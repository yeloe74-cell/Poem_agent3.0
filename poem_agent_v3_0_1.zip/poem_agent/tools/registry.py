"""Typed tool registry with input limits, risk metadata and execution isolation."""
from __future__ import annotations

import asyncio
import inspect
import json
import re
import time
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Mapping

from security.policy_engine import ActionRisk, PolicyEngine

ToolHandler = Callable[[dict[str, Any]], Any | Awaitable[Any]]

@dataclass(frozen=True, slots=True)
class ToolDefinition:
    name: str
    description: str
    handler: ToolHandler
    risk: ActionRisk = ActionRisk.EXTERNAL
    required: tuple[str, ...] = ()
    max_input_chars: int = 4000
    timeout_seconds: float = 20.0
    version: str = "1"
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def validate(self) -> None:
        if not re.fullmatch(r"[a-z][a-z0-9_]{1,48}", self.name):
            raise ValueError("invalid tool name")
        if not self.description.strip() or len(self.description) > 500:
            raise ValueError("invalid tool description")
        if not callable(self.handler):
            raise TypeError("tool handler must be callable")
        if not 100 <= self.max_input_chars <= 50000:
            raise ValueError("tool input limit out of range")

@dataclass(frozen=True)
class ToolExecution:
    name: str
    ok: bool
    output: Any
    elapsed_ms: int
    error: str | None = None

class ToolRegistry:
    """Only trusted Python handlers are executable; model output is data, never code."""
    def __init__(self, policy: PolicyEngine | None = None) -> None:
        self.policy = policy or PolicyEngine()
        self._items: dict[str, ToolDefinition] = {}

    def register(self, definition: ToolDefinition) -> None:
        definition.validate()
        if definition.name in self._items:
            raise ValueError(f"tool already registered: {definition.name}")
        self._items[definition.name] = definition
        self.policy = PolicyEngine(set(self._items), allow_internal_writes=self.policy.allow_internal_writes)

    def describe(self) -> list[dict[str, Any]]:
        return [{"name": item.name, "description": item.description, "risk": item.risk.value,
                 "required": list(item.required), "version": item.version}
                for item in self._items.values()]

    async def execute(self, name: str, arguments: Mapping[str, Any], *,
                      approved: bool = False) -> ToolExecution:
        definition = self._items.get(name)
        if not definition:
            return ToolExecution(name, False, None, 0, "tool is not registered")
        if not isinstance(arguments, Mapping):
            return ToolExecution(name, False, None, 0, "arguments must be an object")
        try:
            encoded = json.dumps(dict(arguments), ensure_ascii=False, default=str)
        except (TypeError, ValueError):
            return ToolExecution(name, False, None, 0, "arguments are not serializable")
        if len(encoded) > definition.max_input_chars:
            return ToolExecution(name, False, None, 0, "arguments exceed tool input limit")
        missing = [key for key in definition.required if key not in arguments]
        if missing:
            return ToolExecution(name, False, None, 0, "missing required arguments: " + ", ".join(missing))
        risk = definition.risk
        if risk not in (ActionRisk.READ, ActionRisk.INTERNAL_WRITE) and not approved:
            return ToolExecution(name, False, None, 0, "owner approval required")
        started = time.monotonic()
        try:
            result = definition.handler(dict(arguments))
            if inspect.isawaitable(result):
                result = await asyncio.wait_for(result, timeout=definition.timeout_seconds)
            return ToolExecution(name, True, result, int((time.monotonic()-started)*1000))
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            return ToolExecution(name, False, None, int((time.monotonic()-started)*1000),
                                 f"{type(exc).__name__}: {str(exc)[:300]}")

    def names(self) -> tuple[str, ...]:
        return tuple(self._items)
