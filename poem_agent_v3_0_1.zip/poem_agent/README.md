# Poem Agent

Telegram ကဗျာ channel စီမံခန့်ခွဲမှုကို ပထမဆုံး Skill အဖြစ်ထားတဲ့ General-Purpose AI Agent။ ကဗျာတွေကို စုဆောင်း၊ ခွဲခြမ်း၊ ပုံရှာ၊ Preview ပို့ပြီး **Owner approve လုပ်မှသာ publish** လုပ်တယ်။ ထို့အပြင် Owner ရဲ့ သဘာဝဘာသာစကားညွှန်ကြားချက်တွေကို နားလည်ဖို့ General Assistant Runtime၊ Task Manager၊ Safe Tools၊ Planning၊ Local Knowledge Retrieval နဲ့ Action Guard ပါဝင်တယ်။

- AI က ကဗျာ **မရေးဘူး**၊ မပြင်ဘူး၊ ရေးသူနာမည် **မဖန်တီးဘူး**။ ဖတ်၊ ခွဲ၊ စစ်၊ ရွေးတာပဲ လုပ်တယ်။
- Python (stdlib) + **Telethon တစ်ခုတည်း** (`requirements.txt`)။ Database က SQLite။

## ⚠️ အခြေအနေ (ရိုးရိုးသားသား)

**v3.0.0 Offline Verification:** Python compile check နဲ့ local fake/in-memory integration tests ၁၄၆ ခု အောင်မြင်ထားတယ်။ Telegram/AI/Image provider တွေကို တကယ့် account/API နဲ့ မခေါ်ထားဘူး။ API keys နဲ့ `.env` ကို မင်းကိုယ်တိုင်ထည့်ပြီး Live Test လုပ်နိုင်အောင် credentials မပါဘဲ ထားထားတယ်။

| Local မှာ စမ်းပြီး (146 tests) | မင်းရဲ့ `.env` နဲ့ Live စမ်းရမယ့်အပိုင်း |
|---|---|
| Database constraint၊ transaction၊ publish approval guard | Telegram နဲ့ တကယ်ချိတ်တာ (Telethon ကို stub နဲ့ပဲ စမ်းထား) |
| စာသား normalize၊ duplicate ၆ မျိုး၊ credit ခွဲတာ | AI API အစစ် (request format ကို API docs အတိုင်းရေးထား၊ မခေါ်ကြည့်ရသေး) |
| Burmese command → intent ("တင်လိုက်", "ပုံပြောင်းပေး" ...) | Wikimedia / Pexels / Unsplash အစစ်ရဲ့ response |
| ပို့စ်ပြင် → preview → approve → တင် → stats flow တစ်ခုလုံး | ကြာကြာ run ရင် memory/ban/rate-limit အခြေအနေ |
| ဒုတိယအကြိမ်နှိပ်/retry/crash ပြီးနောက် ထပ်မတင်မိတာ | systemd deploy |

## Folder

```
main.py                      entry point (--check / --login / --init-db)
config/settings.py           .env ဖတ် (key တွေ code ထဲ မရှိ)   | constants.py  emotions, categories, weekly plan
core/agent.py                controller: poetry tools, confirm guard, background loops
core/general_agent.py        general assistant runtime, tool calling, workflows, task CRUD, audit
core/planner.py              validated multi-step plans
core/reflection.py           evidence-based outcome evaluation
runtime/                     bounded runtime, event bus, context budgeting
tasks/                       durable workflow state, dependencies, idempotency
tools/                       typed trusted tool registry and execution limits
security/                    deny-by-default policies and scoped approvals
core/ai_brain.py             AI (Anthropic / OpenAI / Gemini), task routing, validation
core/intent_rules.py         Burmese phrase rules (AI မခေါ်ဘဲ နားလည်)  | prompts.py, models.py, http_client.py ...
memory/memory_manager.py     short-term, conversation, preferences, avoidances, feedback
memory/knowledge_store.py    local keyword retrieval (no embedding API required)
poetry/poetry_engine.py      collect → credit → duplicate → analyse → select   | text_utils.py
media/image_engine.py        ပုံရှာ၊ license/size စစ်၊ download၊ hash နဲ့ ထပ်မသုံးအောင်
channel/channel_manager.py   plan, post, approval, publish (guarded), stats
telegram/telegram_interface.py  bot client (owner/publish) + user client (source ဖတ်)
storage/database.py + schema.sql   စာရင်းဇယား ၁၈ ခု
tests/                       python -m unittest discover -s tests (146 tests)
deploy/poem-agent.service    systemd
```

## Setup (VPS / local)

Python 3.10+ (3.12 နဲ့ စမ်းထား)။

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env          # ဖြည့်ပါ
python main.py --check        # config/database/Telethon offline စစ်
python main.py --login        # account အလွတ်ကို တစ်ခါတည်း login (ဖုန်းနံပါတ်+code)
python main.py                # run
```

`.env` ထဲမှာ လိုတာ:
1. `TELEGRAM_API_ID` / `TELEGRAM_API_HASH` — https://my.telegram.org
2. `TELEGRAM_BOT_TOKEN` — @BotFather။ Bot ကို **target channel ရဲ့ admin** လုပ်ပေးပါ (post တင်ခွင့်)။
3. `OWNER_TELEGRAM_ID` — သင့်ကိုယ်ပိုင် Telegram numeric id (@userinfobot)။ ဒီ id ကပဲ ထိန်းချုပ်ခွင့်ရှိတယ်။
4. `TARGET_CHANNEL` — `@channelname` ဒါမှမဟုတ် `-100…`
5. AI key အနည်းဆုံး တစ်ခု (`ANTHROPIC_API_KEY` / `OPENAI_API_KEY` / `GEMINI_API_KEY`)။ Model နာမည်တွေ ပြောင်းတတ်လို့ `AI_MODEL_<TASK>` နဲ့ ကိုယ့်ဘာသာ သတ်မှတ်ပါ။

**Bot ကို Telegram မှာ ဖွင့်ပြီး Start ကို တစ်ခါနှိပ်ပါ** — မနှိပ်ရင် bot က Owner ကို message မပို့နိုင်ဘူး။
Account အလွတ် (`--login`) က source channel ဖတ်ဖို့ပဲ သုံးတယ်။ main account မသုံးပါနဲ့။ Scan ကို နှေးနှေးလုပ်ထားတယ် (`SCAN_DELAY_*`)၊ FloodWait ဆိုရင် စောင့်တယ်။

VPS မှာ 24/7: `deploy/poem-agent.service` ထဲ path/user ပြင်ပြီး `systemctl enable --now poem-agent`။

## General Agent စွမ်းရည်အသစ်

Poetry command မဟုတ်တဲ့ Owner စကားတွေကို AI Brain ဆီပို့ပြီး အောက်ပါ trusted tools တွေထဲက လိုအပ်တာကို ရွေးခိုင်းနိုင်တယ်။

- `calculate`: ကန့်သတ်ထားတဲ့ arithmetic AST ကိုသာတွက်တယ်။ Python eval / shell မသုံးဘူး။
- `create_task`, `list_tasks`, `update_task`: SQLite ထဲမှာ task တွေကို persistent သိမ်းတယ်။
- `remember`, `recall`: Owner ပေးတဲ့ project note / preference တွေကို local DB ထဲ သိမ်း၊ ပြန်ရှာတယ်။ Credential နဲ့ secret တွေကို မသိမ်းဘူး။
- `search_knowledge`: Local knowledge records တွေကို keyword overlap နဲ့ရှာတယ်။ Embedding API မလိုဘူး။
- `create_plan`: Tool allow-list နဲ့ dependency ကို validate လုပ်ထားတဲ့ multi-step plan ကို အဆိုပြုတယ်။
- `create_workflow`, `workflow_status`: Workflow ကို SQLite ထဲသိမ်း၊ step state နဲ့ dependency ကို စောင့်ကြည့်တယ်။
- `request_workflow_execution`: Workflow တစ်ခုလုံးနဲ့ Tool arguments ကို Owner ဆီပြပြီး အတည်ပြုချက်တောင်းတယ်။ Owner က `အတည်ပြုလုပ်ဆောင်` လို့ပြန်မှသာ approved step တွေကို run တယ်။
- `ingest_knowledge`, `search_knowledge`: Owner ပေးတဲ့ text ကို chunk ခွဲပြီး local Knowledge Base ထဲသိမ်း၊ ပြန်ရှာတယ်။
- `project_status`: Poetry channel နဲ့ general task အခြေအနေကို ပြတယ်။

AI က tool name/arguments ကို အဆိုပြုနိုင်ပေမဲ့ Python code၊ shell command၊ arbitrary SQL၊ arbitrary URL ကို execute မလုပ်ဘူး။ External/destructive tools အသစ်ထည့်မယ်ဆိုရင် `ActionGuard` ထဲမှာ risk policy သတ်မှတ်ပြီး Owner approval flow ကို ချိတ်ဆက်ရမယ်။ General Agent ရဲ့ AI routing က လက်ရှိ `AI_MODEL_CONVERSATION` route ကို အသုံးပြုတယ်။

**ကန့်သတ်ချက်:** v3 မှာ General Agent runtime, durable workflow, tool registry, memory/knowledge retrieval, event bus, evaluation နဲ့ approval boundary တွေ ပါတယ်။ Browser automation၊ email၊ GitHub နဲ့ arbitrary web research တို့အတွက် သီးခြား connector/tool implementation မထည့်ရသေးဘူး။ Tool မရှိတဲ့အလုပ်ကို လုပ်ပြီးပြီလို့ မပြောစေရန် tool allow-list နဲ့ evidence-based evaluation ထားထားတယ်။

## Owner က ပြောလို့ရတာ

| ပြောရင် | လုပ်ပေးတာ |
|---|---|
| `ကဗျာ ၃ ပုဒ် ပြင်ပေး` | ကဗျာ+ပုံ ရွေး၊ preview ၃ ခု ပို့ (စီစဉ်ထားတဲ့ အချိန်နဲ့) |
| `တင်လိုက်` | Approve — စီစဉ်ထားတဲ့အချိန်ရှိရင် အဲဒီအချိန်မှာ၊ မရှိရင် ချက်ချင်းတင် |
| `ချက်ချင်း တင်လိုက်` | Approve + အခုတင် |
| `ဒီတစ်ပုဒ်မကြိုက်ဘူး` / `နောက်တစ်ပုဒ်ပြ` | ဖယ် (ကဗျာ reject) / ကျော်ပြီး နောက်တစ်ပုဒ် |
| `ပုံပြောင်းပေး` / `ဒီလိုပုံမျိုး မသုံးနဲ့` | ပုံလဲ / ပုံအမျိုးအစား ထပ်မသုံးတော့ |
| `မနက်ဖြန်အတွက် သိမ်းထားလိုက်` (`မနက်ဖြန် ည ၇ နာရီ`) | အချိန်ချိန်း |
| `ဒီနေ့ မတင်တော့နဲ့` | ဒီနေ့ပို့စ်တွေ ဖျက်၊ slot ပိတ် |
| `အလွမ်းကဗျာတွေ များနေပြီ` | ရက်အနည်းငယ် လျှော့ |
| `t.me/name ထည့်ပေး` / `… ဖယ်လိုက်` | source ထည့်/ဖယ် (ဖယ်ရင် "ဟုတ်" လို့ confirm လိုတယ်) |
| `အခြေအနေ` / `စာရင်း` / `ခဏရပ်` / `ပြန်စ` | status / report / auto ရပ်-စ |

ခလုတ်လည်း ပါတယ် (✅ ❌ 🖼 ⏭ 🗓)။ ရှင်းမပြောတဲ့ စကားဆို AI က ကူနားလည်ပေးတယ်၊ မသေချာရင် ပြန်မေးတယ်။ "ကောင်းတယ်" လို စကားက approve မဟုတ်ပါဘူး။

## ဘယ်လို လုံခြုံအောင် လုပ်ထားလဲ

- Owner id မဟုတ်သူရဲ့ message/ခလုတ် အကုန်လျှော့ပစ် (log ထဲ မှတ်)။
- **Approve မရှိရင် publish မလုပ်ဘူး** — code ထဲရော database trigger ကပါ တားထားတယ်။
- Post တစ်ခု ၂ ခါ မတင်မိအောင် atomic claim + `UNIQUE` index။ တင်နေရင်း ရပ်သွားတာကို ကိုယ်တိုင် ပြန်မတင်ဘဲ Owner ကို အကြောင်းကြား။
- Credit ကို source က ရေးထားတာပဲ ယူတယ်၊ မရှိရင် `unknown` (DB ကပါ author ထည့်ခွင့်မပေး)။ Poem တစ်ပုဒ်စီမှာ source link မှတ်ထားတယ်။
- ပုံ — license (NC/ND ပယ်)၊ အရွယ်အစား၊ https၊ ပုံ file hash နဲ့ ထပ်မသုံးတာ စစ်။ CC BY လို attribution လိုတာကို caption မှာ ထည့်။ ဒီနေ့ ပုံရှာတဲ့ အကန့်အသတ် (`IMAGE_DAILY_LIMIT`)။

## သိထားရမယ့် ကန့်သတ်ချက်

- **Zawgyi** စာသားကို heuristic နဲ့ သိပြီး default မှာ ကျော်တယ် (`ALLOW_ZAWGYI=false`)၊ Unicode ပြောင်းပေးတာ မပါသေးဘူး။
- ပုံ image-hash က exact file ပဲ နှိုင်းယှဉ်တယ် (perceptual hash မပါ)။ ပုံ-ကဗျာ ကိုက်မှုက description စာသားအပေါ်မှာပဲ (ပုံကို AI က မကြည့်ဘူး)။
- Private/invite channel ဖတ်လို့မရ (public channel ပဲ)။
- Unsplash က API guideline (download tracking, attribution link) ပိုတင်းတယ်၊ Pexels/Wikimedia ကို အရင်သုံးပါ။
- Local ပက်ကေ့ချ်နာမည် `telegram/` ကြောင့် `python-telegram-bot` ကို ဒီ environment ထဲ မထည့်ပါနဲ့ (နာမည်တူတယ်)။
- ကဗျာ ခွင့်ပြုချက်/credit စစ်ဆေးမှုကို Owner က တာဝန်ယူပြီးသား။

## Copilot နဲ့ ပြင်မယ်ဆိုရင်

ပြင်တိုင်း `python -m unittest discover -s tests` ပြန် run ပါ (146 ခု အကုန်အောင်ရမယ်)။ ပထမဆုံး live run မှာ log (`logs/poem_agent.log`) နဲ့ `error_logs` table ကို ကြည့်ပါ၊ နောက်ပြီး ဒီအစဉ်အတိုင်း စစ်ပါ - ① `--check` ② `--login` ③ Bot ကို Start နှိပ် → `ကူညီ` ပို့ ④ `t.me/…` source တစ်ခုထည့် ⑤ `ကဗျာ ၁ ပုဒ် ပြင်ပေး` ⑥ `ချက်ချင်း တင်လိုက်` (test channel တစ်ခုနဲ့ အရင်စမ်း)။


## Poem Agent 3.0.0 — Advanced Runtime

- `runtime/agent_runtime.py`: step/time/tool-call budgets နဲ့ cancellation ပါတဲ့ bounded execution loop။
- `runtime/event_bus.py`: typed asynchronous events, handler isolation, metrics။
- `runtime/context_builder.py`: prompt context budget နဲ့ credential redaction။
- `tasks/workflow_engine.py`: SQLite durable workflows, dependency validation, resumable checkpoints, retries, idempotency records, approval states။
- `tools/registry.py`: trusted Python handlers only, typed risk, input validation, timeout။ AI-generated code ကို execute မလုပ်ဘူး။
- `security/policy_engine.py`: expiring single-use scoped approval tokens နဲ့ default-deny policy။
- `memory/episodic_memory.py`: importance/recency weighting, secret rejection, retention expiry။
- `knowledge/ingestion.py`: plain text ကို deterministic chunks ခွဲပြီး local KnowledgeStore ထဲသိမ်း။
- `core/reflection.py`: tool result evidence ရှိမှ completion ကို verified လို့သတ်မှတ်တယ်။

General Agent runtime limits ကို `.env.example` ထဲက `GENERAL_AGENT_*`, `WORKFLOW_*`, `RUNTIME_*`, `MEMORY_RETENTION_DAYS`, `KNOWLEDGE_CHUNK_CHARS`, `TOOL_TIMEOUT_SECONDS` တို့နဲ့ ချိန်ညှိနိုင်တယ်။ အကန့်အသတ်တွေကို code ထဲမှာ ထပ်မံ clamp လုပ်ထားတယ်။

Workflow execution က အရင်ဆုံး plan ကို ပြပြီး Owner confirmation တောင်းတယ်။ အတည်ပြုပြီးမှ registered tools ကို dependency order နဲ့ run တယ်။ Telegram owner-only gate ကနေတစ်ဆင့်ပဲ ဒီ confirmation ကို လက်ခံတယ်။
