"""Text helpers for poems: normalisation, similarity, credit extraction, Zawgyi flag.

Nothing here rewrites a poem. `split_credit` only separates the trailing
hashtag/credit footer from the poem body so the body can be shown verbatim.
"""
from __future__ import annotations

import hashlib
import re
import unicodedata
from dataclasses import dataclass
from typing import Iterable

from config.constants import GENERIC_HASHTAGS, TOPIC_WORDS
from core.models import CreditInfo

_ZERO_WIDTH = dict.fromkeys(map(ord, "\u200b\u200c\u200d\u2060\ufeff"), None)
_URL_RE = re.compile(r"https?://\S+|t\.me/\S+|\bwww\.\S+", re.I)
_HANDLE_RE = re.compile(r"@\w+")
_HASHTAG_RE = re.compile(r"#([^\s#]+)")
_DASH_CREDIT_RE = re.compile(r"^\s*[—–\-~✍️✍]+\s*(\S.{0,38})$")


# ---------------------------------------------------------------- normalise
def normalize_text(text: str) -> str:
    """Unicode NFC, no zero-width chars, no urls/hashtags/punctuation/emoji, single spaces."""
    t = unicodedata.normalize("NFC", text).translate(_ZERO_WIDTH).lower()
    t = _URL_RE.sub(" ", t)
    t = _HANDLE_RE.sub(" ", t)
    t = _HASHTAG_RE.sub(" ", t)
    t = "".join(ch if (unicodedata.category(ch)[0] in "LMN" or ch.isspace()) else " " for ch in t)
    return re.sub(r"\s+", " ", t).strip()


def compact_text(text: str) -> str:
    """Normalised text with ALL whitespace removed (Burmese has no word spaces,
    and authors place spaces/line-breaks differently)."""
    return re.sub(r"\s+", "", normalize_text(text))


def text_hash(compact: str) -> str:
    return hashlib.sha256(compact.encode("utf-8")).hexdigest()


# --------------------------------------------------------------- similarity
def trigrams(compact: str) -> frozenset[str]:
    if len(compact) < 3:
        return frozenset({compact}) if compact else frozenset()
    return frozenset(compact[i:i + 3] for i in range(len(compact) - 2))


def jaccard(a: frozenset[str], b: frozenset[str]) -> float:
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def containment(a: frozenset[str], b: frozenset[str]) -> float:
    """Share of the smaller trigram set that also appears in the larger one."""
    if not a or not b:
        return 0.0
    small, large = (a, b) if len(a) <= len(b) else (b, a)
    return len(small & large) / len(small)


def sequence_ratio(a: str, b: str) -> float:
    from difflib import SequenceMatcher
    if not a or not b:
        return 0.0
    return SequenceMatcher(None, a, b, autojunk=False).ratio()


@dataclass
class DupScore:
    similarity: float
    containment: float
    length_ratio: float


def compare(a: str, b: str, ta: frozenset[str] | None = None, tb: frozenset[str] | None = None) -> DupScore:
    """Compare two compact texts."""
    ta = ta if ta is not None else trigrams(a)
    tb = tb if tb is not None else trigrams(b)
    jac = jaccard(ta, tb)
    sim = sequence_ratio(a, b) if jac >= 0.35 else jac
    longest = max(len(a), len(b)) or 1
    return DupScore(sim, containment(ta, tb), min(len(a), len(b)) / longest)


# ------------------------------------------------------------------- Zawgyi
_ZAWGYI_PATTERNS = (
    re.compile(r"[\u1060-\u1097]"),                       # Zawgyi-only stacked/extended forms
    re.compile(r"(?:^|[\s\u104a\u104b])\u1031[\u1000-\u1021]"),   # 'ေ' typed before the consonant
    re.compile(r"\u1031\u103b"),                           # 'ေျ' visual order
)
_UNICODE_PATTERNS = (
    re.compile(r"[\u1000-\u1021]\u1039[\u1000-\u1021]"),  # real virama stacking
    re.compile(r"\u1004\u103a\u1039"),                    # kinzi
)


def looks_zawgyi(text: str) -> bool:
    """Heuristic only. True when the text shows Zawgyi-style encoding."""
    score = sum(len(p.findall(text)) for p in _ZAWGYI_PATTERNS)
    score -= sum(len(p.findall(text)) for p in _UNICODE_PATTERNS)
    return score >= 1


# ------------------------------------------------------------------ credits
def _is_generic(tag: str, generic: Iterable[str]) -> bool:
    low = tag.lower()
    if low in {g.lower() for g in generic} or tag.endswith("ကဗျာ"):
        return True
    return any(tag == word for word in TOPIC_WORDS)


def _footer_line(line: str) -> bool:
    """A line made only of hashtags / handles / urls / a short dash credit."""
    s = line.strip()
    if not s:
        return True
    rest = _HASHTAG_RE.sub("", _HANDLE_RE.sub("", _URL_RE.sub("", s))).strip(" \t|•·—–-~")
    if not rest:
        return True
    return bool(_DASH_CREDIT_RE.match(s)) and len(s) <= 40


def split_credit(text: str, generic_tags: Iterable[str] = GENERIC_HASHTAGS) -> tuple[str, CreditInfo]:
    """Return (poem_body, CreditInfo). The author is taken ONLY from what the source wrote."""
    lines = text.strip().splitlines()
    end = len(lines)
    while end > 0 and _footer_line(lines[end - 1]):
        end -= 1
    body_lines, footer = lines[:end], lines[end:]
    # A poet hashtag may share the last text line ("... #အောင်ချိန့်"): look there too.
    last_text = body_lines[-1] if body_lines else ""
    tags_in_last = _HASHTAG_RE.findall(last_text)

    candidates: list[tuple[str, float]] = []
    for line in footer:
        for tag in _HASHTAG_RE.findall(line):
            if not _is_generic(tag, generic_tags):
                candidates.append((tag, 0.0))
        m = _DASH_CREDIT_RE.match(line.strip())
        if m and "#" not in line:
            name = m.group(1).strip()
            if name and not _URL_RE.search(name):
                candidates.append((name, 0.75))
    if not candidates and tags_in_last:
        non_generic = [t for t in tags_in_last if not _is_generic(t, generic_tags)]
        if non_generic:
            candidates.append((non_generic[-1], 0.0))
            body_lines[-1] = _HASHTAG_RE.sub("", last_text).rstrip()
    body = "\n".join(body_lines).strip()
    if not body:                      # footer swallowed everything -> it was not a footer
        return text.strip(), CreditInfo()
    if not candidates:
        return body, CreditInfo()
    name, conf = candidates[0]
    hashtag_form = conf == 0.0
    if hashtag_form:
        conf = 0.85 if len(candidates) == 1 else 0.6
    display = name.replace("_", " ").strip()
    return body, CreditInfo(status="known", author_name=display,
                            credit_text=f"#{name}" if hashtag_form else name, confidence=conf)
