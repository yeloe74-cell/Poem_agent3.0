"""Poetry engine (main file 06/10).

Ingest pipeline for every collected message:
  filter -> split credit -> duplicate check -> store -> AI analysis -> 'analyzed'
Selection scores analysed poems (quality, variety, owner avoidances, plan target,
past performance) and returns the best eligible one.

The engine never edits a poem and never invents an author: credit comes only
from the source text and is 'unknown' otherwise.
"""
from __future__ import annotations

import logging
import traceback
from collections import Counter
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Sequence

from config.constants import BEST_CATEGORY
from config.settings import Settings
from core.ai_brain import AIBrain
from core.errors import AIError
from core.models import CreditInfo, IngestResult, SourceMessage
from core.time_utils import to_db, utcnow
from datetime import timedelta
from poetry import text_utils as tu
from storage.database import Database

log = logging.getLogger(__name__)
Fetcher = Callable[[str, int, int], Awaitable[Sequence[SourceMessage]]]


@dataclass
class Candidate:
    poem: dict[str, Any]
    score: float
    breakdown: dict[str, float] = field(default_factory=dict)


class DupIndex:
    """In-memory trigram index of known poems for fast near-duplicate lookup."""

    def __init__(self) -> None:
        self._items: dict[int, tuple[str, frozenset[str]]] = {}

    def add(self, poem_id: int, compact: str) -> None:
        self._items[poem_id] = (compact, tu.trigrams(compact))

    def __len__(self) -> int:
        return len(self._items)

    def best_match(self, compact: str) -> tuple[int, tu.DupScore] | None:
        grams = tu.trigrams(compact)
        shortlist = sorted(((tu.jaccard(grams, g), pid) for pid, (_, g) in self._items.items()), reverse=True)[:5]
        best: tuple[int, tu.DupScore] | None = None
        for jac, pid in shortlist:
            if jac < 0.2:
                break
            other, other_grams = self._items[pid]
            score = tu.compare(compact, other, grams, other_grams)
            if best is None or max(score.similarity, score.containment) > max(best[1].similarity, best[1].containment):
                best = (pid, score)
        return best


class PoetryEngine:
    def __init__(self, db: Database, brain: AIBrain, settings: Settings) -> None:
        self.db = db
        self.brain = brain
        self.settings = settings
        self.index = DupIndex()
        self._index_loaded = False

    async def _ensure_index(self) -> None:
        if not self._index_loaded:
            for row in await self.db.poem_index_rows():
                self.index.add(row["id"], tu.compact_text(row["normalized_text"]))
            self._index_loaded = True

    # ------------------------------------------------------------------
    # collection
    # ------------------------------------------------------------------
    async def scan_channel(self, channel: dict[str, Any], fetch: Fetcher) -> dict[str, int]:
        """Read new messages of one source channel and ingest them."""
        messages = await fetch(channel["link"], channel["last_message_id"], self.settings.scan_batch_limit)
        counts: Counter[str] = Counter()
        highest = channel["last_message_id"]
        for msg in messages:
            highest = max(highest, msg.message_id)
            try:
                result = await self.ingest(channel["id"], msg)
            except Exception as exc:  # one bad message must not stop the scan
                await self.db.log_error("poetry_engine", f"ingest failed for {msg.link or msg.message_id}: {exc}",
                                        traceback.format_exc())
                counts["error"] += 1
                continue
            counts[result.status] += 1
        await self.db.update_scan_state(channel["id"], highest)
        return dict(counts)

    async def ingest(self, channel_id: int, msg: SourceMessage) -> IngestResult:
        s = self.settings
        text = (msg.text or "").strip()
        if len(text) < s.min_poem_chars:
            return IngestResult("skipped", reason="too short")
        if await self.db.get_poem_by_source(channel_id, msg.message_id):
            return IngestResult("skipped", reason="already collected")

        body, credit = tu.split_credit(text, s.generic_hashtags)
        credit.source_link = msg.link or None
        if not (s.min_poem_chars <= len(body) <= s.max_poem_chars):
            return IngestResult("skipped", reason="length out of range")
        normalized = tu.normalize_text(body)
        compact = tu.compact_text(body)
        if len(compact) < 10:
            return IngestResult("skipped", reason="no real text")
        digest = tu.text_hash(compact)
        zawgyi = tu.looks_zawgyi(body)

        await self._ensure_index()
        dup = await self._find_duplicate(text, compact, digest)
        language = "my-zawgyi" if zawgyi else "my"
        status = "duplicate" if dup else ("rejected" if zawgyi and not s.allow_zawgyi else "new")
        poem_id = await self.db.insert_poem(
            channel_id, msg.message_id, text, normalized, digest, original_link=msg.link or None,
            language=language, has_media=msg.has_media, status=status)
        if poem_id is None:
            return IngestResult("skipped", reason="already collected")
        await self._store_credit(poem_id, credit)
        if dup:
            await self.db.add_duplicate(poem_id, dup[0], dup[1], dup[2])
            return IngestResult("duplicate", poem_id, f"{dup[1]} of #{dup[0]}")
        self.index.add(poem_id, compact)
        if status == "rejected":
            return IngestResult("rejected", poem_id, "Zawgyi-encoded text")
        await self.analyze(poem_id, body)
        return IngestResult("stored", poem_id)

    async def _store_credit(self, poem_id: int, credit: CreditInfo) -> None:
        await self.db.save_credit(poem_id, credit.status, credit.author_name, credit.credit_text,
                                  credit.confidence, credit.source_link)

    async def _find_duplicate(self, raw: str, compact: str, digest: str) -> tuple[int, str, float] | None:
        """(original_poem_id, dup_type, similarity) or None."""
        exact = await self.db.find_poem_by_hash(digest)
        if exact:
            same_raw = (exact["raw_text"] or "").strip() == raw.strip()
            return exact["id"], "exact" if same_raw else "formatting", 1.0
        match = self.index.best_match(compact)
        if not match:
            return None
        pid, score = match
        s = self.settings
        if score.similarity >= 0.97:
            return pid, "minor_change", score.similarity
        if score.similarity >= s.dup_similar:
            return pid, "similar", score.similarity
        if score.containment >= 0.9 and score.length_ratio < 0.8:
            return pid, "partial", score.containment
        if score.similarity >= s.dup_borderline:
            other = await self.db.get_poem(pid)
            try:
                same, conf = await self.brain.judge_duplicate(raw, other["raw_text"] if other else "")
            except AIError:
                return pid, "similar", score.similarity       # cautious: treat as duplicate
            if same and conf >= 0.6:
                return pid, "semantic", score.similarity
        return None

    # ------------------------------------------------------------------
    # analysis
    # ------------------------------------------------------------------
    async def analyze(self, poem_id: int, body: str) -> bool:
        """Run the AI analysis. On failure the poem stays 'new' and is retried later."""
        try:
            a = await self.brain.analyze_poem(body)
        except AIError as exc:
            await self.db.log_error("poetry_engine", f"analysis failed for poem {poem_id}: {exc}", level="warning")
            return False
        await self.db.save_analysis(poem_id, a.emotions, a.categories, a.quality_score, a.quality_notes, a.model_used)
        await self.db.set_poem_status(poem_id, "analyzed")
        return True

    async def process_pending(self, limit: int = 20) -> int:
        """Retry analysis for poems that failed earlier. Returns how many succeeded."""
        done = 0
        for poem in await self.db.list_poems("new", limit):
            body, _ = tu.split_credit(poem["raw_text"], self.settings.generic_hashtags)
            if await self.analyze(poem["id"], body):
                done += 1
        return done

    # ------------------------------------------------------------------
    # selection
    # ------------------------------------------------------------------
    async def _performance_by_category(self) -> dict[str, float]:
        """Average views per category over the last 30 days, scaled to 0..1."""
        since = to_db(utcnow() - timedelta(days=30))
        totals: dict[str, list[int]] = {}
        for row in await self.db.performance_rows(since):
            if row["views"] is None:
                continue
            for cat in row["categories"]:
                totals.setdefault(cat, []).append(int(row["views"]))
        averages = {c: sum(v) / len(v) for c, v in totals.items()}
        top = max(averages.values(), default=0)
        return {c: (a / top if top else 0.0) for c, a in averages.items()}

    async def rank_candidates(self, *, target_category: str | None = None, exclude_ids: Sequence[int] = (),
                              avoid: dict[str, list[str]] | None = None, limit: int = 5) -> list[Candidate]:
        avoid = avoid or {}
        poems = await self.db.candidate_poems()
        recent = await self.db.recent_posts_analysis(6)
        recent_cats = Counter(c for r in recent for c in r["categories"])
        recent_emos = Counter(e["name"] for r in recent for e in r["emotions"][:1])
        perf = await self._performance_by_category()
        ranked: list[Candidate] = []
        for p in poems:
            if p["id"] in exclude_ids:
                continue
            top_emotion = p["emotions"][0]["name"] if p["emotions"] else None
            if top_emotion in avoid.get("emotion", []) or any(c in avoid.get("category", []) for c in p["categories"]):
                continue                                           # owner said "too many of this"
            b: dict[str, float] = {"quality": (p["quality_score"] or 50) / 100 * 0.5}
            if p["credit_status"] == "known":
                b["credit"] = 0.06 * (p["credit_confidence"] or 0.5)
            if len(p["raw_text"]) <= 600:
                b["fits_telegram"] = 0.04
            repeats = sum(recent_cats[c] for c in p["categories"]) + (recent_emos[top_emotion] if top_emotion else 0)
            b["variety"] = max(0.0, 0.25 - 0.06 * repeats)
            if target_category == BEST_CATEGORY:
                b["plan"] = 0.2 if (p["quality_score"] or 0) >= 80 else 0.0
            elif target_category and target_category != "any" and target_category in p["categories"]:
                b["plan"] = 0.3
            b["audience"] = 0.1 * max((perf.get(c, 0.0) for c in p["categories"]), default=0.0)
            ranked.append(Candidate(p, round(sum(b.values()), 4), b))
        ranked.sort(key=lambda c: (-c.score, c.poem["id"]))
        return ranked[:limit]

    async def select_poem(self, *, target_category: str | None = None, exclude_ids: Sequence[int] = (),
                          avoid: dict[str, list[str]] | None = None) -> Candidate | None:
        found = await self.rank_candidates(target_category=target_category, exclude_ids=exclude_ids, avoid=avoid, limit=1)
        return found[0] if found else None

    def body_and_credit(self, raw_text: str) -> tuple[str, CreditInfo]:
        return tu.split_credit(raw_text, self.settings.generic_hashtags)

    async def release_poem(self, poem_id: int) -> None:
        """Put a selected-but-unused poem back into the pool."""
        await self.db.set_poem_status(poem_id, "analyzed")

    async def reject_poem(self, poem_id: int) -> None:
        await self.db.set_poem_status(poem_id, "rejected")
