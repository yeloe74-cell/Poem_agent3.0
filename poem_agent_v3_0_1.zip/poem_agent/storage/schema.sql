-- =====================================================================
-- Poem Agent - SQLite schema (version 1)
-- NOTE: PRAGMA foreign_keys is per-connection. database.py MUST run
--       "PRAGMA foreign_keys = ON" on every new connection.
-- All timestamps are UTC text: datetime('now').
-- JSON columns (emotions, categories, ...) are stored as TEXT.
-- =====================================================================

PRAGMA journal_mode = WAL;

-- 0. Schema version (for future migrations) ----------------------------
CREATE TABLE IF NOT EXISTS schema_meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
INSERT OR IGNORE INTO schema_meta (key, value) VALUES ('schema_version', '1');

-- 1. Owner & configuration (secrets stay in .env, never here) ----------
CREATE TABLE IF NOT EXISTS owner_config (
    key        TEXT PRIMARY KEY,
    value      TEXT NOT NULL,
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- 2. Source channels ---------------------------------------------------
CREATE TABLE IF NOT EXISTS source_channels (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    link            TEXT NOT NULL UNIQUE,
    username        TEXT,
    title           TEXT,
    is_active       INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0, 1)),
    last_message_id INTEGER NOT NULL DEFAULT 0,
    last_scan_at    TEXT,
    added_at        TEXT NOT NULL DEFAULT (datetime('now'))
);

-- 6a. Authors ----------------------------------------------------------
CREATE TABLE IF NOT EXISTS authors (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT NOT NULL UNIQUE,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

-- 3. Collected poems ---------------------------------------------------
CREATE TABLE IF NOT EXISTS poems (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    source_channel_id INTEGER NOT NULL
                      REFERENCES source_channels (id) ON DELETE RESTRICT,
    source_message_id INTEGER NOT NULL,
    original_link     TEXT,
    raw_text          TEXT NOT NULL,
    normalized_text   TEXT NOT NULL,
    text_hash         TEXT NOT NULL,
    language          TEXT NOT NULL DEFAULT 'my',
    has_media         INTEGER NOT NULL DEFAULT 0 CHECK (has_media IN (0, 1)),
    media_info        TEXT,
    status            TEXT NOT NULL DEFAULT 'new'
                      CHECK (status IN ('new', 'analyzed', 'duplicate',
                                        'selected', 'rejected', 'posted')),
    collected_at      TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (source_channel_id, source_message_id)
);
CREATE INDEX IF NOT EXISTS idx_poems_hash   ON poems (text_hash);
CREATE INDEX IF NOT EXISTS idx_poems_status ON poems (status);

-- 4. Poetry analysis ---------------------------------------------------
CREATE TABLE IF NOT EXISTS poem_analysis (
    poem_id       INTEGER PRIMARY KEY
                  REFERENCES poems (id) ON DELETE CASCADE,
    emotions      TEXT NOT NULL DEFAULT '[]',
    categories    TEXT NOT NULL DEFAULT '[]',
    quality_score REAL CHECK (quality_score BETWEEN 0 AND 100),
    quality_notes TEXT,
    model_used    TEXT,
    analyzed_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

-- 5. Duplicate records -------------------------------------------------
CREATE TABLE IF NOT EXISTS duplicate_records (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    poem_id         INTEGER NOT NULL
                    REFERENCES poems (id) ON DELETE CASCADE,
    duplicate_of_id INTEGER NOT NULL
                    REFERENCES poems (id) ON DELETE CASCADE,
    dup_type        TEXT NOT NULL
                    CHECK (dup_type IN ('exact', 'similar', 'partial',
                                        'formatting', 'minor_change',
                                        'repost', 'semantic')),
    similarity      REAL CHECK (similarity BETWEEN 0 AND 1),
    detected_at     TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (poem_id, duplicate_of_id),
    CHECK (poem_id <> duplicate_of_id)
);

-- 6b. Poem credits (AI must never invent an author) --------------------
CREATE TABLE IF NOT EXISTS poem_credits (
    poem_id           INTEGER PRIMARY KEY
                      REFERENCES poems (id) ON DELETE CASCADE,
    author_id         INTEGER REFERENCES authors (id) ON DELETE SET NULL,
    credit_text       TEXT,
    credit_status     TEXT NOT NULL DEFAULT 'unknown'
                      CHECK (credit_status IN ('known', 'unknown')),
    credit_confidence REAL CHECK (credit_confidence BETWEEN 0 AND 1),
    source_link       TEXT,
    -- unknown credit can never carry an author
    CHECK (credit_status = 'known' OR author_id IS NULL),
    -- known credit must carry an author or the original credit text
    CHECK (credit_status <> 'known'
           OR author_id IS NOT NULL OR credit_text IS NOT NULL)
);

-- 7. Images ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS images (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    poem_id      INTEGER REFERENCES poems (id) ON DELETE SET NULL,
    url          TEXT NOT NULL,
    source       TEXT NOT NULL,
    license      TEXT,
    attribution  TEXT,
    width        INTEGER,
    height       INTEGER,
    image_hash   TEXT,
    is_valid     INTEGER NOT NULL DEFAULT 1 CHECK (is_valid IN (0, 1)),
    match_score  REAL CHECK (match_score BETWEEN 0 AND 100),
    search_query TEXT,
    created_at   TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (poem_id, url)
);
CREATE INDEX IF NOT EXISTS idx_images_hash ON images (image_hash);

-- 8. Content plans -----------------------------------------------------
CREATE TABLE IF NOT EXISTS content_plans (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    plan_date       TEXT NOT NULL,
    target_category TEXT NOT NULL DEFAULT 'any',
    post_count      INTEGER NOT NULL DEFAULT 1 CHECK (post_count >= 0),
    notes           TEXT,
    created_by      TEXT NOT NULL DEFAULT 'agent'
                    CHECK (created_by IN ('agent', 'owner')),
    created_at      TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (plan_date, target_category)
);

-- 9. Scheduled posts ---------------------------------------------------
CREATE TABLE IF NOT EXISTS scheduled_posts (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    poem_id      INTEGER NOT NULL REFERENCES poems (id) ON DELETE RESTRICT,
    image_id     INTEGER REFERENCES images (id) ON DELETE SET NULL,
    plan_id      INTEGER REFERENCES content_plans (id) ON DELETE SET NULL,
    caption      TEXT NOT NULL,
    scheduled_at TEXT,
    status       TEXT NOT NULL DEFAULT 'draft'
                 CHECK (status IN ('draft', 'pending_approval', 'approved',
                                   'scheduled', 'publishing', 'published',
                                   'failed', 'rejected', 'cancelled')),
    created_at   TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at   TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_posts_status ON scheduled_posts (status, scheduled_at);
-- one live post per poem (stops the same poem being queued twice)
CREATE UNIQUE INDEX IF NOT EXISTS uq_active_post_per_poem
    ON scheduled_posts (poem_id)
    WHERE status NOT IN ('rejected', 'cancelled', 'failed');

CREATE TRIGGER IF NOT EXISTS trg_posts_touch
AFTER UPDATE ON scheduled_posts
FOR EACH ROW WHEN NEW.updated_at = OLD.updated_at
BEGIN
    UPDATE scheduled_posts SET updated_at = datetime('now') WHERE id = NEW.id;
END;

-- 10. Approval records -------------------------------------------------
CREATE TABLE IF NOT EXISTS approvals (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id       INTEGER NOT NULL
                  REFERENCES scheduled_posts (id) ON DELETE CASCADE,
    decision      TEXT NOT NULL DEFAULT 'pending'
                  CHECK (decision IN ('pending', 'approved', 'rejected',
                                      'changes_requested')),
    owner_message TEXT,
    requested_at  TEXT NOT NULL DEFAULT (datetime('now')),
    decided_at    TEXT
);
CREATE INDEX IF NOT EXISTS idx_approvals_post ON approvals (post_id, decision);

-- 11. Publishing history -----------------------------------------------
CREATE TABLE IF NOT EXISTS publishing_history (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id             INTEGER NOT NULL
                        REFERENCES scheduled_posts (id) ON DELETE RESTRICT,
    channel_id          TEXT NOT NULL,
    telegram_message_id INTEGER,
    status              TEXT NOT NULL CHECK (status IN ('success', 'failed')),
    error_message       TEXT,
    attempt             INTEGER NOT NULL DEFAULT 1 CHECK (attempt >= 1),
    published_at        TEXT NOT NULL DEFAULT (datetime('now'))
);
-- a post can succeed only once (duplicate publishing prevention)
CREATE UNIQUE INDEX IF NOT EXISTS uq_one_success_per_post
    ON publishing_history (post_id) WHERE status = 'success';

-- publishing approval guard, enforced by the database itself
CREATE TRIGGER IF NOT EXISTS trg_publish_requires_approval
BEFORE INSERT ON publishing_history
FOR EACH ROW WHEN NEW.status = 'success'
BEGIN
    SELECT RAISE(ABORT, 'publish blocked: post has no owner approval')
    WHERE NOT EXISTS (
        SELECT 1 FROM approvals
        WHERE post_id = NEW.post_id AND decision = 'approved'
    );
END;

-- 12. Post stats (analytics) -------------------------------------------
CREATE TABLE IF NOT EXISTS post_stats (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    publishing_id INTEGER NOT NULL
                  REFERENCES publishing_history (id) ON DELETE CASCADE,
    views         INTEGER NOT NULL DEFAULT 0 CHECK (views >= 0),
    reactions     INTEGER NOT NULL DEFAULT 0 CHECK (reactions >= 0),
    forwards      INTEGER NOT NULL DEFAULT 0 CHECK (forwards >= 0),
    captured_at   TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_stats_pub ON post_stats (publishing_id, captured_at);

-- 13. Agent memory -----------------------------------------------------
CREATE TABLE IF NOT EXISTS agent_memory (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    memory_type TEXT NOT NULL
                CHECK (memory_type IN ('short_term', 'long_term',
                                       'conversation', 'preference',
                                       'channel_style', 'task', 'feedback')),
    mem_key     TEXT,
    content     TEXT NOT NULL,
    importance  INTEGER NOT NULL DEFAULT 1 CHECK (importance BETWEEN 1 AND 5),
    created_at  TEXT NOT NULL DEFAULT (datetime('now')),
    expires_at  TEXT
);
CREATE INDEX IF NOT EXISTS idx_memory_lookup ON agent_memory (memory_type, mem_key);

-- 14. Feedback records (owner's Burmese words -> parsed intent) --------
CREATE TABLE IF NOT EXISTS feedback_records (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id       INTEGER REFERENCES scheduled_posts (id) ON DELETE SET NULL,
    poem_id       INTEGER REFERENCES poems (id) ON DELETE SET NULL,
    owner_text    TEXT NOT NULL,
    parsed_intent TEXT,
    parsed_params TEXT,
    applied       INTEGER NOT NULL DEFAULT 0 CHECK (applied IN (0, 1)),
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

-- 15. Task & execution logs --------------------------------------------
CREATE TABLE IF NOT EXISTS task_logs (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    task_type      TEXT NOT NULL,
    state          TEXT NOT NULL DEFAULT 'pending'
                   CHECK (state IN ('pending', 'running', 'done',
                                    'failed', 'cancelled')),
    input_data     TEXT,
    result_data    TEXT,
    parent_task_id INTEGER REFERENCES task_logs (id) ON DELETE SET NULL,
    created_at     TEXT NOT NULL DEFAULT (datetime('now')),
    started_at     TEXT,
    finished_at    TEXT
);
CREATE INDEX IF NOT EXISTS idx_tasks_state ON task_logs (state, task_type);

-- 16. Error logs -------------------------------------------------------
CREATE TABLE IF NOT EXISTS error_logs (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    module     TEXT NOT NULL,
    level      TEXT NOT NULL DEFAULT 'error'
               CHECK (level IN ('warning', 'error', 'critical')),
    message    TEXT NOT NULL,
    traceback  TEXT,
    task_id    INTEGER REFERENCES task_logs (id) ON DELETE SET NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS idx_errors_time ON error_logs (created_at);

