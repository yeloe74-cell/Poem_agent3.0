"""Database layer (main file 02/10).

A thin, thread-safe wrapper around the standard-library `sqlite3`. All public
methods are `async`: the blocking SQLite call runs in a worker thread and a
lock serialises access to the single connection. Multi-step changes use
`transaction()` so they commit or roll back as a unit.

The schema lives in `schema.sql` (same folder).
"""
from __future__ import annotations

import asyncio
import json
import logging
import sqlite3
import threading
from pathlib import Path
from typing import Any, Callable, Iterable, Sequence

from core.time_utils import to_db, utcnow

log = logging.getLogger(__name__)
SCHEMA_PATH = Path(__file__).with_name("schema.sql")


def _loads(value: str | None, default: Any) -> Any:
    try:
        return json.loads(value) if value else default
    except (TypeError, json.JSONDecodeError):
        return default


class Database:
    def __init__(self, path: str | Path = ":memory:", schema_path: Path = SCHEMA_PATH) -> None:
        self.path = str(path)
        self.schema_path = schema_path
        self._lock = threading.RLock()
        self._conn: sqlite3.Connection | None = None

    # ------------------------------------------------------------------
    # connection management
    # ------------------------------------------------------------------
    async def open(self) -> None:
        await asyncio.to_thread(self._open_sync)

    def _open_sync(self) -> None:
        with self._lock:
            if self._conn is not None:
                return
            if self.path != ":memory:":
                Path(self.path).parent.mkdir(parents=True, exist_ok=True)
            conn = sqlite3.connect(self.path, check_same_thread=False, isolation_level=None)
            conn.row_factory = sqlite3.Row
            conn.execute("PRAGMA foreign_keys = ON")       # per-connection: must be set here
            conn.execute("PRAGMA busy_timeout = 5000")
            conn.executescript(self.schema_path.read_text(encoding="utf-8"))
            self._conn = conn
            log.info("database ready: %s", self.path)

    async def close(self) -> None:
        def _close() -> None:
            with self._lock:
                if self._conn is not None:
                    self._conn.close()
                    self._conn = None
        await asyncio.to_thread(_close)

    def _need(self) -> sqlite3.Connection:
        if self._conn is None:
            raise RuntimeError("Database is not open; call await db.open() first")
        return self._conn

    async def _run(self, fn: Callable[[sqlite3.Connection], Any]) -> Any:
        def runner() -> Any:
            with self._lock:
                return fn(self._need())
        return await asyncio.to_thread(runner)

    # ------------------------------------------------------------------
    # generic helpers
    # ------------------------------------------------------------------
    async def execute(self, sql: str, params: Sequence[Any] = ()) -> int:
        """Run one write statement (autocommit). Returns lastrowid."""
        return await self._run(lambda c: c.execute(sql, params).lastrowid)

    async def fetchone(self, sql: str, params: Sequence[Any] = ()) -> dict[str, Any] | None:
        def fn(c: sqlite3.Connection) -> dict[str, Any] | None:
            row = c.execute(sql, params).fetchone()
            return dict(row) if row else None
        return await self._run(fn)

    async def fetchall(self, sql: str, params: Sequence[Any] = ()) -> list[dict[str, Any]]:
        return await self._run(lambda c: [dict(r) for r in c.execute(sql, params).fetchall()])

    async def transaction(self, fn: Callable[[sqlite3.Connection], Any]) -> Any:
        """Run `fn(conn)` inside BEGIN IMMEDIATE ... COMMIT (ROLLBACK on error)."""
        def wrapped(c: sqlite3.Connection) -> Any:
            c.execute("BEGIN IMMEDIATE")
            try:
                result = fn(c)
            except BaseException:
                c.execute("ROLLBACK")
                raise
            c.execute("COMMIT")
            return result
        return await self._run(wrapped)

    async def backup(self, dest: Path) -> Path:
        """Consistent online copy of the database file."""
        def fn(c: sqlite3.Connection) -> Path:
            dest.parent.mkdir(parents=True, exist_ok=True)
            target = sqlite3.connect(str(dest))
            try:
                c.backup(target)
            finally:
                target.close()
            return dest
        return await self._run(fn)

    # ------------------------------------------------------------------
    # 1. owner config
    # ------------------------------------------------------------------
    async def set_config(self, key: str, value: str) -> None:
        await self.execute(
            "INSERT INTO owner_config(key, value, updated_at) VALUES (?, ?, datetime('now')) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=datetime('now')", (key, value))

    async def get_config(self, key: str, default: str | None = None) -> str | None:
        row = await self.fetchone("SELECT value FROM owner_config WHERE key=?", (key,))
        return row["value"] if row else default

    # ------------------------------------------------------------------
    # 2. source channels
    # ------------------------------------------------------------------
    async def add_source_channel(self, link: str, username: str | None = None, title: str | None = None) -> int:
        row = await self.fetchone("SELECT id FROM source_channels WHERE link=?", (link,))
        if row:
            await self.execute("UPDATE source_channels SET is_active=1 WHERE id=?", (row["id"],))
            return row["id"]
        return await self.execute(
            "INSERT INTO source_channels(link, username, title) VALUES (?, ?, ?)", (link, username, title))

    async def list_source_channels(self, active_only: bool = True) -> list[dict[str, Any]]:
        sql = "SELECT * FROM source_channels" + (" WHERE is_active=1" if active_only else "") + " ORDER BY id"
        return await self.fetchall(sql)

    async def get_source_channel(self, link: str) -> dict[str, Any] | None:
        return await self.fetchone("SELECT * FROM source_channels WHERE link=?", (link,))

    async def deactivate_source_channel(self, link: str) -> bool:
        """Sources are kept (poems reference them); removal just turns scanning off."""
        def fn(c: sqlite3.Connection) -> bool:
            return c.execute("UPDATE source_channels SET is_active=0 WHERE link=? AND is_active=1", (link,)).rowcount > 0
        return await self._run(fn)

    async def update_scan_state(self, channel_id: int, last_message_id: int) -> None:
        await self.execute(
            "UPDATE source_channels SET last_message_id=MAX(last_message_id, ?), last_scan_at=datetime('now') WHERE id=?",
            (last_message_id, channel_id))

    # ------------------------------------------------------------------
    # 3. poems
    # ------------------------------------------------------------------
    async def insert_poem(self, channel_id: int, message_id: int, raw_text: str, normalized: str, text_hash: str,
                          *, original_link: str | None = None, language: str = "my", has_media: bool = False,
                          media_info: str | None = None, status: str = "new") -> int | None:
        """Insert a poem; returns None if this source message is already stored."""
        def fn(c: sqlite3.Connection) -> int | None:
            try:
                return c.execute(
                    "INSERT INTO poems(source_channel_id, source_message_id, original_link, raw_text, normalized_text,"
                    " text_hash, language, has_media, media_info, status) VALUES (?,?,?,?,?,?,?,?,?,?)",
                    (channel_id, message_id, original_link, raw_text, normalized, text_hash, language,
                     int(has_media), media_info, status)).lastrowid
            except sqlite3.IntegrityError:
                return None
        return await self._run(fn)

    async def get_poem(self, poem_id: int) -> dict[str, Any] | None:
        return await self.fetchone("SELECT * FROM poems WHERE id=?", (poem_id,))

    async def get_poem_by_source(self, channel_id: int, message_id: int) -> dict[str, Any] | None:
        return await self.fetchone(
            "SELECT * FROM poems WHERE source_channel_id=? AND source_message_id=?", (channel_id, message_id))

    async def find_poem_by_hash(self, text_hash: str) -> dict[str, Any] | None:
        return await self.fetchone(
            "SELECT * FROM poems WHERE text_hash=? AND status<>'duplicate' ORDER BY id LIMIT 1", (text_hash,))

    async def set_poem_status(self, poem_id: int, status: str) -> None:
        await self.execute("UPDATE poems SET status=? WHERE id=?", (status, poem_id))

    async def list_poems(self, status: str, limit: int = 50) -> list[dict[str, Any]]:
        return await self.fetchall("SELECT * FROM poems WHERE status=? ORDER BY id LIMIT ?", (status, limit))

    async def count_poems_by_status(self) -> dict[str, int]:
        rows = await self.fetchall("SELECT status, COUNT(*) AS n FROM poems GROUP BY status")
        return {r["status"]: r["n"] for r in rows}

    async def poem_index_rows(self) -> list[dict[str, Any]]:
        """(id, normalized_text) of every poem that is not itself a duplicate."""
        return await self.fetchall("SELECT id, normalized_text FROM poems WHERE status<>'duplicate'")

    async def candidate_poems(self, limit: int = 500) -> list[dict[str, Any]]:
        rows = await self.fetchall(
            "SELECT p.id, p.raw_text, p.original_link, p.source_channel_id, p.collected_at, a.emotions, a.categories, "
            "a.quality_score, a.quality_notes, c.credit_status, c.credit_text, c.credit_confidence, c.author_id "
            "FROM poems p JOIN poem_analysis a ON a.poem_id=p.id LEFT JOIN poem_credits c ON c.poem_id=p.id "
            "WHERE p.status='analyzed' ORDER BY p.id LIMIT ?", (limit,))
        for r in rows:
            r["emotions"] = _loads(r["emotions"], [])
            r["categories"] = _loads(r["categories"], [])
        return rows

    # ------------------------------------------------------------------
    # 4-6. analysis, duplicates, authors, credits
    # ------------------------------------------------------------------
    async def save_analysis(self, poem_id: int, emotions: list, categories: list, quality_score: float,
                            quality_notes: str, model_used: str) -> None:
        await self.execute(
            "INSERT INTO poem_analysis(poem_id, emotions, categories, quality_score, quality_notes, model_used) "
            "VALUES (?,?,?,?,?,?) ON CONFLICT(poem_id) DO UPDATE SET emotions=excluded.emotions, "
            "categories=excluded.categories, quality_score=excluded.quality_score, "
            "quality_notes=excluded.quality_notes, model_used=excluded.model_used, analyzed_at=datetime('now')",
            (poem_id, json.dumps(emotions, ensure_ascii=False), json.dumps(categories, ensure_ascii=False),
             quality_score, quality_notes, model_used))

    async def get_analysis(self, poem_id: int) -> dict[str, Any] | None:
        row = await self.fetchone("SELECT * FROM poem_analysis WHERE poem_id=?", (poem_id,))
        if row:
            row["emotions"] = _loads(row["emotions"], [])
            row["categories"] = _loads(row["categories"], [])
        return row

    async def add_duplicate(self, poem_id: int, duplicate_of_id: int, dup_type: str, similarity: float) -> None:
        await self.execute(
            "INSERT OR IGNORE INTO duplicate_records(poem_id, duplicate_of_id, dup_type, similarity) VALUES (?,?,?,?)",
            (poem_id, duplicate_of_id, dup_type, similarity))

    async def get_or_create_author(self, name: str) -> int:
        await self.execute("INSERT OR IGNORE INTO authors(name) VALUES (?)", (name,))
        row = await self.fetchone("SELECT id FROM authors WHERE name=?", (name,))
        assert row is not None
        return row["id"]

    async def save_credit(self, poem_id: int, status: str, author_name: str | None, credit_text: str | None,
                          confidence: float, source_link: str | None) -> None:
        author_id = await self.get_or_create_author(author_name) if (status == "known" and author_name) else None
        await self.execute(
            "INSERT INTO poem_credits(poem_id, author_id, credit_text, credit_status, credit_confidence, source_link) "
            "VALUES (?,?,?,?,?,?) ON CONFLICT(poem_id) DO UPDATE SET author_id=excluded.author_id, "
            "credit_text=excluded.credit_text, credit_status=excluded.credit_status, "
            "credit_confidence=excluded.credit_confidence, source_link=excluded.source_link",
            (poem_id, author_id, credit_text, status, confidence, source_link))

    async def get_credit(self, poem_id: int) -> dict[str, Any] | None:
        return await self.fetchone(
            "SELECT c.*, a.name AS author_name FROM poem_credits c LEFT JOIN authors a ON a.id=c.author_id "
            "WHERE c.poem_id=?", (poem_id,))

    # ------------------------------------------------------------------
    # 7. images
    # ------------------------------------------------------------------
    async def add_image(self, poem_id: int | None, url: str, source: str, *, license: str = "", attribution: str = "",
                        width: int = 0, height: int = 0, match_score: float | None = None,
                        search_query: str = "") -> int:
        row = await self.fetchone("SELECT id FROM images WHERE poem_id IS ? AND url=?", (poem_id, url))
        if row:
            return row["id"]
        return await self.execute(
            "INSERT INTO images(poem_id, url, source, license, attribution, width, height, match_score, search_query) "
            "VALUES (?,?,?,?,?,?,?,?,?)",
            (poem_id, url, source, license, attribution, width, height, match_score, search_query))

    async def get_image(self, image_id: int) -> dict[str, Any] | None:
        return await self.fetchone("SELECT * FROM images WHERE id=?", (image_id,))

    async def list_images_for_poem(self, poem_id: int) -> list[dict[str, Any]]:
        return await self.fetchall(
            "SELECT * FROM images WHERE poem_id=? AND is_valid=1 ORDER BY match_score DESC, id", (poem_id,))

    async def set_image_hash(self, image_id: int, image_hash: str) -> None:
        await self.execute("UPDATE images SET image_hash=? WHERE id=?", (image_hash, image_id))

    async def invalidate_image(self, image_id: int) -> None:
        await self.execute("UPDATE images SET is_valid=0 WHERE id=?", (image_id,))

    async def image_in_use(self, url: str | None = None, image_hash: str | None = None, exclude_id: int | None = None) -> bool:
        """True if this URL/hash is attached to a post that is not rejected/cancelled/failed."""
        row = await self.fetchone(
            "SELECT 1 AS used FROM scheduled_posts sp JOIN images i ON i.id=sp.image_id "
            "WHERE sp.status NOT IN ('rejected','cancelled','failed') AND i.id IS NOT ? "
            "AND ((? IS NOT NULL AND i.url=?) OR (? IS NOT NULL AND i.image_hash=?)) LIMIT 1",
            (exclude_id, url, url, image_hash, image_hash))
        return row is not None

    # ------------------------------------------------------------------
    # 8. content plans
    # ------------------------------------------------------------------
    async def upsert_plan(self, plan_date: str, target_category: str, post_count: int = 1,
                          notes: str = "", created_by: str = "agent") -> int:
        await self.execute(
            "INSERT INTO content_plans(plan_date, target_category, post_count, notes, created_by) VALUES (?,?,?,?,?) "
            "ON CONFLICT(plan_date, target_category) DO UPDATE SET post_count=excluded.post_count, "
            "notes=excluded.notes, created_by=excluded.created_by", (plan_date, target_category, post_count, notes, created_by))
        row = await self.fetchone("SELECT id FROM content_plans WHERE plan_date=? AND target_category=?", (plan_date, target_category))
        assert row is not None
        return row["id"]

    async def get_plans(self, plan_date: str) -> list[dict[str, Any]]:
        return await self.fetchall("SELECT * FROM content_plans WHERE plan_date=? ORDER BY id", (plan_date,))

    async def clear_plans(self, plan_date: str, created_by: str = "agent") -> None:
        await self.execute("DELETE FROM content_plans WHERE plan_date=? AND created_by=?", (plan_date, created_by))

    # ------------------------------------------------------------------
    # 9-10. scheduled posts and approvals
    # ------------------------------------------------------------------
    async def create_post(self, poem_id: int, image_id: int | None, caption: str, scheduled_at: str | None,
                          plan_id: int | None = None, status: str = "pending_approval") -> int:
        """Create a post and its pending approval request in one transaction."""
        def fn(c: sqlite3.Connection) -> int:
            pid = c.execute(
                "INSERT INTO scheduled_posts(poem_id, image_id, plan_id, caption, scheduled_at, status) VALUES (?,?,?,?,?,?)",
                (poem_id, image_id, plan_id, caption, scheduled_at, status)).lastrowid
            c.execute("INSERT INTO approvals(post_id, decision) VALUES (?, 'pending')", (pid,))
            c.execute("UPDATE poems SET status='selected' WHERE id=?", (poem_id,))
            return int(pid)
        return await self.transaction(fn)

    async def get_post(self, post_id: int) -> dict[str, Any] | None:
        return await self.fetchone("SELECT * FROM scheduled_posts WHERE id=?", (post_id,))

    async def update_post(self, post_id: int, **fields: Any) -> None:
        allowed = {"image_id", "caption", "scheduled_at", "status", "plan_id"}
        bad = set(fields) - allowed
        if bad:
            raise ValueError(f"cannot update fields: {sorted(bad)}")
        if not fields:
            return
        sets = ", ".join(f"{k}=?" for k in fields)
        await self.execute(f"UPDATE scheduled_posts SET {sets}, updated_at=datetime('now') WHERE id=?",
                           (*fields.values(), post_id))

    async def list_posts(self, statuses: Iterable[str], limit: int = 100) -> list[dict[str, Any]]:
        st = list(statuses)
        marks = ",".join("?" for _ in st)
        return await self.fetchall(
            f"SELECT * FROM scheduled_posts WHERE status IN ({marks}) ORDER BY COALESCE(scheduled_at, created_at), id LIMIT ?",
            (*st, limit))

    async def due_posts(self, now_db: str) -> list[dict[str, Any]]:
        return await self.fetchall(
            "SELECT * FROM scheduled_posts WHERE status IN ('approved','scheduled') AND "
            "(scheduled_at IS NULL OR scheduled_at<=?) ORDER BY COALESCE(scheduled_at, created_at), id", (now_db,))

    async def count_posts_by_status(self) -> dict[str, int]:
        rows = await self.fetchall("SELECT status, COUNT(*) AS n FROM scheduled_posts GROUP BY status")
        return {r["status"]: r["n"] for r in rows}

    async def claim_post(self, post_id: int, from_statuses: Iterable[str], to_status: str) -> bool:
        """Atomically move a post to `to_status` only if it is currently in one of `from_statuses`."""
        st = list(from_statuses)
        marks = ",".join("?" for _ in st)

        def fn(c: sqlite3.Connection) -> bool:
            return c.execute(
                f"UPDATE scheduled_posts SET status=?, updated_at=datetime('now') WHERE id=? AND status IN ({marks})",
                (to_status, post_id, *st)).rowcount == 1
        return await self._run(fn)

    async def posts_in_range(self, start_db: str, end_db: str) -> list[dict[str, Any]]:
        return await self.fetchall(
            "SELECT * FROM scheduled_posts WHERE status IN ('pending_approval','approved','scheduled','publishing','published') "
            "AND scheduled_at>=? AND scheduled_at<? ORDER BY scheduled_at", (start_db, end_db))

    async def stuck_posts(self, older_than_db: str) -> list[dict[str, Any]]:
        return await self.fetchall(
            "SELECT * FROM scheduled_posts WHERE status='publishing' AND updated_at<=?", (older_than_db,))

    async def posts_near(self, when_db: str, minutes: int = 30) -> list[dict[str, Any]]:
        return await self.fetchall(
            "SELECT * FROM scheduled_posts WHERE status IN ('pending_approval','approved','scheduled','publishing') "
            "AND scheduled_at IS NOT NULL AND ABS(strftime('%s', scheduled_at) - strftime('%s', ?)) < ?",
            (when_db, minutes * 60))

    async def decide_approval(self, post_id: int, decision: str, owner_message: str = "") -> None:
        """Record the owner's decision on the newest approval row of a post."""
        await self.execute(
            "UPDATE approvals SET decision=?, owner_message=?, decided_at=datetime('now') WHERE id="
            "(SELECT id FROM approvals WHERE post_id=? ORDER BY id DESC LIMIT 1)", (decision, owner_message, post_id))

    async def latest_approval(self, post_id: int) -> dict[str, Any] | None:
        return await self.fetchone("SELECT * FROM approvals WHERE post_id=? ORDER BY id DESC LIMIT 1", (post_id,))

    # ------------------------------------------------------------------
    # 11-12. publishing history and stats
    # ------------------------------------------------------------------
    async def record_publish(self, post_id: int, channel_id: str, status: str, telegram_message_id: int | None = None,
                             error: str | None = None, attempt: int = 1) -> int:
        return await self.execute(
            "INSERT INTO publishing_history(post_id, channel_id, telegram_message_id, status, error_message, attempt) "
            "VALUES (?,?,?,?,?,?)", (post_id, channel_id, telegram_message_id, status, error, attempt))

    async def get_success_publish(self, post_id: int) -> dict[str, Any] | None:
        return await self.fetchone(
            "SELECT * FROM publishing_history WHERE post_id=? AND status='success'", (post_id,))

    async def count_failed_attempts(self, post_id: int) -> int:
        row = await self.fetchone(
            "SELECT COUNT(*) AS n FROM publishing_history WHERE post_id=? AND status='failed'", (post_id,))
        return int(row["n"]) if row else 0

    async def add_stats(self, publishing_id: int, views: int, reactions: int, forwards: int) -> None:
        await self.execute("INSERT INTO post_stats(publishing_id, views, reactions, forwards) VALUES (?,?,?,?)",
                           (publishing_id, views, reactions, forwards))

    async def published_since(self, since_db: str) -> list[dict[str, Any]]:
        return await self.fetchall(
            "SELECT * FROM publishing_history WHERE status='success' AND telegram_message_id IS NOT NULL "
            "AND published_at>=? ORDER BY id", (since_db,))

    async def performance_rows(self, since_db: str) -> list[dict[str, Any]]:
        rows = await self.fetchall(
            "SELECT ph.id AS publishing_id, ph.post_id, ph.published_at, a.categories, a.emotions, a.quality_score, "
            "(SELECT views FROM post_stats s WHERE s.publishing_id=ph.id ORDER BY s.id DESC LIMIT 1) AS views, "
            "(SELECT reactions FROM post_stats s WHERE s.publishing_id=ph.id ORDER BY s.id DESC LIMIT 1) AS reactions, "
            "(SELECT forwards FROM post_stats s WHERE s.publishing_id=ph.id ORDER BY s.id DESC LIMIT 1) AS forwards "
            "FROM publishing_history ph JOIN scheduled_posts sp ON sp.id=ph.post_id "
            "JOIN poem_analysis a ON a.poem_id=sp.poem_id WHERE ph.status='success' AND ph.published_at>=? "
            "ORDER BY ph.id", (since_db,))
        for r in rows:
            r["categories"] = _loads(r["categories"], [])
            r["emotions"] = _loads(r["emotions"], [])
        return rows

    async def recent_posts_analysis(self, limit: int = 8) -> list[dict[str, Any]]:
        """Categories/emotions of the latest non-cancelled posts (for diversity control)."""
        rows = await self.fetchall(
            "SELECT sp.id AS post_id, sp.status, a.categories, a.emotions FROM scheduled_posts sp "
            "JOIN poem_analysis a ON a.poem_id=sp.poem_id "
            "WHERE sp.status IN ('pending_approval','approved','scheduled','publishing','published') "
            "ORDER BY sp.id DESC LIMIT ?", (limit,))
        for r in rows:
            r["categories"] = _loads(r["categories"], [])
            r["emotions"] = _loads(r["emotions"], [])
        return rows

    # ------------------------------------------------------------------
    # 13-14. memory and feedback
    # ------------------------------------------------------------------
    async def add_memory(self, memory_type: str, content: str, mem_key: str | None = None,
                         importance: int = 1, expires_at: str | None = None) -> int:
        return await self.execute(
            "INSERT INTO agent_memory(memory_type, mem_key, content, importance, expires_at) VALUES (?,?,?,?,?)",
            (memory_type, mem_key, content, importance, expires_at))

    async def upsert_memory(self, memory_type: str, mem_key: str, content: str, importance: int = 1,
                            expires_at: str | None = None) -> int:
        row = await self.fetchone("SELECT id FROM agent_memory WHERE memory_type=? AND mem_key=?", (memory_type, mem_key))
        if row:
            await self.execute(
                "UPDATE agent_memory SET content=?, importance=?, expires_at=?, created_at=datetime('now') WHERE id=?",
                (content, importance, expires_at, row["id"]))
            return row["id"]
        return await self.add_memory(memory_type, content, mem_key, importance, expires_at)

    async def list_memory(self, memory_type: str, key_prefix: str | None = None, limit: int = 50) -> list[dict[str, Any]]:
        """Newest first; expired rows are excluded."""
        now = to_db(utcnow())
        sql = "SELECT * FROM agent_memory WHERE memory_type=? AND (expires_at IS NULL OR expires_at>?)"
        params: list[Any] = [memory_type, now]
        if key_prefix is not None:
            sql += " AND mem_key LIKE ?"
            params.append(key_prefix.replace("%", "") + "%")
        sql += " ORDER BY importance DESC, id DESC LIMIT ?"
        params.append(limit)
        return await self.fetchall(sql, params)

    async def delete_memory_key(self, memory_type: str, mem_key: str) -> None:
        await self.execute("DELETE FROM agent_memory WHERE memory_type=? AND mem_key=?", (memory_type, mem_key))

    async def purge_expired_memory(self) -> int:
        def fn(c: sqlite3.Connection) -> int:
            return c.execute("DELETE FROM agent_memory WHERE expires_at IS NOT NULL AND expires_at<=?",
                             (to_db(utcnow()),)).rowcount
        return await self._run(fn)

    async def trim_memory(self, memory_type: str, keep: int) -> None:
        await self.execute(
            "DELETE FROM agent_memory WHERE memory_type=? AND id NOT IN "
            "(SELECT id FROM agent_memory WHERE memory_type=? ORDER BY id DESC LIMIT ?)", (memory_type, memory_type, keep))

    async def add_feedback(self, owner_text: str, parsed_intent: str | None, parsed_params: dict | None = None,
                           post_id: int | None = None, poem_id: int | None = None, applied: bool = False) -> int:
        return await self.execute(
            "INSERT INTO feedback_records(post_id, poem_id, owner_text, parsed_intent, parsed_params, applied) "
            "VALUES (?,?,?,?,?,?)",
            (post_id, poem_id, owner_text, parsed_intent, json.dumps(parsed_params or {}, ensure_ascii=False), int(applied)))

    # ------------------------------------------------------------------
    # 15-16. task and error logs
    # ------------------------------------------------------------------
    async def start_task(self, task_type: str, input_data: dict | None = None, parent_id: int | None = None) -> int:
        return await self.execute(
            "INSERT INTO task_logs(task_type, state, input_data, parent_task_id, started_at) "
            "VALUES (?, 'running', ?, ?, datetime('now'))",
            (task_type, json.dumps(input_data or {}, ensure_ascii=False, default=str), parent_id))

    async def finish_task(self, task_id: int, state: str = "done", result: dict | None = None) -> None:
        await self.execute(
            "UPDATE task_logs SET state=?, result_data=?, finished_at=datetime('now') WHERE id=?",
            (state, json.dumps(result or {}, ensure_ascii=False, default=str), task_id))

    async def log_error(self, module: str, message: str, traceback: str | None = None,
                        level: str = "error", task_id: int | None = None) -> None:
        try:
            await self.execute("INSERT INTO error_logs(module, level, message, traceback, task_id) VALUES (?,?,?,?,?)",
                               (module, level, message[:2000], traceback, task_id))
        except Exception:  # never let error logging crash the caller
            log.exception("could not write error log")

    async def count_errors_since(self, since_db: str) -> int:
        row = await self.fetchone("SELECT COUNT(*) AS n FROM error_logs WHERE created_at>=?", (since_db,))
        return int(row["n"]) if row else 0
