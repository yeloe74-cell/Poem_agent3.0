"""End-to-end flows: Burmese owner message -> agent -> modules -> fake Telegram."""
import asyncio
import tempfile
import unittest
from pathlib import Path

from core.time_utils import to_db, utcnow
from datetime import timedelta
from tests.fakes import image_routes, make_app, seed_poems


class AgentFlow(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.app = await make_app(self.tmp, QUEUE_TARGET="2")
        image_routes(self.app.transport, 8)
        await seed_poems(self.app)
        self.tg, self.db, self.agent = self.app.tg, self.app.db, self.app.agent

    async def asyncTearDown(self):
        await self.db.close()

    async def say(self, text):
        await self.agent.on_owner_text(text)
        return self.tg.sent[-1]

    async def post(self, pid):
        return await self.db.get_post(pid)

    async def test_three_previews_then_approval_schedules_not_publishes(self):
        await self.say("ကဗျာ ၃ ပုဒ်ပြင်ပေး")
        self.assertEqual(len(self.tg.previews), 3)
        self.assertEqual(len({b.poem_id for b in self.tg.previews}), 3)
        last = self.tg.previews[-1].post_id
        reply = await self.say("တင်လိုက်")
        self.assertEqual((await self.post(last))["status"], "scheduled")
        self.assertEqual(self.tg.published, [])
        self.assertIn("တင်ပေးပါမယ်", reply)

    async def test_publish_now_words_publish_immediately(self):
        await self.say("ကဗျာ ၁ ပုဒ်ပြင်ပေး")
        pid = self.tg.previews[-1].post_id
        reply = await self.say("ချက်ချင်း တင်လိုက်")
        self.assertEqual((await self.post(pid))["status"], "published")
        self.assertEqual(len(self.tg.published), 1)
        self.assertIn("တင်ပြီးပါပြီ", reply)
        self.assertIn((pid, "✅ တင်ပြီးပါပြီ"), self.tg.marks)

    async def test_nothing_is_published_without_owner_words(self):
        await self.say("ကဗျာ ၂ ပုဒ်ပြင်ပေး")
        await self.say("ကောင်းတယ်နော်")                      # praise is not approval
        await self.agent.schedule_tick()
        self.assertEqual(self.tg.published, [])

    async def test_button_pressed_twice_publishes_once(self):
        b = await self.app.channels.prepare_post()           # no planned time -> publishes on approval
        await self.agent._send_preview(b)
        await self.agent.on_callback(f"ap:{b.post_id}")
        first = self.tg.sent[-1]
        await self.agent.on_callback(f"ap:{b.post_id}")
        self.assertEqual(len(self.tg.published), 1)
        self.assertIn("တင်ပြီးပါပြီ", first)

    async def test_reject_gets_replacement_and_feedback(self):
        await self.say("ကဗျာ ၁ ပုဒ်ပြင်ပေး")
        first = self.tg.previews[-1]
        reply = await self.say("ဒီတစ်ပုဒ်မကြိုက်ဘူး")
        self.assertEqual(len(self.tg.previews), 2)
        self.assertNotEqual(self.tg.previews[-1].poem_id, first.poem_id)
        self.assertEqual((await self.db.get_poem(first.poem_id))["status"], "rejected")
        self.assertEqual((await self.post(first.post_id))["status"], "rejected")
        fb = await self.db.fetchall("SELECT * FROM feedback_records")
        self.assertEqual((len(fb), fb[0]["parsed_intent"]), (1, "reject"))
        self.assertIn("နောက်တစ်ပုဒ်", reply)

    async def test_next_poem_keeps_old_poem_available(self):
        await self.say("ကဗျာ ၁ ပုဒ်ပြင်ပေး")
        first = self.tg.previews[-1]
        await self.say("နောက်တစ်ပုဒ်ပြ")
        self.assertNotEqual(self.tg.previews[-1].poem_id, first.poem_id)
        self.assertEqual((await self.db.get_poem(first.poem_id))["status"], "analyzed")

    async def test_change_image_swaps_image(self):
        await self.say("ကဗျာ ၁ ပုဒ်ပြင်ပေး")
        pid = self.tg.previews[-1].post_id
        before = (await self.post(pid))["image_id"]
        await self.say("ပုံပြောင်းပေး")
        self.assertNotEqual((await self.post(pid))["image_id"], before)
        self.assertEqual(len(self.tg.previews), 2)

    async def test_avoid_image_style_is_remembered_permanently(self):
        await self.say("ကဗျာ ၁ ပုဒ်ပြင်ပေး")
        await self.say("နောက်တစ်ခါ ဒီလိုပုံမျိုး မသုံးနဲ့")
        self.assertEqual((await self.app.memory.active_avoidances())["image_style"], ["rainy window"])

    async def test_too_many_longing_avoids_it_in_next_picks(self):
        await self.say("အလွမ်းကဗျာတွေ များနေပြီ")
        self.assertEqual((await self.app.memory.active_avoidances())["emotion"], ["longing"])
        await self.say("ကဗျာ ၃ ပုဒ်ပြင်ပေး")
        for b in self.tg.previews:
            analysis = await self.db.get_analysis(b.poem_id)
            self.assertNotEqual(analysis["emotions"][0]["name"], "longing")

    async def test_remove_source_needs_confirmation(self):
        reply = await self.say("@poemsource ကို ဖယ်လိုက်")
        self.assertIn("တကယ်", reply)
        self.assertEqual(len(await self.db.list_source_channels()), 1)
        await self.say("မလုပ်နဲ့")
        self.assertEqual(len(await self.db.list_source_channels()), 1)
        await self.say("@poemsource ကို ဖယ်လိုက်")
        await self.say("ဟုတ်")
        self.assertEqual(await self.db.list_source_channels(), [])

    async def test_yes_without_pending_question_does_nothing(self):
        reply = await self.say("ဟုတ်")
        self.assertEqual(self.tg.published, [])
        self.assertTrue(reply)

    async def test_scheduled_post_goes_out_at_its_time(self):
        await self.db.set_config("auto_prepare", "0")
        await self.say("ကဗျာ ၁ ပုဒ်ပြင်ပေး")
        pid = self.tg.previews[-1].post_id
        await self.say("မနက်ဖြန်အတွက် သိမ်းထားလိုက်")
        self.assertEqual((await self.post(pid))["status"], "scheduled")
        await self.agent.schedule_tick()
        self.assertEqual(self.tg.published, [])
        await self.db.update_post(pid, scheduled_at=to_db(utcnow() - timedelta(minutes=1)))
        await self.agent.schedule_tick()
        self.assertEqual([p.post_id for p in self.tg.published], [pid])
        await self.agent.schedule_tick()
        self.assertEqual(len(self.tg.published), 1)

    async def test_skip_today(self):
        await self.db.set_config("auto_prepare", "0")
        reply = await self.say("ဒီနေ့ မတင်တော့နဲ့")
        self.assertEqual(await self.db.get_config("skip_date"), self.app.channels.local_date_str())
        self.assertIn("မတင်တော့", reply)

    async def test_queue_is_filled_up_to_target_one_per_tick(self):
        await self.agent.schedule_tick()
        self.assertEqual(len(self.tg.previews), 1)
        await self.agent.schedule_tick()
        await self.agent.schedule_tick()
        self.assertEqual(len(self.tg.previews), 2)            # QUEUE_TARGET=2
        self.assertEqual(self.tg.published, [])                # filling never publishes

    async def test_pause_stops_auto_preparation(self):
        await self.say("ခဏရပ်")
        await self.agent.schedule_tick()
        self.assertEqual(self.tg.previews, [])
        await self.say("ပြန်စ")
        await self.agent.schedule_tick()
        self.assertEqual(len(self.tg.previews), 1)

    async def test_overdue_unapproved_post_is_never_published_only_reminded_once(self):
        await self.db.set_config("auto_prepare", "0")
        b = await self.app.channels.prepare_post(scheduled_at=to_db(utcnow() - timedelta(minutes=2)))
        await self.agent.schedule_tick()
        await self.agent.schedule_tick()
        self.assertEqual(self.tg.published, [])
        self.assertEqual(sum("အချိန်ရောက်နေပါပြီ" in s for s in self.tg.sent), 1)

    async def test_out_of_poems_message(self):
        await self.say("ကဗျာ ၁၀ ပုဒ်ပြင်ပေး")
        self.assertEqual(len(self.tg.previews), 4)
        self.assertIn("လျှော့", self.tg.sent[-1])
        await self.say("နောက်တစ်ပုဒ်ပြ")
        self.assertIn("ကျန်တာ မရှိ", self.tg.sent[-1])

    async def test_add_source_validates_links(self):
        self.assertIn("ထည့်လိုက်ပါပြီ", await self.say("https://t.me/newpoems ထည့်ပေး"))
        self.assertEqual(len(await self.db.list_source_channels()), 2)
        self.assertIn("public", await self.say("https://t.me/+AbCdEfGh123 ထည့်ပေး"))

    async def test_status_report_help_and_unknown(self):
        self.assertIn("အခြေအနေ", await self.say("အခြေအနေ"))
        self.assertIn("မရှိသေးပါဘူး", await self.say("စာရင်း"))
        self.assertIn("ကူညီ", await self.say("ကူညီ") + "ကူညီ")
        self.assertIn("နားမလည်", await self.say("ဘာမှမဆိုင်တဲ့စာ"))

    async def test_tool_error_is_logged_and_owner_gets_apology(self):
        async def boom(**kw):
            raise RuntimeError("disk exploded")
        self.app.channels.prepare_post = boom
        reply = await self.say("ကဗျာ ၁ ပုဒ်ပြင်ပေး")
        self.assertIn("မှားသွား", reply)
        errors = await self.db.fetchall("SELECT module, message FROM error_logs")
        self.assertTrue(any("disk exploded" in e["message"] for e in errors))
        tasks = await self.db.fetchall("SELECT state FROM task_logs WHERE task_type='tool:prepare_posts'")
        self.assertEqual(tasks[0]["state"], "failed")

    async def test_every_tool_run_is_logged(self):
        await self.say("ကဗျာ ၁ ပုဒ်ပြင်ပေး")
        rows = await self.db.fetchall("SELECT task_type, state FROM task_logs")
        self.assertIn(("tool:prepare_posts", "done"), [(r["task_type"], r["state"]) for r in rows])

    async def test_conversation_is_remembered(self):
        await self.say("ကူညီ")
        turns = self.app.memory.recent_turns()
        self.assertEqual([t["role"] for t in turns], ["owner", "agent"])

    async def test_loop_survives_errors_and_stops_cleanly(self):
        calls = []

        async def flaky():
            calls.append(1)
            if len(calls) == 1:
                raise RuntimeError("first run fails")

        stop = asyncio.Event()
        task = asyncio.create_task(self.agent._loop("t", flaky, 0.01, stop, False))
        await asyncio.sleep(0.1)
        stop.set()
        await asyncio.wait_for(task, 1)
        self.assertGreaterEqual(len(calls), 2)
        errors = await self.db.fetchall("SELECT module FROM error_logs")
        self.assertIn("agent.t", [e["module"] for e in errors])

    async def test_maintenance_makes_backup_and_keeps_last_seven(self):
        backup_dir = self.app.settings.backup_dir
        backup_dir.mkdir(parents=True, exist_ok=True)
        for i in range(9):
            (backup_dir / f"poem_agent_2020010{i}.db").write_text("old")
        await self.agent.maintenance_tick()
        self.assertEqual(len(list(backup_dir.glob("poem_agent_*.db"))), 7)

    async def test_stats_pipeline_through_agent(self):
        b = await self.app.channels.prepare_post()
        await self.app.channels.approve(b.post_id)
        mid = await self.app.channels.publish(b.post_id, self.tg.publish)
        self.tg.stats[mid] = (120, 9, 3)
        await self.agent.stats_tick()
        self.assertIn("120", await self.say("စာရင်း"))


if __name__ == "__main__":
    unittest.main()
