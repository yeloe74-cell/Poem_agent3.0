"""Regression tests for the 3.0.1 fixes."""
import json
import tempfile
import time
import unittest
from pathlib import Path

from core.ai_brain import UNKNOWN_MESSAGE
from core.models import Intent
from tests.fakes import image_routes, make_app, seed_poems


class V301Fixes(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.app = await make_app(Path(tempfile.mkdtemp()))
        image_routes(self.app.transport, 6)
        await seed_poems(self.app)
        self.tg, self.agent, self.general = self.app.tg, self.app.agent, self.app.agent.general
        self.ai_calls = []

        async def complete(task, system, user, **kw):
            self.ai_calls.append(task)
            return json.dumps({"response": "အထွေထွေအဖြေ", "tool_calls": []}), "fake:m"
        self.app.brain.complete = complete               # switches the general assistant on

    async def asyncTearDown(self):
        await self.app.db.close()

    async def say(self, text):
        await self.agent.on_owner_text(text)
        return self.tg.sent[-1]

    def pending(self, ttl=100.0):
        self.general._pending_workflow_approval = {"workflow_id": "w1", "step_keys": [], "tool_names": ["create_task"],
                                                   "expires_at": time.monotonic() + ttl}

    async def test_unanswered_confirmation_expires(self):
        self.pending(ttl=-1)
        self.assertFalse(self.general.has_pending_confirmation)
        self.assertIsNone(self.general._pending_workflow_approval)

    async def test_poetry_commands_work_while_confirmation_is_pending(self):
        b = await self.app.channels.prepare_post()
        await self.agent._send_preview(b)
        self.pending()
        reply = await self.say("ချက်ချင်း တင်လိုက်")
        self.assertEqual(len(self.tg.published), 1)
        self.assertIn("တင်ပြီးပါပြီ", reply)
        self.assertTrue(self.general.has_pending_confirmation)       # still waiting for its own answer

    async def test_yes_no_still_reach_the_workflow_confirmation(self):
        self.pending()
        self.assertIn("မလုပ်ဆောင်တော့", await self.say("မလုပ်နဲ့"))
        self.assertFalse(self.general.has_pending_confirmation)

    async def test_other_text_gets_a_reminder_not_a_poetry_action(self):
        self.pending()
        reply = await self.say("ဘာမှမဆိုင်တဲ့စာ")
        self.assertIn("Workflow အတည်ပြုချက်", reply)
        self.assertEqual(self.tg.published, [])

    async def test_poetry_clarification_is_kept(self):
        async def ask(text, **k):
            return Intent("unknown", clarification="ဘယ်ပို့စ်ကို ပြောတာလဲ?")
        self.app.brain.parse_owner_message = ask
        self.assertEqual(await self.say("ဒါလေး တင်ပေးပါလား"), "ဘယ်ပို့စ်ကို ပြောတာလဲ?")
        self.assertEqual(self.ai_calls, [])                           # general assistant not called

    async def test_plain_chatter_still_goes_to_general_assistant(self):
        async def chatter(text, **k):
            return Intent("unknown", clarification=UNKNOWN_MESSAGE)
        self.app.brain.parse_owner_message = chatter
        self.assertEqual(await self.say("ဒီနေ့ရာသီဥတု ဘယ်လိုလဲ"), "အထွေထွေအဖြေ")
        self.assertEqual(self.ai_calls, ["conversation"])

    async def test_confirmation_word_detection(self):
        for yes in ("အတည်ပြုလုပ်ဆောင်", "ဟုတ်", " YES ", "မလုပ်နဲ့"):
            self.assertTrue(self.general.is_confirmation_reply(yes), yes)
        for other in ("တင်လိုက်", "ကဗျာ ၃ ပုဒ်ပြင်ပေး", ""):
            self.assertFalse(self.general.is_confirmation_reply(other), other)


if __name__ == "__main__":
    unittest.main()
