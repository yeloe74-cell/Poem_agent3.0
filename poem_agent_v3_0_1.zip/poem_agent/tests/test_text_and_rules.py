import unittest

from core.ai_brain import AIBrain, extract_json
from core.errors import AIError
from core.intent_rules import rule_intent
from core.time_utils import parse_clock_hint, parse_count, parse_hhmm_list, resolve_when, utcnow
from poetry import text_utils as tu


class TextUtils(unittest.TestCase):
    A = "ညနေခင်း မိုးရွာသည်\nအိမ်ပြန်လမ်းမှာ မင်းကိုသတိရ။\n\n#ကဗျာ #အောင်ချိန့်"

    def test_credit_known_from_hashtag(self):
        body, credit = tu.split_credit(self.A)
        self.assertEqual(credit.status, "known")
        self.assertEqual(credit.credit_text, "#အောင်ချိန့်")
        self.assertNotIn("#", body)

    def test_credit_unknown_never_invented(self):
        _, credit = tu.split_credit("မည်သူမှန်းမသိ ကဗျာတစ်ပုဒ်ပါ\n#ကဗျာ #အလွမ်း #poem")
        self.assertEqual(credit.status, "unknown")
        self.assertIsNone(credit.author_name)

    def test_credit_from_dash_line(self):
        _, credit = tu.split_credit("ပထမစာကြောင်း\nဒုတိယစာကြောင်း\n— မောင်သော်ကာ")
        self.assertEqual((credit.status, credit.author_name), ("known", "မောင်သော်ကာ"))

    def test_formatting_differences_hash_equal(self):
        b2 = "ညနေခင်း   မိုးရွာသည် အိမ်ပြန်လမ်းမှာ\n\n မင်းကို သတိရ"
        self.assertEqual(tu.text_hash(tu.compact_text(self.A)), tu.text_hash(tu.compact_text(b2)))

    def test_different_poems_low_similarity(self):
        from tests.fakes import POEMS
        s = tu.compare(tu.compact_text(POEMS["rain"]), tu.compact_text(POEMS["flower"]))
        self.assertLess(s.similarity, 0.5)

    def test_partial_duplicate_detected_by_containment(self):
        full = tu.compact_text("အကြောင်းအရာတစ်ခုကို ရေးထားတဲ့ ကဗျာရှည်တစ်ပုဒ်ရဲ့ ပထမအပိုင်းနဲ့ ဒုတိယအပိုင်း ပြီးတော့ တတိယအပိုင်းပါ")
        part = tu.compact_text("အကြောင်းအရာတစ်ခုကို ရေးထားတဲ့ ကဗျာရှည်တစ်ပုဒ်ရဲ့ ပထမအပိုင်းနဲ့ ဒုတိယအပိုင်း")
        s = tu.compare(part, full)
        self.assertGreaterEqual(s.containment, 0.9)
        self.assertLess(s.length_ratio, 0.9)

    def test_zawgyi_flag(self):
        self.assertTrue(tu.looks_zawgyi("ေကာင္းတယ္"))
        self.assertFalse(tu.looks_zawgyi("မင်္ဂလာပါ ကောင်းတယ်"))

    def test_normalize_strips_marks_but_keeps_burmese(self):
        self.assertEqual(tu.normalize_text("ကောင်း၊ တယ်။ 😀 #tag https://t.me/x"), "ကောင်း တယ်")


class IntentRules(unittest.TestCase):
    def test_blueprint_phrases(self):
        cases = {
            "တင်လိုက်။": "approve", "ဒီတစ်ပုဒ်မကြိုက်ဘူး။": "reject", "နောက်တစ်ပုဒ်ပြ။": "next_poem",
            "ပုံပြောင်းပေး။": "change_image", "မနက်ဖြန်အတွက် သိမ်းထားလိုက်။": "schedule",
            "ဒီနေ့ မတင်တော့နဲ့။": "skip_today", "အလွမ်းကဗျာတွေ များနေပြီ။": "too_many",
            "နောက်တစ်ခါ ဒီလိုပုံမျိုး မသုံးနဲ့။": "avoid_image_style", "ကဗျာ ၃ ပုဒ်ပြင်ပေး": "prepare_posts",
        }
        for text, expected in cases.items():
            self.assertEqual(rule_intent(text).name, expected, text)

    def test_negation_never_approves(self):
        for text in ("မတင်ပါနဲ့", "ဒီနေ့ မတင်ဘူး", "မတင်လိုက်နဲ့"):
            self.assertNotEqual(rule_intent(text).name, "approve", text)

    def test_ambiguous_praise_is_not_approval(self):
        self.assertIsNone(rule_intent("ကောင်းတယ်နော်"))

    def test_too_many_params_and_count(self):
        self.assertEqual(rule_intent("အလွမ်းကဗျာတွေ များနေပြီ").params, {"kind": "emotion", "key": "longing"})
        self.assertEqual(rule_intent("ကဗျာ ၅ ပုဒ်ပြင်ပေး").params["count"], 5)

    def test_confirmation_only_when_waiting(self):
        self.assertIsNone(rule_intent("ဟုတ်"))
        self.assertEqual(rule_intent("ဟုတ်", awaiting_confirm=True).name, "confirm")
        self.assertEqual(rule_intent("မလုပ်နဲ့", awaiting_confirm=True).name, "cancel_confirm")

    def test_source_links(self):
        self.assertEqual(rule_intent("t.me/poems ထည့်ပေး").name, "add_source")
        self.assertEqual(rule_intent("@poemchan ကို ဖယ်လိုက်").name, "remove_source")

    def test_schedule_with_clock(self):
        i = rule_intent("မနက်ဖြန် ည ၇ နာရီ တင်")
        self.assertEqual((i.name, i.params), ("schedule", {"day_offset": 1, "hour": 19, "minute": 0}))


class TimeUtils(unittest.TestCase):
    def test_counts_and_clock(self):
        self.assertEqual(parse_count("ကဗျာ ၃ ပုဒ်"), 3)
        self.assertEqual(parse_count("ကဗျာ နှစ်ပုဒ်"), 2)
        self.assertEqual(parse_clock_hint("နေ့လည် ၂ နာရီ"), (14, 0))
        self.assertEqual(parse_clock_hint("မနက် ၉ နာရီ"), (9, 0))
        self.assertEqual(parse_hhmm_list("19:00, 09:30,bad,25:00"), [(9, 30), (19, 0)])

    def test_resolve_when_tomorrow_default_time(self):
        when = resolve_when({"day_offset": 1}, utcnow(), 390, [(9, 0)])
        self.assertGreater(when, utcnow())


class AIHelpers(unittest.TestCase):
    def test_extract_json_variants(self):
        self.assertEqual(extract_json('```json\n{"a": 1}\n```'), {"a": 1})
        self.assertEqual(extract_json('Sure! {"a": [1, 2]} thanks'), {"a": [1, 2]})
        with self.assertRaises(AIError):
            extract_json("no json here")

    def test_intent_validation_blocks_weak_approve(self):
        weak = AIBrain.validate_intent({"intent": "approve", "confidence": 0.8, "params": {}})
        self.assertEqual(weak.name, "unknown")
        ok = AIBrain.validate_intent({"intent": "approve", "confidence": 0.95, "params": {}})
        self.assertEqual(ok.name, "approve")
        self.assertEqual(AIBrain.validate_intent({"intent": "rm -rf", "confidence": 1}).name, "unknown")
        self.assertEqual(AIBrain.validate_intent({"intent": "confirm", "confidence": 1}).name, "unknown")


if __name__ == "__main__":
    unittest.main()
