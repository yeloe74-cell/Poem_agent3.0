from __future__ import annotations

import asyncio
import unittest

from core.reflection import OutcomeEvaluator
from knowledge.ingestion import KnowledgeIngestor
from memory.episodic_memory import EpisodicMemory
from runtime.agent_runtime import AgentRuntime, RuntimeLimits
from runtime.context_builder import ContextBuilder, ContextSection
from runtime.event_bus import AgentEvent, EventBus
from security.policy_engine import ApprovalVault, PolicyEngine
from security.action_guard import ActionGuard
from tasks.workflow_engine import WorkflowEngine, WorkflowValidationError
from tools.registry import ToolDefinition, ToolRegistry
from security.policy_engine import ActionRisk
from storage.database import Database
from config.settings import Settings
from core.errors import ConfigError
from core.general_agent import GeneralAgent


class RuntimeV3Tests(unittest.IsolatedAsyncioTestCase):
    async def test_event_bus_isolates_handler_failure(self):
        bus = EventBus()
        seen = []
        async def good(event):
            seen.append(event.name)
        async def bad(event):
            raise RuntimeError("expected")
        await bus.subscribe("test", good)
        await bus.subscribe("test", bad)
        result = await bus.publish(AgentEvent("test", {"x": 1}))
        self.assertEqual(result, {"delivered": 1, "failed": 1})
        self.assertEqual(seen, ["test"])
        self.assertEqual(bus.metrics()["published"], 1)
        await bus.close()

    async def test_runtime_respects_step_budget_and_reports_results(self):
        runtime = AgentRuntime(limits=RuntimeLimits(max_steps=2))
        result = await runtime.run([lambda: "one", lambda: "two"])
        self.assertEqual(result["status"], "completed")
        self.assertEqual(result["tool_calls"], 2)
        with self.assertRaises(ValueError):
            await runtime.run([lambda: 1, lambda: 2, lambda: 3])

    async def test_context_builder_redacts_credentials_and_caps_context(self):
        builder = ContextBuilder(total_chars=1200)
        result = builder.build([
            ContextSection("private", "api_key=abc123 and safe note", 1, 500),
            ContextSection("extra", "x" * 2000, 2, 2000),
        ])
        rendered = str(result)
        self.assertNotIn("abc123", rendered)
        self.assertLessEqual(result["characters"], 1200)

    async def test_policy_approval_is_scoped_and_single_use(self):
        vault = ApprovalVault(ttl_seconds=60)
        token = vault.issue("publish", "post-9")
        policy = PolicyEngine({"publish"})
        self.assertFalse(policy.assess("publish", subject="post-9").allowed)
        self.assertTrue(policy.assess("publish", approval_token=token, subject="post-9", vault=vault).allowed)
        self.assertFalse(policy.assess("publish", approval_token=token, subject="post-9", vault=vault).allowed)

    async def test_internal_write_can_be_configured_to_require_approval(self):
        guard = ActionGuard({"create_task"}, auto_allow_internal_write=False)
        blocked = guard.assess("create_task")
        allowed = guard.assess("create_task", owner_confirmed=True, explicitly_allowed=True)
        self.assertFalse(blocked.allowed)
        self.assertTrue(blocked.requires_approval)
        self.assertTrue(allowed.allowed)

    async def test_tool_registry_requires_explicit_approval_for_external(self):
        registry = ToolRegistry()
        registry.register(ToolDefinition("read_status", "Read status", lambda args: "ok", ActionRisk.READ))
        registry.register(ToolDefinition("send_notice", "Send notice", lambda args: "sent", ActionRisk.EXTERNAL))
        read = await registry.execute("read_status", {})
        blocked = await registry.execute("send_notice", {})
        allowed = await registry.execute("send_notice", {}, approved=True)
        self.assertTrue(read.ok)
        self.assertFalse(blocked.ok)
        self.assertTrue(allowed.ok)

    async def test_workflow_persistence_dependencies_and_idempotency(self):
        db = Database(":memory:")
        await db.open()
        try:
            engine = WorkflowEngine(db)
            await engine.initialize()
            workflow = engine.validate("prepare report", [
                {"key": "first", "title": "Collect", "tool": "collect", "arguments": {}},
                {"key": "second", "title": "Summarize", "tool": "summarize", "arguments": {}, "depends_on": ["first"], "requires_approval": True},
            ], ["collect", "summarize"])
            workflow_id = await engine.create(workflow)
            self.assertEqual([x["step_key"] for x in await engine.ready_steps(workflow_id)], ["first"])
            await engine.set_state(workflow_id, "approved")
            async def execute(name, args, idem):
                return {"tool": name, "key": idem}
            result = await engine.execute_ready(workflow_id, execute, approved_tools={"collect"})
            self.assertEqual(result["completed"], ["first"])
            self.assertEqual(result["state"], "paused")
            self.assertTrue(await engine.approve(workflow_id, approved_steps={"second"}))
            resumed = await engine.execute_ready(workflow_id, execute, approved_tools={"summarize"})
            self.assertEqual(resumed["completed"], ["second"])
            self.assertEqual(resumed["state"], "done")
            await engine.save_idempotent_result("scope", "key", {"ok": True})
            self.assertEqual(await engine.idempotent_result("scope", "key"), {"ok": True})
        finally:
            await db.close()

    async def test_workflow_failed_step_can_be_explicitly_retried(self):
        db = Database(":memory:")
        await db.open()
        try:
            engine = WorkflowEngine(db, max_attempts=3)
            await engine.initialize()
            workflow = engine.validate("retry safely", [
                {"key": "step", "title": "Run", "tool": "run", "arguments": {}}
            ], ["run"])
            workflow_id = await engine.create(workflow)
            await engine.set_state(workflow_id, "approved")
            async def broken(name, args, idem):
                raise RuntimeError("temporary failure")
            first = await engine.execute_ready(workflow_id, broken, approved_tools={"run"})
            self.assertEqual(first["state"], "failed")
            snapshot = await engine.get(workflow_id)
            self.assertTrue(await engine.retry_step(snapshot["steps"][0]["id"]))
            async def recovered(name, args, idem):
                return {"recovered": True}
            second = await engine.execute_ready(workflow_id, recovered, approved_tools={"run"})
            self.assertEqual(second["state"], "done")
        finally:
            await db.close()

    async def test_workflow_rejects_unknown_tools_and_bad_dependencies(self):
        engine = WorkflowEngine(object())
        with self.assertRaises(WorkflowValidationError):
            engine.validate("bad", [{"title": "x", "tool": "shell"}], ["read"])
        with self.assertRaises(WorkflowValidationError):
            engine.validate("bad", [{"key": "a", "title": "x", "tool": "read", "depends_on": ["b"]}], ["read"])

    async def test_knowledge_ingestion_is_chunked_and_deterministic(self):
        ingestor = KnowledgeIngestor(chunk_chars=300, overlap_chars=20)
        chunks = ingestor.chunk(("မြန်မာစာ knowledge " * 60), source="manual")
        self.assertGreater(len(chunks), 1)
        self.assertEqual(chunks[0].digest, ingestor.chunk(("မြန်မာစာ knowledge " * 60), source="manual")[0].digest)

    async def test_episodic_memory_blocks_secrets_and_retrieves_notes(self):
        db = Database(":memory:")
        await db.open()
        try:
            memory = EpisodicMemory(db)
            self.assertFalse(await memory.remember("credentials", "api_key=secret"))
            self.assertTrue(await memory.remember("project", "Poem Agent uses SQLite and Telegram", importance=5))
            found = await memory.retrieve("SQLite Telegram")
            self.assertTrue(found)
            self.assertIn("Poem Agent", found[0]["content"])
            self.assertTrue(await memory.forget("project", category="fact"))
            self.assertEqual(await memory.retrieve("SQLite Telegram"), [])
        finally:
            await db.close()

    async def test_general_agent_settings_are_configurable_and_bounded(self):
        settings = Settings.from_env(env={"GENERAL_AGENT_MAX_CALLS": "5", "WORKFLOW_MAX_STEPS": "50"}, base_dir=".")
        self.assertEqual(settings.general_agent_max_calls, 5)
        self.assertEqual(settings.workflow_max_steps, 50)
        with self.assertRaises(ConfigError):
            Settings.from_env(env={"GENERAL_AGENT_MAX_CALLS": "99"}, base_dir=".")
        with self.assertRaises(ConfigError):
            Settings.from_env(env={"GENERAL_AGENT_ENABLED": "maybe"}, base_dir=".")

    async def test_general_agent_requires_owner_confirmation_for_workflow(self):
        class Brain:
            available = True
            async def complete(self, *args, **kwargs):
                return ('{"response":"ok","tool_calls":[]}', "test:model")
        class Memory:
            def recent_turns(self, n=6):
                return []
        db = Database(":memory:")
        await db.open()
        try:
            agent = GeneralAgent(db, Brain(), Memory())
            await agent.initialize()
            workflow = agent.workflows.validate("calculate results in sequence", [
                {"key": "calc", "title": "Calculate first result", "tool": "calculate",
                 "arguments": {"expression": "6*7"}},
                {"key": "calc2", "title": "Calculate dependent result", "tool": "calculate",
                 "arguments": {"expression": "7*7"}, "depends_on": ["calc"], "requires_approval": True}
            ], list(agent._tools))
            workflow_id = await agent.workflows.create(workflow)
            requested = await agent._request_workflow_execution({"workflow_id": workflow_id})
            self.assertTrue(requested.ok)
            self.assertTrue(agent.has_pending_confirmation)
            response = await agent.handle("အတည်ပြုလုပ်ဆောင်")
            self.assertIn("done", response)
            self.assertFalse(agent.has_pending_confirmation)
            state = await agent.workflows.get(workflow_id)
            self.assertEqual([row["state"] for row in state["steps"]], ["done", "done"])
        finally:
            await db.close()

    async def test_knowledge_ingestion_is_connected_to_store(self):
        class Brain:
            available = True
            async def complete(self, *args, **kwargs):
                return ('{"response":"ok","tool_calls":[]}', "test:model")
        class Memory:
            def recent_turns(self, n=6):
                return []
        db = Database(":memory:")
        await db.open()
        try:
            agent = GeneralAgent(db, Brain(), Memory())
            await agent.initialize()
            result = await agent._ingest_knowledge({"content": "Telegram Agent SQLite knowledge " * 30, "source": "test"})
            self.assertTrue(result.ok)
            matches = await agent.knowledge.search("Telegram Agent SQLite")
            self.assertTrue(matches)
        finally:
            await db.close()

    async def test_outcome_evaluator_requires_evidence(self):
        evaluator = OutcomeEvaluator()
        pending = evaluator.evaluate(expected=["post_id", "url"], observed={"status": "done", "post_id": 3})
        verified = evaluator.evaluate(expected=["post_id"], observed={"status": "completed", "post_id": 3})
        self.assertEqual(pending.status, "needs_review")
        self.assertEqual(verified.status, "verified")


if __name__ == "__main__":
    unittest.main()
