from __future__ import annotations

import unittest

from core.general_agent import GeneralAgent, SafeCalculator
from core.planner import Planner, PlanValidationError
from memory.knowledge_store import KnowledgeStore
from security.action_guard import ActionGuard
from storage.database import Database


class FakeMemory:
    def recent_turns(self, n=6):
        return []


class FakeBrain:
    available = True

    async def complete(self, task, system, user, **kwargs):
        return ('{"response":"အဆင်ပြေပါတယ်","tool_calls":[]}', 'fake:model')


class GeneralAgentTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = Database(":memory:")
        await self.db.open()
        self.agent = GeneralAgent(self.db, FakeBrain(), FakeMemory())
        await self.agent.initialize()

    async def asyncTearDown(self):
        await self.db.close()

    async def test_safe_calculator(self):
        self.assertEqual(SafeCalculator.calculate("(12 + 8) * 3"), 60)
        with self.assertRaises(ValueError):
            SafeCalculator.calculate("__import__('os')")

    async def test_task_create_and_update(self):
        result = await self.agent._create_task({"title": "Review code", "priority": 4})
        task_id = result.data["id"]
        changed = await self.agent._update_task({"task_id": task_id, "state": "done"})
        self.assertTrue(changed.ok)
        row = await self.db.fetchone("SELECT state FROM agent_tasks WHERE id=?", (task_id,))
        self.assertEqual(row["state"], "done")

    async def test_secret_is_not_saved(self):
        result = await self.agent._remember({"key": "test", "content": "API_KEY=abc123"})
        self.assertFalse(result.ok)

    async def test_initialize_is_idempotent(self):
        await self.agent.initialize()
        rows = await self.db.fetchall("SELECT name FROM sqlite_master WHERE type='table'")
        names = {row["name"] for row in rows}
        self.assertIn("agent_tasks", names)
        self.assertIn("agent_tool_audit", names)

    async def test_handle_conversation(self):
        self.assertIn("အဆင်ပြေ", await self.agent.handle("မင်္ဂလာပါ"))


class PlannerTests(unittest.TestCase):
    def test_valid_plan(self):
        planner = Planner(FakeBrain(), ["calculate", "list_tasks"])
        plan = planner.validate({"goal": "review", "steps": [
            {"title": "List tasks", "tool": "list_tasks", "arguments": {}, "depends_on": []},
            {"title": "Calculate", "tool": "calculate", "arguments": {"expression": "2+2"}, "depends_on": ["s1"]},
        ]})
        self.assertEqual(len(plan.steps), 2)
        self.assertIn("အလိုအလျောက်", planner.render(plan))

    def test_unlisted_tool_rejected(self):
        planner = Planner(FakeBrain(), ["calculate"])
        with self.assertRaises(PlanValidationError):
            planner.validate({"goal": "x", "steps": [{"title": "bad", "tool": "shell", "arguments": {}}]})

    def test_credentials_rejected(self):
        planner = Planner(FakeBrain(), ["remember"])
        with self.assertRaises(PlanValidationError):
            planner.validate({"goal": "x", "steps": [{"title": "bad", "tool": "remember", "arguments": {"api_key": "x"}}]})


class SecurityAndKnowledgeTests(unittest.IsolatedAsyncioTestCase):
    async def test_guard_requires_approval_for_external_action(self):
        guard = ActionGuard(["calculate", "publish_post"])
        self.assertTrue(guard.assess("calculate").allowed)
        decision = guard.assess("publish_post")
        self.assertFalse(decision.allowed)
        self.assertTrue(decision.requires_approval)

    async def test_knowledge_search(self):
        db = Database(":memory:")
        await db.open()
        try:
            store = KnowledgeStore(db)
            await store.add("bot architecture", "Telegram agent uses SQLite task storage", category="project")
            matches = await store.search("Telegram agent SQLite")
            self.assertTrue(matches)
            self.assertIn("bot architecture", matches[0]["key"])
        finally:
            await db.close()


if __name__ == "__main__":
    unittest.main()
