import tempfile
import unittest
from pathlib import Path

from core.errors import ApprovalRequired, PublishError
from core.time_utils import to_db, utcnow
from datetime import timedelta
from tests.fakes import CHANNEL, POEMS, image_routes, make_app, msg, seed_poems, commons_response


class PoetryEngineTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.app = await make_app(Path(tempfile.mkdtemp()))
        self.cid = await self.app.db.add_source_channel(CHANNEL, "poemsource", "S")

    async def asyncTearDown(self):
        await self.app.db.close()

    async def ingest(self, mid, text):
        return await self.app.poetry.ingest(self.cid, msg(mid, text))

    async def test_new_poem_stored_analysed_with_credit(self):
        r = await self.ingest(1, POEMS["rain"])
        self.assertEqual(r.status, "stored")
        self.assertEqual((await self.app.db.get_poem(r.poem_id))["status"], "analyzed")
        credit = await self.app.db.get_credit(r.poem_id)
        self.assertEqual((credit["credit_status"], credit["credit_text"], credit["author_name"]),
                         ("known", "#အောင်ချိန့်", "အောင်ချိန့်"))
        self.assertEqual(credit["source_link"], f"{CHANNEL}/1")

    async def test_unknown_author_stays_unknown(self):
        r = await self.ingest(1, POEMS["hill"])
        credit = await self.app.db.get_credit(r.poem_id)
        self.assertEqual((credit["credit_status"], credit["author_id"]), ("unknown", None))

    async def test_exact_and_formatting_duplicates(self):
        first = await self.ingest(1, POEMS["rain"])
        again = await self.app.poetry.ingest(self.cid, msg(2, POEMS["rain"]))
        spaced = await self.ingest(3, POEMS["rain"].replace("\n", "  \n ").replace("မိုး", "မိုး "))
        self.assertEqual((again.status, spaced.status), ("duplicate", "duplicate"))
        rows = await self.app.db.fetchall("SELECT dup_type, duplicate_of_id FROM duplicate_records ORDER BY id")
        self.assertEqual([r["dup_type"] for r in rows], ["exact", "formatting"])
        self.assertTrue(all(r["duplicate_of_id"] == first.poem_id for r in rows))
        self.assertEqual((await self.app.db.count_poems_by_status())["analyzed"], 1)

    async def test_minor_word_change_is_similar_duplicate(self):
        await self.ingest(1, POEMS["rain"])
        changed = POEMS["rain"].replace("သတိရနေမိတယ်", "သတိရနေမိပါတယ်")
        r = await self.ingest(2, changed)
        self.assertEqual(r.status, "duplicate")
        row = await self.app.db.fetchone("SELECT dup_type FROM duplicate_records")
        self.assertIn(row["dup_type"], ("minor_change", "similar"))

    async def test_different_poems_are_not_duplicates(self):
        await self.ingest(1, POEMS["rain"])
        self.assertEqual((await self.ingest(2, POEMS["flower"])).status, "stored")

    async def test_partial_duplicate(self):
        long = POEMS["rain"].split("\n\n")[0] + "\n" + POEMS["river"]
        await self.ingest(1, long)
        r = await self.ingest(2, POEMS["river"])
        self.assertEqual(r.status, "duplicate")
        self.assertEqual((await self.app.db.fetchone("SELECT dup_type FROM duplicate_records"))["dup_type"], "partial")

    async def test_short_and_zawgyi_are_filtered(self):
        self.assertEqual((await self.ingest(1, "တိုတို")).status, "skipped")
        z = await self.ingest(2, "ေကာင္းတဲ့ေန႔တစ္ေန႔မွာ ျမန္မာျပည္ရဲ႕ ေတာင္တန္းေတြေပၚမွာ")
        self.assertEqual(z.status, "rejected")
        self.assertEqual((await self.app.db.get_poem(z.poem_id))["language"], "my-zawgyi")

    async def test_ai_failure_leaves_poem_new_then_retry_succeeds(self):
        self.app.brain.fail_analysis = True
        r = await self.ingest(1, POEMS["rain"])
        self.assertEqual((await self.app.db.get_poem(r.poem_id))["status"], "new")
        self.app.brain.fail_analysis = False
        self.assertEqual(await self.app.poetry.process_pending(), 1)
        self.assertEqual((await self.app.db.get_poem(r.poem_id))["status"], "analyzed")

    async def test_borderline_uses_ai_verdict(self):
        # Thresholds widened so a lightly edited copy (similarity ~0.94) lands in the AI-judged band.
        app = await make_app(Path(tempfile.mkdtemp()), DUP_SIMILAR="0.99", DUP_BORDERLINE="0.80")
        cid = await app.db.add_source_channel(CHANNEL, "poemsource", "S")
        base = "ကြယ်တွေရောင်လွှာနေတဲ့ညမှာ မင်းရဲ့အပြုံးကိုမြင်ယောင်မိတယ် အဝေးကခေါ်သံတစ်ခုကြားလို့ နှလုံးသားထဲလှိုက်ခနဲ ဖြစ်သွားတယ်"
        variant = "ကြယ်တွေရောင်လွှာနေတဲ့ညမှာ မင်းရဲ့အပြုံးကိုမြင်ယောင်မိတယ် အဝေးကခေါ်သံတစ်ခုကြားလို့ ရင်ထဲလှိုက်ခနဲ ဖြစ်သွားတယ်"
        await app.poetry.ingest(cid, msg(1, base))
        app.brain.dup_verdict = (False, 0.9)
        self.assertEqual((await app.poetry.ingest(cid, msg(2, variant))).status, "stored")
        self.assertEqual(app.brain.dup_calls, 1)
        app2 = await make_app(Path(tempfile.mkdtemp()), DUP_SIMILAR="0.99", DUP_BORDERLINE="0.80")
        cid2 = await app2.db.add_source_channel(CHANNEL, "poemsource", "S")
        await app2.poetry.ingest(cid2, msg(1, base))
        app2.brain.dup_verdict = (True, 0.9)
        r = await app2.poetry.ingest(cid2, msg(2, variant))
        self.assertEqual(r.status, "duplicate")
        self.assertEqual((await app2.db.fetchone("SELECT dup_type FROM duplicate_records"))["dup_type"], "semantic")
        await app.db.close()
        await app2.db.close()

    async def test_selection_prefers_plan_category_and_avoids_owner_dislikes(self):
        await seed_poems(self.app)
        love = await self.app.poetry.select_poem(target_category="love_poetry")
        self.assertIn("love_poetry", love.poem["categories"])
        sad = await self.app.poetry.select_poem(target_category="sad_poetry")
        self.assertIn("sad_poetry", sad.poem["categories"])
        avoided = await self.app.poetry.select_poem(avoid={"emotion": ["longing"], "category": []})
        self.assertNotEqual(avoided.poem["emotions"][0]["name"], "longing")
        none_left = await self.app.poetry.select_poem(avoid={"emotion": ["longing", "love"], "category": []})
        self.assertIsNone(none_left)

    async def test_scan_stores_only_new_messages(self):
        self.assertEqual(await seed_poems(self.app), 4)
        self.assertEqual(await self.app.agent.scan_once(), {})            # nothing new
        self.app.tg.channels[CHANNEL].append(msg(5, "ကြည်လင်တဲ့ရေပြင်ပေါ်မှာ လေညင်းတိုက်ခတ်တဲ့အခါ ငှက်ကလေးတွေ ပျံသန်းသွားတယ်"))
        self.assertEqual((await self.app.agent.scan_once()).get("stored"), 1)

    async def test_unavailable_source_is_reported_not_fatal(self):
        await seed_poems(self.app)
        self.app.tg.unavailable.add(CHANNEL)
        await self.app.agent.scan_once()
        self.assertTrue(any("ဖတ်လို့မရပါဘူး" in s for s in self.app.tg.sent))


class ImageEngineTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.app = await make_app(Path(tempfile.mkdtemp()))
        image_routes(self.app.transport, 4)
        await seed_poems(self.app, ("rain", "flower"))
        self.poems = await self.app.db.candidate_poems()

    async def asyncTearDown(self):
        await self.app.db.close()

    async def find(self, poem, **kw):
        return await self.app.images.find_for_poem(poem["id"], poem["raw_text"], poem["emotions"], **kw)

    async def test_finds_downloads_and_hashes(self):
        img = await self.find(self.poems[0])
        self.assertIsNotNone(img["image_hash"])
        self.assertTrue(self.app.images.local_file(img["id"]).exists())
        self.assertIn("CC BY-SA", img["license"])

    async def test_license_rules(self):
        im = self.app.images
        for ok in ("CC0", "CC BY 4.0", "CC BY-SA 4.0", "Public domain", "Pexels License", "Unsplash License"):
            self.assertTrue(im.license_ok(ok), ok)
        for bad in ("CC BY-NC 4.0", "CC BY-ND 2.0", "All rights reserved", "", "Fair use"):
            self.assertFalse(im.license_ok(bad), bad)

    async def test_bad_candidates_filtered(self):
        t = self.app.transport
        t.routes.clear()
        t.add("commons.wikimedia.org", commons_response([
            {"name": "nc.jpg", "url": "https://u.example/nc.jpg", "license": "CC BY-NC 4.0"},
            {"name": "tiny.jpg", "url": "https://u.example/tiny.jpg", "w": 50, "h": 50},
            {"name": "http.jpg", "url": "http://u.example/http.jpg"},
        ]))
        self.assertIsNone(await self.find(self.poems[0]))

    async def test_image_not_reused_by_another_post(self):
        first = await self.find(self.poems[0])
        await self.app.db.create_post(self.poems[0]["id"], first["id"], "cap", None)
        second = await self.find(self.poems[1])
        self.assertNotEqual(first["url"], second["url"])
        self.assertNotEqual(first["image_hash"], second["image_hash"])

    async def test_identical_file_with_other_url_is_rejected_by_hash(self):
        t = self.app.transport
        t.routes.clear()
        t.add("commons.wikimedia.org", commons_response([{"name": "a.jpg", "url": "https://u.example/a.jpg"},
                                                         {"name": "b.jpg", "url": "https://u.example/b.jpg"}]))
        t.add("u.example/a.jpg", b"SAMEBYTES", headers={"Content-Type": "image/jpeg"})
        t.add("u.example/b.jpg", b"SAMEBYTES", headers={"Content-Type": "image/jpeg"})
        first = await self.find(self.poems[0])
        await self.app.db.create_post(self.poems[0]["id"], first["id"], "cap", None)
        self.assertIsNone(await self.find(self.poems[1]))

    async def test_daily_budget_stops_new_searches(self):
        app = await make_app(Path(tempfile.mkdtemp()), IMAGE_DAILY_LIMIT="1")
        image_routes(app.transport, 3)
        await seed_poems(app, ("rain", "flower"))
        p = await app.db.candidate_poems()
        self.assertIsNotNone(await app.images.find_for_poem(p[0]["id"], p[0]["raw_text"], p[0]["emotions"]))
        calls_before = len(app.transport.calls)
        self.assertIsNone(await app.images.find_for_poem(p[1]["id"], p[1]["raw_text"], p[1]["emotions"]))
        self.assertEqual(len(app.transport.calls), calls_before)          # no network used
        await app.db.close()

    async def test_source_failure_is_tolerated(self):
        self.app.transport.routes.clear()
        self.assertIsNone(await self.find(self.poems[0]))

    async def test_attribution_only_when_license_requires(self):
        img = {"attribution": "A / Wikimedia", "license": "CC BY-SA 4.0"}
        self.assertIn("📷", self.app.images.caption_credit(img))
        self.assertEqual(self.app.images.caption_credit({"attribution": "x", "license": "Pexels License"}), "")


class ChannelManagerTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.app = await make_app(Path(tempfile.mkdtemp()))
        image_routes(self.app.transport, 6)
        await seed_poems(self.app)
        self.cm = self.app.channels

    async def asyncTearDown(self):
        await self.app.db.close()

    async def prepared(self, **kw):
        b = await self.cm.prepare_post(**kw)
        self.assertIsNotNone(b)
        return b

    async def test_caption_has_poem_verbatim_credit_and_attribution(self):
        b = await self.prepared(category="sad_poetry")
        self.assertIn("မိုးရွာတဲ့ညနေခင်းမှာ", b.text)
        self.assertIn("#အောင်ချိန့်", b.text)
        self.assertIn("📷", b.text)                                     # CC BY-SA needs attribution
        self.assertNotIn("#ကဗျာ", b.text)                                # source's generic tag is not copied
        self.assertIsNotNone(b.image_path)

    async def test_publish_requires_approval(self):
        b = await self.prepared()
        with self.assertRaises(ApprovalRequired):
            await self.cm.publish(b.post_id, self.app.tg.publish)
        self.assertEqual(self.app.tg.published, [])

    async def test_publish_once_even_if_called_twice(self):
        b = await self.prepared()
        self.assertEqual(await self.cm.approve(b.post_id), "publish_now")
        m1 = await self.cm.publish(b.post_id, self.app.tg.publish)
        m2 = await self.cm.publish(b.post_id, self.app.tg.publish)
        self.assertEqual(m1, m2)
        self.assertEqual(len(self.app.tg.published), 1)
        self.assertEqual((await self.app.db.get_poem(b.meta and (await self.app.db.get_post(b.post_id))["poem_id"]))["status"], "posted")
        self.assertEqual(await self.cm.approve(b.post_id), "already")

    async def test_scheduled_post_waits_for_its_time(self):
        when = to_db(utcnow() + timedelta(hours=5))
        b = await self.prepared(scheduled_at=when)
        self.assertEqual(await self.cm.approve(b.post_id), "scheduled")
        self.assertEqual(await self.cm.due_post_ids(), [])
        await self.app.db.update_post(b.post_id, scheduled_at=to_db(utcnow() - timedelta(minutes=1)))
        self.assertEqual(await self.cm.due_post_ids(), [b.post_id])

    async def test_publish_retries_then_succeeds(self):
        b = await self.prepared()
        await self.cm.approve(b.post_id)
        self.app.tg.fail_publish = 2
        await self.cm.publish(b.post_id, self.app.tg.publish)
        rows = await self.app.db.fetchall("SELECT status, attempt FROM publishing_history ORDER BY id")
        self.assertEqual([(r["status"], r["attempt"]) for r in rows], [("failed", 1), ("failed", 2), ("success", 3)])

    async def test_publish_gives_up_and_releases_poem(self):
        b = await self.prepared()
        await self.cm.approve(b.post_id)
        self.app.tg.fail_publish = 9
        with self.assertRaises(PublishError):
            await self.cm.publish(b.post_id, self.app.tg.publish)
        post = await self.app.db.get_post(b.post_id)
        self.assertEqual(post["status"], "failed")
        self.assertEqual((await self.app.db.get_poem(post["poem_id"]))["status"], "analyzed")

    async def test_stuck_publishing_is_failed_not_resent(self):
        b = await self.prepared()
        await self.cm.approve(b.post_id)
        await self.app.db.claim_post(b.post_id, ("approved",), "publishing")
        await self.app.db.execute("UPDATE scheduled_posts SET updated_at='2000-01-01 00:00:00' WHERE id=?", (b.post_id,))
        self.assertEqual(await self.cm.recover_stuck(), [b.post_id])
        self.assertEqual((await self.app.db.get_post(b.post_id))["status"], "failed")
        self.assertEqual(self.app.tg.published, [])

    async def test_replace_after_dislike_rejects_poem_and_picks_another(self):
        b = await self.prepared()
        old_poem = (await self.app.db.get_post(b.post_id))["poem_id"]
        nb = await self.cm.replace_post(b.post_id, dislike=True)
        self.assertNotEqual(nb.poem_id, old_poem)
        self.assertEqual((await self.app.db.get_poem(old_poem))["status"], "rejected")
        self.assertEqual((await self.app.db.get_post(b.post_id))["status"], "rejected")

    async def test_next_poem_releases_old_one(self):
        b = await self.prepared()
        old = (await self.app.db.get_post(b.post_id))["poem_id"]
        nb = await self.cm.replace_post(b.post_id, dislike=False)
        self.assertNotEqual(nb.poem_id, old)
        self.assertEqual((await self.app.db.get_poem(old))["status"], "analyzed")

    async def test_change_image_picks_a_different_one(self):
        b = await self.prepared()
        before = (await self.app.db.get_post(b.post_id))["image_id"]
        nb = await self.cm.change_image(b.post_id)
        after = (await self.app.db.get_post(b.post_id))["image_id"]
        self.assertIsNotNone(nb)
        self.assertNotEqual(before, after)

    async def test_no_poems_returns_none(self):
        for _ in range(4):
            await self.cm.prepare_post()
        self.assertIsNone(await self.cm.prepare_post())

    async def test_skip_today_cancels_and_blocks_slots(self):
        slot = (await self.cm.free_slots(1))[0]
        today_local = self.cm.local_date_str(slot)
        if today_local != self.cm.local_date_str():
            self.skipTest("next slot is not today")
        await self.prepared(scheduled_at=to_db(slot))
        self.assertEqual(await self.cm.skip_today(), 1)
        self.assertFalse(any(self.cm.local_date_str(s) == today_local for s in await self.cm.free_slots(6)))

    async def test_stats_and_report_feed_back_into_selection(self):
        b = await self.prepared(category="sad_poetry")
        await self.cm.approve(b.post_id)
        mid = await self.cm.publish(b.post_id, self.app.tg.publish)
        self.app.tg.stats[mid] = (500, 20, 5)
        self.assertEqual(await self.cm.collect_stats(self.app.tg.fetch_stats), 1)
        report = await self.cm.performance_report()
        self.assertEqual(report["categories"]["sad_poetry"]["avg_views"], 500.0)
        self.assertEqual(report["best_post"]["views"], 500)
        perf = await self.app.poetry._performance_by_category()
        self.assertEqual(perf["sad_poetry"], 1.0)

    async def test_default_plan_follows_weekly_template(self):
        await self.cm.ensure_plans(2)
        self.assertEqual(len(await self.app.db.get_plans(self.cm.local_date_str())), 1)
        await self.cm.set_plan(self.cm.local_date_str(), "nature", 2)
        self.assertEqual(await self.cm.target_category_for(self.cm.local_date_str()), "nature")


if __name__ == "__main__":
    unittest.main()
