import asyncio
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

import main
from config.settings import Settings
from core.errors import ConfigError, PublishError, SourceUnavailable
from core.models import PostBundle
from telegram import telegram_interface as ti
from tests.fakes import FakeTelegram, OWNER, make_settings


class FloodErr(Exception):
    def __init__(self, seconds=1):
        self.seconds = seconds


class StubClient:
    def __init__(self, session, api_id, api_hash):
        self.session, self.handlers, self.sent, self.files = session, [], [], []
        self.entity_error = None
        self.history = []

    async def start(self, bot_token=None): self.started = bot_token
    async def connect(self): ...
    async def is_user_authorized(self): return True
    async def disconnect(self): self.closed = True
    def add_event_handler(self, cb, ev): self.handlers.append((cb, ev))

    async def send_message(self, to, text, **kw):
        if getattr(self, "flood_once", False):
            self.flood_once = False
            raise FloodErr(2)
        self.sent.append((to, text, kw))
        return SimpleNamespace(id=len(self.sent) + 10)

    async def send_file(self, to, path, **kw):
        self.files.append((to, path, kw))
        return SimpleNamespace(id=len(self.files) + 50)

    async def get_entity(self, handle):
        if self.entity_error:
            raise self.entity_error
        return SimpleNamespace(username="poemsource", id=77)

    async def get_messages(self, entity, limit=None, ids=None):
        if ids is not None:
            return [SimpleNamespace(id=i, views=10 * i, forwards=1, reactions=SimpleNamespace(results=[SimpleNamespace(count=2), SimpleNamespace(count=3)])) for i in ids]
        return list(self.history[-limit:][::-1])             # newest first, like Telethon

    async def iter_messages(self, entity, min_id=0, reverse=False, limit=None):
        for m in [m for m in self.history if m.id > min_id][:limit]:
            yield m


def stub_module():
    return SimpleNamespace(
        TelegramClient=StubClient,
        events=SimpleNamespace(NewMessage=lambda **k: ("new", k), CallbackQuery=lambda **k: ("cb", k)),
        Button=SimpleNamespace(inline=lambda label, data: (label, data)),
        errors=SimpleNamespace(FloodWaitError=FloodErr))


def tmsg(mid, text="မိုးရွာတဲ့ညနေခင်းမှာ မင်းကိုသတိရတယ်"):
    return SimpleNamespace(id=mid, message=text, date=datetime(2026, 1, 1, 9, 0), media=None)


class PureHelpers(unittest.TestCase):
    def test_buttons_and_callbacks(self):
        flat = [d for row in ti.preview_buttons(7) for _, d in row]
        self.assertEqual(flat, ["ap:7", "rj:7", "im:7", "nx:7", "sc:7"])
        self.assertEqual(ti.parse_callback("rj:12"), ("rj", 12))
        for bad in ("zz:1", "ap:x", "ap:1;drop", ""):
            self.assertIsNone(ti.parse_callback(bad))

    def test_link_to_entity(self):
        self.assertEqual(ti.link_to_entity("https://t.me/poemsource/12"), "@poemsource")
        self.assertEqual(ti.link_to_entity("@poemsource"), "@poemsource")
        for bad in ("https://t.me/+AbCdEf12345", "https://t.me/joinchat/xyz", "hello"):
            with self.assertRaises(SourceUnavailable):
                ti.link_to_entity(bad)

    def test_conversions(self):
        sm = ti.to_source_message(tmsg(5), "https://t.me/poemsource", "poemsource", 77)
        self.assertEqual((sm.message_id, sm.link), (5, "https://t.me/poemsource/5"))
        self.assertIsNone(ti.to_source_message(SimpleNamespace(), "x"))
        self.assertEqual(ti.message_stats(SimpleNamespace(views=9, forwards=2, reactions=SimpleNamespace(results=[SimpleNamespace(count=4)]))), (9, 4, 2))
        self.assertEqual(ti.message_stats(SimpleNamespace(views=None, forwards=None, reactions=None)), (0, 0, 0))
        self.assertEqual((ti.parse_target("-1001234"), ti.parse_target("@chan")), (-1001234, "@chan"))


class InterfaceWithStub(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.settings = make_settings(self.tmp)
        self.iface = ti.TelegramInterface(self.settings, stub_module())
        self.texts, self.callbacks = [], []

        async def on_text(t): self.texts.append(t)
        async def on_cb(d): self.callbacks.append(d)
        self.iface.set_handlers(on_text, on_cb)
        await self.iface.start(with_user_client=False)

    async def test_start_registers_handlers_and_logs_in_as_bot(self):
        self.assertEqual(self.iface.bot.started, "t")
        self.assertEqual(len(self.iface.bot.handlers), 2)

    async def test_only_owner_is_served(self):
        stranger = SimpleNamespace(sender_id=999, raw_text="တင်လိုက်", is_private=True)
        owner = SimpleNamespace(sender_id=OWNER, raw_text="တင်လိုက်", is_private=True)
        await self.iface._handle_message(stranger)
        await self.iface._handle_message(owner)
        self.assertEqual(self.texts, ["တင်လိုက်"])

    async def test_group_messages_ignored(self):
        await self.iface._handle_message(SimpleNamespace(sender_id=OWNER, raw_text="x", is_private=False))
        self.assertEqual(self.texts, [])

    async def test_button_press_from_stranger_is_ignored(self):
        answered = []

        async def answer(*a, **k): answered.append(1)
        await self.iface._handle_callback(SimpleNamespace(sender_id=999, data=b"ap:1", answer=answer))
        await self.iface._handle_callback(SimpleNamespace(sender_id=OWNER, data=b"ap:1", answer=answer))
        self.assertEqual((self.callbacks, len(answered)), (["ap:1"], 1))

    async def test_preview_with_image_and_buttons(self):
        img = self.tmp / "a.jpg"
        img.write_bytes(b"x")
        bundle = PostBundle(3, 1, "ကဗျာ", str(img))
        await self.iface.send_preview(bundle, "📝 #3", "🏷 x")
        to, path, kw = self.iface.bot.files[0]
        self.assertEqual((to, path), (OWNER, str(img)))
        self.assertIn("ကဗျာ", kw["caption"])
        self.assertEqual(kw["buttons"][0][0], ("✅ တင်မယ်", b"ap:3"))

    async def test_long_preview_sent_as_image_then_text(self):
        img = self.tmp / "a.jpg"
        img.write_bytes(b"x")
        await self.iface.send_preview(PostBundle(3, 1, "က" * 1100, str(img)), "h", "f")
        self.assertEqual(len(self.iface.bot.files), 1)
        self.assertNotIn("caption", self.iface.bot.files[0][2])
        self.assertEqual(len(self.iface.bot.sent), 1)

    async def test_publish_variants(self):
        img = self.tmp / "a.jpg"
        img.write_bytes(b"x")
        mid = await self.iface.publish(PostBundle(1, 1, "စာသား", str(img)))
        self.assertEqual(self.iface.bot.files[0][0], "@mychan")
        self.assertEqual(self.iface.bot.files[0][2]["caption"], "စာသား")
        await self.iface.publish(PostBundle(1, 1, "စာသား", None))
        self.assertEqual(self.iface.bot.sent[-1][0], "@mychan")
        await self.iface.publish(PostBundle(1, 1, "က" * 1100, str(img), split=True))
        self.assertEqual(len(self.iface.bot.files), 2)
        self.assertIsInstance(mid, int)

    async def test_publish_error_wrapped(self):
        async def boom(*a, **k): raise OSError("no admin rights")
        self.iface.bot.send_message = boom
        with self.assertRaises(PublishError):
            await self.iface.publish(PostBundle(1, 1, "x"))

    async def test_flood_wait_is_waited_out(self):
        self.iface.bot.flood_once = True
        with mock.patch("asyncio.sleep", new=mock.AsyncMock()) as slept:
            self.assertIsNotNone(await self.iface.send_owner("hi"))
        slept.assert_awaited_once_with(3)

    async def test_mark_preview_edits_and_clears_buttons(self):
        edits = []

        async def edit(to, mid, text=None, buttons=None): edits.append((to, text, buttons))
        self.iface.bot.edit_message = edit
        await self.iface.send_preview(PostBundle(9, 1, "ကဗျာ"), "h", "f")
        await self.iface.mark_preview(9, "✅ တင်ပြီး")
        self.assertIn("✅ တင်ပြီး", edits[0][1])
        self.assertIsNone(edits[0][2])

    async def test_reading_channels_needs_user_login(self):
        with self.assertRaises(SourceUnavailable):
            await self.iface.fetch_new_messages("https://t.me/poemsource")

    async def test_fetch_first_scan_and_incremental(self):
        self.iface.user = StubClient("u", 1, "h")
        self.iface.user.history = [tmsg(i) for i in range(1, 6)]
        first = await self.iface.fetch_new_messages("https://t.me/poemsource", 0, 3)
        self.assertEqual([m.message_id for m in first], [3, 4, 5])         # latest 3, oldest first
        later = await self.iface.fetch_new_messages("https://t.me/poemsource", 3, 30)
        self.assertEqual([m.message_id for m in later], [4, 5])
        self.assertEqual(later[0].link, "https://t.me/poemsource/4")

    async def test_unreadable_channel_becomes_source_unavailable(self):
        self.iface.user = StubClient("u", 1, "h")
        self.iface.user.entity_error = ValueError("channel is private")
        with self.assertRaises(SourceUnavailable):
            await self.iface.fetch_new_messages("https://t.me/poemsource")

    async def test_stats_fetch(self):
        self.iface.user = None
        stats = await self.iface.fetch_stats("@mychan", [3, 4])
        self.assertEqual(stats[3], (30, 5, 1))


class MainTests(unittest.IsolatedAsyncioTestCase):
    def settings(self, **extra):
        d = Path(tempfile.mkdtemp())
        return make_settings(d, DB_PATH=str(d / "t.db"), LOG_DIR=str(d / "logs"), BACKUP_DIR=str(d / "b"),
                             IMAGE_DIR=str(d / "i"), SESSION_DIR=str(d / "s"), **extra)

    def test_bad_config_values_are_reported(self):
        with self.assertRaises(ConfigError):
            Settings.from_env(env={"TELEGRAM_API_ID": "abc"}, base_dir="/tmp")
        with self.assertRaises(ConfigError):
            Settings.from_env(env={"AI_PROVIDER": "skynet"}, base_dir="/tmp")
        with self.assertRaises(ConfigError):
            Settings.from_env(env={"AI_MODEL_CONVERSATION": "no-colon"}, base_dir="/tmp")

    def test_secrets_never_appear_in_redacted_view(self):
        s = make_settings(Path(tempfile.mkdtemp()), TELEGRAM_BOT_TOKEN="SECRET-TOKEN", ANTHROPIC_API_KEY="SECRET-KEY")
        self.assertNotIn("SECRET", str(s.redacted()))

    def test_missing_required_lists_everything(self):
        s = Settings.from_env(env={}, base_dir=Path(tempfile.mkdtemp()))
        self.assertGreaterEqual(len(s.missing_required()), 6)

    def test_dotenv_file_is_read(self):
        d = Path(tempfile.mkdtemp())
        (d / ".env").write_text('# c\nOWNER_TELEGRAM_ID="77"\nTARGET_CHANNEL=@x\n', encoding="utf-8")
        s = Settings.from_env(env={}, base_dir=d)
        self.assertEqual((s.owner_id, s.target_channel), (77, "@x"))

    async def test_health_check_ok_and_failures(self):
        with mock.patch("importlib.util.find_spec", return_value=object()):
            errors, warnings = await main.health_check(self.settings())
        self.assertEqual(errors, [])
        self.assertTrue(warnings)                         # no user session / one AI provider
        bad = Settings.from_env(env={}, base_dir=Path(tempfile.mkdtemp()))
        errors, _ = await main.health_check(bad)
        self.assertTrue(any("TELEGRAM_BOT_TOKEN" in e for e in errors))

    def test_build_app_wires_modules(self):
        app = main.build_app(self.settings(), tg=FakeTelegram())
        self.assertIs(app.agent.channels, app.channels)
        self.assertIs(app.channels.poetry, app.poetry)
        self.assertIs(app.poetry.brain, app.brain)

    async def test_run_app_starts_and_shuts_down_cleanly(self):
        tg = FakeTelegram()
        stop = asyncio.Event()
        task = asyncio.create_task(main.run_app(self.settings(), stop, tg=tg))
        await asyncio.sleep(0.3)
        self.assertTrue(any("စတင်ပါပြီ" in s for s in tg.sent))
        stop.set()
        await asyncio.wait_for(task, 5)

    def test_cli_check_exit_codes(self):
        d = Path(tempfile.mkdtemp())
        env = {"DB_PATH": str(d / "t.db"), "LOG_DIR": str(d / "logs"), "BACKUP_DIR": str(d / "b"),
               "IMAGE_DIR": str(d / "i"), "SESSION_DIR": str(d / "s")}
        with mock.patch.dict("os.environ", env):
            self.assertEqual(main.main(["--check", "--env-file", "/nonexistent"]), 1)   # nothing configured -> fails


if __name__ == "__main__":
    unittest.main()
