"""Test doubles: fake HTTP transport, fake AI brain, fake Telegram, app builder."""
from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace
from typing import Any

from channel.channel_manager import ChannelManager
from config.settings import Settings
from core.agent import Agent
from core.ai_brain import UNKNOWN_MESSAGE
from core.errors import AIError, SourceUnavailable
from core.http_client import HttpClient
from core.intent_rules import rule_intent
from core.models import Intent, PoemAnalysis, PostBundle, SourceMessage
from media.image_engine import ImageEngine
from memory.memory_manager import MemoryManager
from poetry.poetry_engine import PoetryEngine
from storage.database import Database

OWNER = 4242
CHANNEL = "https://t.me/poemsource"

POEMS = {
    "rain": "မိုးရွာတဲ့ညနေခင်းမှာ\nမင်းကိုသတိရနေမိတယ်\nအိမ်ပြန်လမ်းတစ်လျှောက်\nအထီးကျန်ရင်ဆိုင်ရတယ်\n\n#ကဗျာ #အောင်ချိန့်",
    "flower": "နံနက်ခင်းနေရောင်ခြည်ကြောင့်\nပန်းတွေပွင့်လာတဲ့အခါ\nမျှော်လင့်ချက်အသစ်တွေနဲ့\nဘဝကိုပြန်ချစ်မိတယ်\n\n#ကဗျာ #မြင့်သန်း",
    "hill": "တောင်ကုန်းပေါ်ကလေပြည်ညင်း\nတိတ်ဆိတ်တဲ့ကောင်းကင်အောက်\nစိတ်ထဲမှာငြိမ်းချမ်းမှုတစ်ခု\nတိုးတိတ်စွာဝင်လာခဲ့တယ်",
    "river": "ချောင်းရိုးတစ်လျှောက်ရေစီးသံ\nကြယ်စုံညဉ့်နက်ရဲ့အလွမ်း\nမြစ်ကမ်းပါးမှာထိုင်ရင်း\nအနာဂတ်ကိုစိတ်ကူးမိတယ်",
}


def make_settings(tmp: Path, **extra: str) -> Settings:
    env = {"TELEGRAM_API_ID": "1", "TELEGRAM_API_HASH": "h", "TELEGRAM_BOT_TOKEN": "t",
           "OWNER_TELEGRAM_ID": str(OWNER), "TARGET_CHANNEL": "@mychan", "ANTHROPIC_API_KEY": "k",
           "POST_TIMES": "09:00,19:00", "SCAN_DELAY_MIN": "0", "SCAN_DELAY_MAX": "0",
           "MIN_IMAGE_WIDTH": "100", "MIN_IMAGE_HEIGHT": "100"}
    env.update(extra)
    return Settings.from_env(env=env, base_dir=tmp)


async def _nosleep(_: float) -> None:
    return None


class FakeTransport:
    """Replaces the network. routes: substring of URL -> (status, headers, body | callable)."""

    def __init__(self) -> None:
        self.routes: list[tuple[str, int, dict, Any]] = []
        self.calls: list[tuple[str, str, dict, bytes | None]] = []

    def add(self, needle: str, body: Any, status: int = 200, headers: dict | None = None) -> None:
        self.routes.append((needle, status, headers or {}, body))

    def __call__(self, method: str, url: str, headers: dict, body: bytes | None, timeout: float):
        self.calls.append((method, url, headers, body))
        for needle, status, hdrs, data in self.routes:
            if needle in url:
                if callable(data):
                    data = data(url, body)
                if isinstance(data, (dict, list)):
                    data = json.dumps(data).encode()
                return status, hdrs, data
        return 404, {}, b"no route"


def make_http(transport: FakeTransport) -> HttpClient:
    return HttpClient(transport=transport, sleep=_nosleep, retries=1)


def commons_response(items: list[dict]) -> dict:
    pages = {}
    for i, it in enumerate(items, 1):
        pages[str(i)] = {"title": f"File:{it['name']}", "index": i, "imageinfo": [{
            "thumburl": it["url"], "thumbwidth": it.get("w", 1280), "thumbheight": it.get("h", 800),
            "url": it["url"], "mime": "image/jpeg", "descriptionurl": "https://commons.example/page",
            "extmetadata": {"LicenseShortName": {"value": it.get("license", "CC BY-SA 4.0")},
                            "Artist": {"value": f"<a href='x'>{it.get('artist', 'Someone')}</a>"},
                            "ImageDescription": {"value": it.get("desc", "rainy window at night")}}}]}
    return {"query": {"pages": pages}}


def image_routes(transport: FakeTransport, n: int = 4) -> None:
    items = [{"name": f"rain{i}.jpg", "url": f"https://upload.example/img/rain{i}.jpg"} for i in range(1, n + 1)]
    transport.add("commons.wikimedia.org", commons_response(items))
    for i in range(1, n + 1):
        transport.add(f"img/rain{i}.jpg", f"JPEGDATA{i}".encode(), headers={"Content-Type": "image/jpeg"})


class FakeBrain:
    available = True

    def __init__(self) -> None:
        self.fail_analysis = False
        self.dup_verdict: tuple[bool, float] = (False, 0.0)
        self.image_match: float | None = None
        self.dup_calls = 0

    async def analyze_poem(self, text: str) -> PoemAnalysis:
        if self.fail_analysis:
            raise AIError("provider down")
        rainy = "မိုး" in text
        return PoemAnalysis([{"name": "longing" if rainy else "love", "score": 0.9}],
                            ["sad_poetry"] if rainy else ["love_poetry"], 60.0 + (len(text) % 35),
                            "fake", ["rainy window"], "fake:model")

    async def judge_duplicate(self, a: str, b: str) -> tuple[bool, float]:
        self.dup_calls += 1
        return self.dup_verdict

    async def image_queries(self, poem_text, emotions, visual_themes=(), avoid=()):
        return ["rainy window"]

    async def judge_image_match(self, poem_text: str, description: str):
        return self.image_match

    async def parse_owner_message(self, text, *, awaiting_confirm=False, context=None) -> Intent:
        return rule_intent(text, awaiting_confirm=awaiting_confirm) or Intent("unknown", clarification=UNKNOWN_MESSAGE)


class FakeTelegram:
    def __init__(self) -> None:
        self.sent: list[str] = []
        self.previews: list[PostBundle] = []
        self.marks: list[tuple[int, str]] = []
        self.published: list[PostBundle] = []
        self.channels: dict[str, list[SourceMessage]] = {}
        self.fail_publish = 0
        self.stats: dict[int, tuple[int, int, int]] = {}
        self.unavailable: set[str] = set()
        self._next_id = 1000

    def set_handlers(self, on_text, on_callback) -> None:
        self.on_text, self.on_callback = on_text, on_callback

    async def start(self) -> None: ...
    async def stop(self) -> None: ...

    async def send_owner(self, text: str, buttons=None) -> int:
        self.sent.append(text)
        return len(self.sent)

    async def send_preview(self, bundle: PostBundle, header: str, footer: str) -> int:
        self.previews.append(bundle)
        return len(self.previews)

    async def mark_preview(self, post_id: int, status: str) -> None:
        self.marks.append((post_id, status))

    async def publish(self, bundle: PostBundle) -> int:
        if self.fail_publish > 0:
            self.fail_publish -= 1
            raise RuntimeError("telegram down")
        self.published.append(bundle)
        self._next_id += 1
        return self._next_id

    async def fetch_new_messages(self, link: str, min_id: int, limit: int):
        if link in self.unavailable:
            raise SourceUnavailable("private channel")
        return [m for m in self.channels.get(link, []) if m.message_id > min_id][:limit]

    async def fetch_stats(self, channel: str, ids):
        return {i: self.stats[i] for i in ids if i in self.stats}


def msg(mid: int, text: str, link: str = CHANNEL) -> SourceMessage:
    return SourceMessage(link, mid, text, "", False, f"{link}/{mid}")


async def make_app(tmp: Path, **env: str) -> SimpleNamespace:
    settings = make_settings(tmp, **env)
    db = Database(":memory:")
    await db.open()
    transport = FakeTransport()
    http = make_http(transport)
    brain = FakeBrain()
    memory = MemoryManager(db)
    poetry = PoetryEngine(db, brain, settings)
    images = ImageEngine(db, brain, http, settings)
    channels = ChannelManager(db, poetry, images, memory, settings, sleep=_nosleep)
    tg = FakeTelegram()
    agent = Agent(settings, db, brain, memory, poetry, images, channels, tg)
    await agent.startup()
    return SimpleNamespace(settings=settings, db=db, transport=transport, brain=brain, memory=memory, poetry=poetry,
                           images=images, channels=channels, tg=tg, agent=agent)


async def seed_poems(app: SimpleNamespace, keys=("rain", "flower", "hill", "river")) -> int:
    """Add the source channel, serve the poems from FakeTelegram and run one scan."""
    await app.db.add_source_channel(CHANNEL, "poemsource", "Poem source")
    app.tg.channels[CHANNEL] = [msg(i + 1, POEMS[k]) for i, k in enumerate(keys)]
    totals = await app.agent.scan_once()
    return totals.get("stored", 0)
