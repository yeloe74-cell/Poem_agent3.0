import sqlite3
import tempfile
import unittest
from pathlib import Path

from core.ai_brain import AIBrain
from core.errors import AIError
from storage.database import Database
from tests.fakes import FakeTransport, make_http, make_settings


class DatabaseTests(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.db = Database(":memory:")
        await self.db.open()
        self.cid = await self.db.add_source_channel("https://t.me/x", "x", "X")

    async def asyncTearDown(self):
        await self.db.close()

    async def poem(self, mid=1, h="h1"):
        return await self.db.insert_poem(self.cid, mid, "raw", "norm", h)

    async def test_schema_has_all_tables_and_is_reopenable(self):
        names = {r["name"] for r in await self.db.fetchall("SELECT name FROM sqlite_master WHERE type='table'")}
        for t in ("poems", "poem_credits", "scheduled_posts", "approvals", "publishing_history", "post_stats",
                  "agent_memory", "feedback_records", "task_logs", "error_logs", "content_plans", "images"):
            self.assertIn(t, names)

    async def test_same_source_message_not_stored_twice(self):
        self.assertIsNotNone(await self.poem(1))
        self.assertIsNone(await self.poem(1))

    async def test_unknown_credit_cannot_have_author(self):
        pid = await self.poem()
        await self.db.save_credit(pid, "unknown", "Invented Name", None, 0.9, None)
        credit = await self.db.get_credit(pid)
        self.assertIsNone(credit["author_id"])          # author dropped, never invented
        self.assertEqual(credit["credit_status"], "unknown")

    async def test_publish_blocked_without_approval_and_single_success(self):
        pid = await self.poem()
        post = await self.db.create_post(pid, None, "cap", None)
        with self.assertRaises(sqlite3.IntegrityError):
            await self.db.record_publish(post, "@c", "success", 1)
        await self.db.decide_approval(post, "approved")
        await self.db.record_publish(post, "@c", "success", 1)
        with self.assertRaises(sqlite3.IntegrityError):
            await self.db.record_publish(post, "@c", "success", 2)
        await self.db.record_publish(post, "@c", "failed", error="x")     # failures are always loggable

    async def test_one_live_post_per_poem(self):
        pid = await self.poem()
        first = await self.db.create_post(pid, None, "a", None)
        with self.assertRaises(sqlite3.IntegrityError):
            await self.db.create_post(pid, None, "b", None)
        await self.db.update_post(first, status="cancelled")
        await self.db.create_post(pid, None, "c", None)                   # allowed after cancel

    async def test_create_post_is_atomic(self):
        pid = await self.poem()
        await self.db.create_post(pid, None, "a", None)
        try:
            await self.db.create_post(pid, None, "dup", None)
        except sqlite3.IntegrityError:
            pass
        self.assertEqual(len(await self.db.fetchall("SELECT * FROM approvals")), 1)   # no orphan approval

    async def test_claim_post_only_once(self):
        pid = await self.poem()
        post = await self.db.create_post(pid, None, "a", None)
        await self.db.update_post(post, status="approved")
        self.assertTrue(await self.db.claim_post(post, ("approved",), "publishing"))
        self.assertFalse(await self.db.claim_post(post, ("approved",), "publishing"))

    async def test_memory_expiry_and_upsert(self):
        await self.db.upsert_memory("preference", "k", "v1", 1, "2000-01-01 00:00:00")
        self.assertEqual(await self.db.list_memory("preference"), [])
        await self.db.upsert_memory("preference", "k", "v2", 1, None)
        rows = await self.db.list_memory("preference")
        self.assertEqual([r["content"] for r in rows], ["v2"])

    async def test_update_post_rejects_unknown_fields(self):
        with self.assertRaises(ValueError):
            await self.db.update_post(1, evil="x")

    async def test_backup_file_is_valid_database(self):
        with tempfile.TemporaryDirectory() as d:
            dest = await self.db.backup(Path(d) / "b.db")
            con = sqlite3.connect(dest)
            self.assertGreater(con.execute("SELECT COUNT(*) FROM source_channels").fetchone()[0], 0)
            con.close()


ANALYSIS = {"emotions": [{"name": "longing", "score": 0.9}, {"name": "bogus", "score": 1}],
            "categories": ["sad_poetry", "nonsense"], "quality": {"score": 140, "notes": "n"},
            "visual_themes": ["rainy window", "ကဗျာ", "x"]}


class BrainTests(unittest.IsolatedAsyncioTestCase):
    def brain(self, **env):
        t = FakeTransport()
        return AIBrain(make_settings(Path(tempfile.mkdtemp()), **env), make_http(t)), t

    def test_analysis_is_validated_and_clamped(self):
        brain, _ = self.brain()
        a = brain.validate_analysis(ANALYSIS, "m")
        self.assertEqual([e["name"] for e in a.emotions], ["longing"])
        self.assertEqual(a.categories, ["sad_poetry"])
        self.assertEqual(a.quality_score, 100.0)
        self.assertEqual(a.visual_themes, ["rainy window"])
        self.assertEqual(brain.validate_analysis({"emotions": [], "categories": []}).categories, ["free_verse"])
        with self.assertRaises(AIError):
            brain.validate_analysis("not a dict")

    async def test_anthropic_request_and_parse(self):
        brain, t = self.brain()
        t.add("api.anthropic.com/v1/messages", {"content": [{"type": "text", "text": "```json\n" + __import__("json").dumps(ANALYSIS) + "\n```"}]})
        a = await brain.analyze_poem("မိုးရွာသည်")
        self.assertEqual(a.categories, ["sad_poetry"])
        method, url, headers, body = t.calls[0]
        self.assertEqual(headers["x-api-key"], "k")
        self.assertIn(b"NEVER write", body)               # prompt forbids writing poems

    async def test_fallback_to_second_provider(self):
        brain, t = self.brain(OPENAI_API_KEY="o")
        t.add("api.anthropic.com", {"error": "overloaded"}, status=500)
        t.add("api.openai.com/v1/chat/completions", {"choices": [{"message": {"content": __import__("json").dumps(ANALYSIS)}}]})
        a = await brain.analyze_poem("မိုးရွာသည်")
        self.assertTrue(a.model_used.startswith("openai:"))

    async def test_gemini_format(self):
        brain, t = self.brain(ANTHROPIC_API_KEY="", GEMINI_API_KEY="g")
        t.add(":generateContent", {"candidates": [{"content": {"parts": [{"text": '{"same": true, "confidence": 0.9}'}]}}]})
        self.assertEqual(await brain.judge_duplicate("a", "b"), (True, 0.9))

    async def test_all_providers_down_raises(self):
        brain, t = self.brain()
        t.add("api.anthropic.com", {}, status=503)
        with self.assertRaises(AIError):
            await brain.analyze_poem("x")

    async def test_garbage_output_retried_then_fails_cleanly(self):
        brain, t = self.brain()
        t.add("api.anthropic.com", {"content": [{"type": "text", "text": "I cannot comply"}]})
        with self.assertRaises(AIError):
            await brain.analyze_poem("x")
        self.assertEqual(len(t.calls), 2)                  # one stricter retry

    async def test_image_queries_work_without_ai(self):
        brain, _ = self.brain(ANTHROPIC_API_KEY="")
        queries = await brain.image_queries("x", [{"name": "loneliness", "score": 1}], avoid=["bench"])
        self.assertTrue(queries)
        self.assertFalse(any("bench" in q for q in queries))

    async def test_owner_message_ai_fallback_and_safety(self):
        brain, t = self.brain()
        t.add("api.anthropic.com", {"content": [{"type": "text", "text": '{"intent":"approve","params":{},"confidence":0.7,"clarification":null}'}]})
        intent = await brain.parse_owner_message("ကောင်းလိုက်တာနော် သိပ်ကြိုက်တယ်")
        self.assertEqual(intent.name, "unknown")           # a weak AI guess can never publish
        self.assertTrue(intent.clarification)


if __name__ == "__main__":
    unittest.main()
