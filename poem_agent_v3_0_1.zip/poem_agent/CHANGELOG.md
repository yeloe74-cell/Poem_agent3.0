# Changelog

## 3.0.1

- A workflow confirmation the owner never answers now expires after 180 s instead of blocking every Burmese text command.
- While a confirmation is pending, only a plain yes/no reply goes to it; poetry commands ("တင်လိုက်", "ကဗျာ ၃ ပုဒ်ပြင်ပေး" ...) keep working.
- When the intent parser asks a poetry clarification question, the question is sent to the owner instead of being replaced by a general-assistant answer.
- `--check` warns when SQLite is older than 3.35 (needed for `UPDATE ... RETURNING`).

## 3.0.0

- Preserved the original poetry collection, classification, image selection, owner approval, scheduling and Telegram publishing workflow.
- Added a bounded asynchronous Agent Runtime and typed Event Bus.
- Added a durable workflow engine with dependency validation, step checkpoints, approval gates and idempotency records.
- Added a typed Tool Registry with argument limits, timeouts, allow-list registration and explicit external-action approval.
- Added scoped, expiring, single-use approval tokens and a deny-by-default policy engine.
- Added context budgeting and credential redaction before prompt assembly.
- Added episodic memory retrieval with importance and recency weighting.
- Added deterministic document chunking for the existing SQLite-backed KnowledgeStore.
- Added evidence-based outcome evaluation and runtime-focused tests.
- No new third-party runtime dependencies. External provider/API credentials remain configured by the owner in `.env`.

## Compatibility

The v3 package is based on the supplied v2 project and retains its original module paths and settings contract. New SQLite tables are additive and initialized by the agent; existing tables are not dropped or rewritten.
