"""Poem Agent entry point (main file 01/10).

    python main.py --check     offline health check (config, folders, database, Telethon)
    python main.py --login     one-time interactive login of the spare Telegram account
    python main.py --init-db   create/upgrade the database file and exit
    python main.py             run the agent (Ctrl+C or SIGTERM stops it cleanly)
"""
from __future__ import annotations

import argparse
import asyncio
import importlib.util
import sqlite3
import logging
import signal
import sys
from dataclasses import dataclass
from logging.handlers import RotatingFileHandler
from typing import Any

from channel.channel_manager import ChannelManager
from config.settings import Settings
from core.agent import Agent
from core.ai_brain import AIBrain
from core.errors import ConfigError
from core.http_client import HttpClient
from media.image_engine import ImageEngine
from memory.memory_manager import MemoryManager
from poetry.poetry_engine import PoetryEngine
from storage.database import Database
from telegram.telegram_interface import TelegramInterface

log = logging.getLogger("poem_agent")


@dataclass
class App:
    settings: Settings
    db: Database
    http: HttpClient
    brain: AIBrain
    memory: MemoryManager
    poetry: PoetryEngine
    images: ImageEngine
    channels: ChannelManager
    tg: Any
    agent: Agent


def setup_logging(settings: Settings) -> None:
    settings.log_dir.mkdir(parents=True, exist_ok=True)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
    root = logging.getLogger()
    root.setLevel(getattr(logging, settings.log_level, logging.INFO))
    for handler in list(root.handlers):
        root.removeHandler(handler)
    console = logging.StreamHandler()
    console.setFormatter(fmt)
    files = RotatingFileHandler(settings.log_dir / "poem_agent.log", maxBytes=2_000_000, backupCount=5, encoding="utf-8")
    files.setFormatter(fmt)
    root.addHandler(console)
    root.addHandler(files)
    logging.getLogger("telethon").setLevel(logging.WARNING)


def build_app(settings: Settings, tg: Any | None = None, http: HttpClient | None = None) -> App:
    """Create every module and connect them (nothing is opened or started yet)."""
    http = http or HttpClient(user_agent=settings.user_agent)
    db = Database(settings.db_path)
    brain = AIBrain(settings, http)
    memory = MemoryManager(db)
    poetry = PoetryEngine(db, brain, settings)
    images = ImageEngine(db, brain, http, settings)
    channels = ChannelManager(db, poetry, images, memory, settings)
    tg = tg or TelegramInterface(settings)
    agent = Agent(settings, db, brain, memory, poetry, images, channels, tg)
    return App(settings, db, http, brain, memory, poetry, images, channels, tg, agent)


async def health_check(settings: Settings) -> tuple[list[str], list[str]]:
    """Returns (errors, warnings). Makes no network calls."""
    errors = [f"missing setting: {name}" for name in settings.missing_required()]
    warnings: list[str] = []
    try:
        settings.ensure_dirs()
        probe = settings.log_dir / ".write_test"
        probe.write_text("ok")
        probe.unlink()
    except OSError as exc:
        errors.append(f"cannot write to data/log folders: {exc}")
    try:
        db = Database(settings.db_path)
        await db.open()
        tables = await db.fetchall("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")
        if len(tables) < 17:
            errors.append(f"database has only {len(tables)} tables")
        await db.close()
    except Exception as exc:  # noqa: BLE001
        errors.append(f"database problem: {exc}")
    if importlib.util.find_spec("telethon") is None:
        errors.append("Telethon is not installed (pip install -r requirements.txt)")
    if sqlite3.sqlite_version_info < (3, 35):
        warnings.append(f"SQLite {sqlite3.sqlite_version} is older than 3.35: general-assistant tasks/workflows "
                        "(UPDATE ... RETURNING) will fail; poetry features are not affected")
    if not (settings.session_dir / "user.session").exists():
        warnings.append("spare account not logged in yet: run `python main.py --login` (needed to read source channels)")
    if not settings.pexels_key and not settings.unsplash_key:
        warnings.append("no PEXELS_API_KEY / UNSPLASH_ACCESS_KEY: only Wikimedia Commons will be used for images")
    if len(settings.ai_keys) < 2:
        warnings.append("only one AI provider configured: no fallback if it is down")
    return errors, warnings


async def run_app(settings: Settings, stop: asyncio.Event | None = None, tg: Any | None = None,
                  http: HttpClient | None = None) -> None:
    settings.ensure_dirs()
    stop = stop or asyncio.Event()
    app = build_app(settings, tg=tg, http=http)
    await app.db.open()
    try:
        await app.agent.startup()
        await app.tg.start()
        app.agent.start_background(stop)
        await app.tg.send_owner("✅ Poem Agent စတင်ပါပြီ။ 'ကူညီ' လို့ ပြောရင် ပြောလို့ရတာတွေ ပြပါမယ်။")
        log.info("Poem Agent running. Settings: %s", settings.redacted())
        await stop.wait()
    finally:
        log.info("shutting down ...")
        await app.agent.shutdown()
        await app.tg.stop()
        await app.db.close()


def _install_signals(loop: asyncio.AbstractEventLoop, stop: asyncio.Event) -> None:
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, stop.set)
        except (NotImplementedError, RuntimeError):      # e.g. Windows
            signal.signal(sig, lambda *_: loop.call_soon_threadsafe(stop.set))


async def _main_async(args: argparse.Namespace, settings: Settings) -> int:
    if args.check:
        errors, warnings = await health_check(settings)
        for w in warnings:
            print(f"WARNING: {w}")
        for e in errors:
            print(f"ERROR:   {e}")
        print("Health check: " + ("FAILED" if errors else "OK (offline checks only; Telegram/AI/image APIs not contacted)"))
        return 1 if errors else 0
    if args.init_db:
        settings.ensure_dirs()
        db = Database(settings.db_path)
        await db.open()
        await db.close()
        print(f"database ready: {settings.db_path}")
        return 0
    if args.login:
        missing = [m for m in settings.missing_required() if m.startswith("TELEGRAM_API")]
        if missing:
            print("Set TELEGRAM_API_ID and TELEGRAM_API_HASH in .env first.")
            return 1
        await TelegramInterface(settings).login_user()
        return 0
    errors = settings.missing_required()
    if errors:
        print("Cannot start. Missing settings: " + ", ".join(errors))
        print("Copy .env.example to .env and fill it in, then run: python main.py --check")
        return 1
    stop = asyncio.Event()
    _install_signals(asyncio.get_running_loop(), stop)
    await run_app(settings, stop)
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Poem Agent")
    parser.add_argument("--check", action="store_true", help="offline health check")
    parser.add_argument("--login", action="store_true", help="log in the spare Telegram account (interactive)")
    parser.add_argument("--init-db", action="store_true", help="create the database and exit")
    parser.add_argument("--env-file", default=None, help="path to a .env file")
    args = parser.parse_args(argv)
    try:
        settings = Settings.from_env(env_file=args.env_file)
    except ConfigError as exc:
        print(f"Configuration error: {exc}")
        return 1
    setup_logging(settings)
    try:
        return asyncio.run(_main_async(args, settings))
    except KeyboardInterrupt:
        return 0


if __name__ == "__main__":
    sys.exit(main())
