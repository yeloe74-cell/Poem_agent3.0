# Poem Agent 3.0.0

Poem Agent 3.0 is a Telegram poetry-channel manager extended with a general-purpose assistant runtime. Poetry remains the first-class skill: source collection, poem classification, duplicate detection, image matching, owner preview/approval, scheduling and channel publishing remain in the original modules.

## Runtime additions

- `runtime/agent_runtime.py`: bounded execution loop, cancellation, wall-time and step budgets.
- `runtime/event_bus.py`: typed asynchronous events with handler isolation and metrics.
- `runtime/context_builder.py`: context budgeting and secret redaction.
- `tasks/workflow_engine.py`: persistent workflow proposals, dependency graph validation, resumable step state, bounded retries, idempotency keys and approval gating.
- `tools/registry.py`: trusted handler registry, typed risk metadata, argument size checks and execution timeouts. Model-generated text is never evaluated as Python, shell or SQL.
- `security/policy_engine.py`: scoped, expiring, single-use approval tokens and default-deny permissions.
- `memory/episodic_memory.py`: SQLite-backed episodic note retrieval with recency/importance weighting and secret rejection.
- `knowledge/ingestion.py`: deterministic text chunking for the existing `KnowledgeStore`.
- `core/reflection.py`: outcome verification based on evidence, not assistant claims.

## Installation

Python 3.10+ is recommended. Install the single external runtime dependency:

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
cp .env.example .env
```

Fill in the credentials and settings you choose to use in `.env`. Never commit `.env` or paste secrets into Telegram chats. Provider model names and endpoints are configurable; availability depends on the provider account and current provider catalogue.

## Local checks

```bash
python -m compileall -q .
python -m unittest discover -s tests -v
python main.py --check
```

The unit suite uses local fakes and an in-memory SQLite database. It does not call paid or external AI/image APIs. Live provider and Telegram connectivity checks are intentionally left to the owner using their own `.env` and accounts.

## Startup

```bash
python main.py --init-db
python main.py --login
python main.py
```

Use `python main.py --check` to validate local configuration. Source-channel reading uses the Telegram user session; the bot token is used for owner interaction and channel posting according to the existing project setup.

## Safety model

- The poetry publishing pipeline still requires owner approval before publication.
- The general assistant only calls registered tools.
- Unknown tools are denied.
- External, destructive and credential-changing actions require an explicit approval boundary.
- Workflow creation stores a proposal; it does not silently execute it.
- `GeneralAgent.execute_approved_workflow(...)` is an application-level entry point and must only be called by a trusted owner-authenticated handler after confirming the exact workflow and approved tool set. The Telegram flow shows all steps and waits for the Owner's explicit `အတည်ပြုလုပ်ဆောင်` reply.
- Do not expose internal workflow approval methods to arbitrary Telegram users.

## Data and compatibility

The project uses SQLite. New workflow tables are additive. Existing poetry, image, channel, Telegram, memory and task tables are preserved. Back up the database before upgrading a live installation.

## Known operational boundaries

- This release does not claim that a third-party provider API key is valid or that a Telegram session is logged in; those are account-specific owner checks.
- The general assistant can create tasks, search saved knowledge, create validated workflow proposals and report project state. It must not claim a real-world action completed without execution evidence.
- Knowledge retrieval is lexical and Unicode-aware, not a hosted vector database. No embedding API is required.
- Autonomous execution remains bounded by registered tools, timeouts, budgets and owner permissions. Arbitrary shell execution and model-generated code execution are intentionally unsupported.
