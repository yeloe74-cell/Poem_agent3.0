"""Image engine (main file 07/10).

Finds stock photos whose mood fits a poem:
  AI/fallback queries -> search sources -> validate (license, size, https) ->
  score against the poem -> download the winner -> reject duplicates by file hash.

Sources: Wikimedia Commons (no key), Pexels and Unsplash (free API keys).
A daily budget limits how many poems get a fresh image search.
"""
from __future__ import annotations

import html
import logging
import re
from pathlib import Path
from typing import Any, Iterable, Sequence

from config.settings import Settings
from core.ai_brain import AIBrain
from core.errors import HTTPError
from core.http_client import HttpClient
from core.models import ImageCandidate
from core.time_utils import to_local, utcnow
from storage.database import Database

log = logging.getLogger(__name__)
_TAG_RE = re.compile(r"<[^>]+>")
_WORD_RE = re.compile(r"[a-z]{3,}")
COMMONS_API = "https://commons.wikimedia.org/w/api.php"
PEXELS_API = "https://api.pexels.com/v1/search"
UNSPLASH_API = "https://api.unsplash.com/search/photos"


def _clean(value: Any) -> str:
    return html.unescape(_TAG_RE.sub("", str(value or ""))).strip()


class ImageEngine:
    def __init__(self, db: Database, brain: AIBrain, http: HttpClient, settings: Settings) -> None:
        self.db = db
        self.brain = brain
        self.http = http
        self.settings = settings

    # ------------------------------------------------------------------
    # sources
    # ------------------------------------------------------------------
    async def search_wikimedia(self, query: str, limit: int = 8) -> list[ImageCandidate]:
        data = await self.http.get_json(COMMONS_API, params={
            "action": "query", "format": "json", "generator": "search", "gsrnamespace": 6,
            "gsrsearch": f"{query} filetype:bitmap", "gsrlimit": limit, "prop": "imageinfo",
            "iiprop": "url|size|mime|extmetadata", "iiurlwidth": 1280})
        pages = (data.get("query") or {}).get("pages") or {}
        out: list[ImageCandidate] = []
        for page in sorted(pages.values(), key=lambda p: p.get("index", 0)):
            info = (page.get("imageinfo") or [{}])[0]
            if info.get("mime") not in ("image/jpeg", "image/png"):
                continue
            meta = info.get("extmetadata") or {}
            artist = _clean((meta.get("Artist") or {}).get("value"))
            license_name = _clean((meta.get("LicenseShortName") or {}).get("value"))
            out.append(ImageCandidate(
                url=info.get("thumburl") or info.get("url", ""), source="wikimedia", license=license_name,
                attribution=f"{artist or 'Unknown author'} / Wikimedia Commons ({license_name})".strip(),
                width=int(info.get("thumbwidth") or info.get("width") or 0),
                height=int(info.get("thumbheight") or info.get("height") or 0),
                description=_clean((meta.get("ImageDescription") or {}).get("value")) or _clean(page.get("title")),
                query=query, page_url=info.get("descriptionurl", ""), rank=page.get("index", 0)))
        return out

    async def search_pexels(self, query: str, limit: int = 8) -> list[ImageCandidate]:
        data = await self.http.get_json(PEXELS_API, headers={"Authorization": self.settings.pexels_key},
                                        params={"query": query, "per_page": limit, "orientation": "landscape"})
        return [ImageCandidate(
            url=(p.get("src") or {}).get("large2x") or (p.get("src") or {}).get("large", ""), source="pexels",
            license="Pexels License", attribution=f"Photo by {p.get('photographer', 'Unknown')} on Pexels",
            width=int(p.get("width") or 0), height=int(p.get("height") or 0), description=_clean(p.get("alt")),
            query=query, page_url=p.get("url", ""), rank=i) for i, p in enumerate(data.get("photos") or [])]

    async def search_unsplash(self, query: str, limit: int = 8) -> list[ImageCandidate]:
        data = await self.http.get_json(UNSPLASH_API, headers={"Authorization": f"Client-ID {self.settings.unsplash_key}"},
                                        params={"query": query, "per_page": limit, "orientation": "landscape"})
        return [ImageCandidate(
            url=(p.get("urls") or {}).get("regular", ""), source="unsplash", license="Unsplash License",
            attribution=f"Photo by {(p.get('user') or {}).get('name', 'Unknown')} on Unsplash",
            width=int(p.get("width") or 0), height=int(p.get("height") or 0),
            description=_clean(p.get("alt_description") or p.get("description")), query=query,
            page_url=(p.get("links") or {}).get("html", ""), rank=i) for i, p in enumerate(data.get("results") or [])]

    def enabled_sources(self) -> list[str]:
        names = ["wikimedia"]
        if self.settings.pexels_key:
            names.append("pexels")
        if self.settings.unsplash_key:
            names.append("unsplash")
        return names

    async def search_all(self, query: str) -> list[ImageCandidate]:
        found: list[ImageCandidate] = []
        for name in self.enabled_sources():
            try:
                found += await getattr(self, f"search_{name}")(query)
            except HTTPError as exc:
                log.warning("image source %s failed for %r: %s", name, query, exc)
        return found

    # ------------------------------------------------------------------
    # validation and scoring
    # ------------------------------------------------------------------
    def license_ok(self, license_name: str) -> bool:
        low = license_name.lower().strip()
        if not low:
            return False
        tokens = set(re.findall(r"[a-z0-9]+", low))
        if any(b in tokens or (len(b) > 3 and b in low) for b in self.settings.license_block):
            return False
        return any((a in low) if len(a) > 3 else (a in tokens) for a in self.settings.license_allow)

    def validate(self, c: ImageCandidate) -> str | None:
        """None when acceptable, otherwise the reason it is rejected."""
        if not c.url.startswith("https://"):
            return "not https"
        if c.width < self.settings.min_image_width or c.height < self.settings.min_image_height:
            return "resolution too small"
        if not self.license_ok(c.license):
            return f"license not allowed ({c.license or 'unknown'})"
        return None

    @staticmethod
    def attribution_required(license_name: str) -> bool:
        low = license_name.lower()
        return "cc by" in low or "cc-by" in low or "by-sa" in low

    def _heuristic(self, c: ImageCandidate, queries: Sequence[str], avoid: Iterable[str]) -> float:
        desc = f"{c.description} {c.query}".lower()
        words = set(_WORD_RE.findall(" ".join(queries).lower()))
        overlap = len(words & set(_WORD_RE.findall(desc)))
        score = 40.0 + min(overlap, 3) * 12.0 + max(0, 8 - c.rank) * 1.5
        if any(a and a.lower() in desc for a in avoid):
            score -= 60.0
        return max(0.0, min(100.0, score))

    # ------------------------------------------------------------------
    # budget
    # ------------------------------------------------------------------
    def _budget_key(self) -> str:
        day = to_local(utcnow(), self.settings.timezone_offset_minutes).date().isoformat()
        return f"img_budget:{day}"

    async def searches_today(self) -> int:
        return int(await self.db.get_config(self._budget_key(), "0") or 0)

    async def _spend(self) -> None:
        await self.db.set_config(self._budget_key(), str(await self.searches_today() + 1))

    # ------------------------------------------------------------------
    # public API
    # ------------------------------------------------------------------
    def local_file(self, image_id: int) -> Path | None:
        matches = sorted(self.settings.image_dir.glob(f"{image_id}.*"))
        return matches[0] if matches else None

    async def find_for_poem(self, poem_id: int, poem_text: str, emotions: Sequence[dict[str, Any]],
                            visual_themes: Sequence[str] = (), avoid_styles: Sequence[str] = (),
                            exclude_ids: Sequence[int] = ()) -> dict[str, Any] | None:
        """Pick (and download) the best unused image. Returns the images row, or None."""
        pool = [i for i in await self.db.list_images_for_poem(poem_id) if i["id"] not in exclude_ids]
        if not pool and await self.searches_today() < self.settings.image_daily_limit:
            await self._spend()
            await self._fresh_search(poem_id, poem_text, emotions, visual_themes, avoid_styles)
            pool = [i for i in await self.db.list_images_for_poem(poem_id) if i["id"] not in exclude_ids]
        elif not pool:
            log.info("image budget used up for today; post will go without a new image")
        for row in pool[:6]:
            ready = await self._prepare(row, avoid_styles)
            if ready:
                return ready
        return None

    async def _fresh_search(self, poem_id: int, poem_text: str, emotions: Sequence[dict[str, Any]],
                            visual_themes: Sequence[str], avoid_styles: Sequence[str]) -> None:
        queries = await self.brain.image_queries(poem_text, emotions, visual_themes, avoid_styles)
        seen: set[str] = set()
        candidates: list[ImageCandidate] = []
        for q in queries:
            for c in await self.search_all(q):
                reason = self.validate(c)
                if reason or c.url in seen:
                    if reason:
                        log.debug("image rejected (%s): %s", reason, c.url[:80])
                    continue
                seen.add(c.url)
                candidates.append(c)
        scored = [(self._heuristic(c, queries, avoid_styles), c) for c in candidates]
        scored.sort(key=lambda t: -t[0])
        for rank, (heuristic, c) in enumerate(scored[:10]):
            final = heuristic
            if rank < 3 and self.settings.image_ai_judge:               # AI judges only the top few (cost)
                ai = await self.brain.judge_image_match(poem_text, c.description)
                if ai is not None:
                    final = 0.5 * heuristic + 0.5 * ai
            await self.db.add_image(poem_id, c.url, c.source, license=c.license, attribution=c.attribution,
                                    width=c.width, height=c.height, match_score=round(final, 1), search_query=c.query)

    async def _prepare(self, row: dict[str, Any], avoid_styles: Sequence[str]) -> dict[str, Any] | None:
        """Download and fingerprint one candidate; reject it if it was already used."""
        if await self.db.image_in_use(url=row["url"], exclude_id=row["id"]):
            await self.db.invalidate_image(row["id"])
            return None
        if self.local_file(row["id"]) is None or not row.get("image_hash"):
            try:
                _, digest = await self.http.download_image(row["url"], self.settings.image_dir, str(row["id"]))
            except HTTPError as exc:
                log.warning("image download failed (%s): %s", row["url"][:80], exc)
                await self.db.invalidate_image(row["id"])
                return None
            if await self.db.image_in_use(image_hash=digest, exclude_id=row["id"]):
                await self.db.invalidate_image(row["id"])
                return None
            await self.db.set_image_hash(row["id"], digest)
        return await self.db.get_image(row["id"])

    def caption_credit(self, image: dict[str, Any] | None) -> str:
        """Attribution line to print under the post (only when the license asks for it)."""
        if image and image.get("attribution") and self.attribution_required(image.get("license") or ""):
            return f"📷 {image['attribution']}"
        return ""
