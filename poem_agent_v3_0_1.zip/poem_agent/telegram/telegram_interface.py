"""Telegram interface (main file 09/10).

Two Telethon clients:
* bot client  - talks to the owner (previews, buttons, replies) and publishes to
                the target channel (the bot must be an admin there).
* user client - a spare personal account used ONLY to read public source
                channels. It logs in once with `python main.py --login`.

Only messages/button presses from OWNER_TELEGRAM_ID are ever handled.
Telethon is imported lazily so the rest of the project (and its tests) work
without it installed.
"""
from __future__ import annotations

import asyncio
import importlib
import logging
import re
from typing import Any, Awaitable, Callable, Sequence

from config.constants import TELEGRAM_CAPTION_LIMIT, TELEGRAM_TEXT_LIMIT
from config.settings import Settings
from core.errors import PublishError, SourceUnavailable
from core.models import PostBundle, SourceMessage

log = logging.getLogger(__name__)
TextHandler = Callable[[str], Awaitable[None]]
CallbackHandler = Callable[[str], Awaitable[None]]


# ---------------------------------------------------------------------------
# pure helpers (unit-tested without Telegram)
# ---------------------------------------------------------------------------
def preview_buttons(post_id: int) -> list[list[tuple[str, str]]]:
    """(label, callback_data) rows shown under every preview."""
    return [
        [("✅ တင်မယ်", f"ap:{post_id}"), ("❌ မကြိုက်ဘူး", f"rj:{post_id}")],
        [("🖼 ပုံပြောင်း", f"im:{post_id}"), ("⏭ နောက်တစ်ပုဒ်", f"nx:{post_id}")],
        [("🗓 မနက်ဖြန်အတွက် သိမ်း", f"sc:{post_id}")],
    ]


def parse_callback(data: str) -> tuple[str, int] | None:
    m = re.fullmatch(r"(ap|rj|im|nx|sc):(\d+)", data)
    return (m.group(1), int(m.group(2))) if m else None


def link_to_entity(link: str) -> str:
    """'https://t.me/name/12' | 't.me/name' | '@name' -> '@name' (public channels only)."""
    s = link.strip()
    m = re.search(r"(?:t\.me/|^@)([A-Za-z][\w]{3,})", s)
    if not m or "joinchat" in s or "/+" in s:
        raise SourceUnavailable(f"not a public channel link: {link}")
    return "@" + m.group(1)


def to_source_message(msg: Any, channel_link: str, username: str | None = None,
                      channel_id: int | None = None) -> SourceMessage | None:
    """Convert a Telethon message (duck-typed) into our SourceMessage."""
    mid = getattr(msg, "id", None)
    if mid is None:
        return None
    text = getattr(msg, "message", None) or getattr(msg, "raw_text", None) or ""
    date = getattr(msg, "date", None)
    if username:
        link = f"https://t.me/{username}/{mid}"
    elif channel_id:
        link = f"https://t.me/c/{channel_id}/{mid}"
    else:
        link = ""
    return SourceMessage(channel_link, int(mid), text, date.isoformat() if date else "",
                         bool(getattr(msg, "media", None)), link)


def message_stats(msg: Any) -> tuple[int, int, int]:
    """(views, reactions, forwards) from a Telethon channel message."""
    reactions = getattr(msg, "reactions", None)
    results = getattr(reactions, "results", None) or []
    return (int(getattr(msg, "views", 0) or 0), sum(int(getattr(r, "count", 0) or 0) for r in results),
            int(getattr(msg, "forwards", 0) or 0))


def parse_target(value: str) -> int | str:
    v = value.strip()
    return int(v) if re.fullmatch(r"-?\d+", v) else v


# ---------------------------------------------------------------------------
class TelegramInterface:
    def __init__(self, settings: Settings, telethon_module: Any | None = None) -> None:
        self.settings = settings
        self._tl = telethon_module
        self.bot: Any = None
        self.user: Any = None
        self._on_text: TextHandler | None = None
        self._on_callback: CallbackHandler | None = None
        self._previews: dict[int, tuple[int, str]] = {}      # post_id -> (message_id, text)

    # ------------------------------------------------------------- lifecycle
    def telethon(self) -> Any:
        if self._tl is None:
            try:
                self._tl = importlib.import_module("telethon")
            except ImportError as exc:
                raise RuntimeError("Telethon is not installed. Run: pip install -r requirements.txt") from exc
        return self._tl

    def set_handlers(self, on_text: TextHandler, on_callback: CallbackHandler) -> None:
        self._on_text, self._on_callback = on_text, on_callback

    def is_owner(self, sender_id: int | None) -> bool:
        return bool(sender_id) and sender_id == self.settings.owner_id

    def _session(self, name: str) -> str:
        self.settings.session_dir.mkdir(parents=True, exist_ok=True)
        return str(self.settings.session_dir / name)

    async def start(self, with_user_client: bool = True) -> None:
        tl, s = self.telethon(), self.settings
        self.bot = tl.TelegramClient(self._session("bot"), s.api_id, s.api_hash)
        await self.bot.start(bot_token=s.bot_token)
        self.bot.add_event_handler(self._handle_message, tl.events.NewMessage(incoming=True))
        self.bot.add_event_handler(self._handle_callback, tl.events.CallbackQuery())
        if with_user_client and (s.session_dir / "user.session").exists():
            self.user = tl.TelegramClient(self._session("user"), s.api_id, s.api_hash)
            await self.user.connect()
            if not await self.user.is_user_authorized():
                log.warning("user session is not authorised; run `python main.py --login`")
                await self.user.disconnect()
                self.user = None
        elif with_user_client:
            log.warning("no user session yet: source channels cannot be read until `python main.py --login`")
        log.info("telegram interface started (user client: %s)", "on" if self.user else "off")

    async def login_user(self) -> None:
        """Interactive one-time login of the spare account (asks phone, code, 2FA in the console)."""
        tl, s = self.telethon(), self.settings
        client = tl.TelegramClient(self._session("user"), s.api_id, s.api_hash)
        await client.start()                                  # prompts on the console
        me = await client.get_me()
        log.info("logged in as %s", getattr(me, "first_name", "?"))
        await client.disconnect()

    async def stop(self) -> None:
        for client in (self.bot, self.user):
            if client is not None:
                try:
                    await client.disconnect()
                except Exception:  # noqa: BLE001 - shutting down anyway
                    log.exception("error while disconnecting")

    # --------------------------------------------------------------- inbound
    async def _handle_message(self, event: Any) -> None:
        if not getattr(event, "is_private", True):
            return
        if not self.is_owner(getattr(event, "sender_id", None)):
            log.warning("ignored message from unauthorised user %s", getattr(event, "sender_id", None))
            return
        if self._on_text is not None:
            await self._on_text(getattr(event, "raw_text", "") or "")

    async def _handle_callback(self, event: Any) -> None:
        if not self.is_owner(getattr(event, "sender_id", None)):
            log.warning("ignored button press from unauthorised user %s", getattr(event, "sender_id", None))
            return
        try:
            await event.answer()
        except Exception:  # noqa: BLE001 - answering is cosmetic
            log.debug("callback answer failed", exc_info=True)
        data = (event.data or b"").decode("utf-8", "replace")
        if self._on_callback is not None:
            await self._on_callback(data)

    # -------------------------------------------------------------- outbound
    async def _guard(self, make: Callable[[], Awaitable[Any]], what: str) -> Any:
        """Run a Telegram call; sleep through short flood-waits."""
        flood = getattr(self.telethon().errors, "FloodWaitError", ())
        for attempt in range(3):
            try:
                return await make()
            except flood as exc:                              # type: ignore[misc]
                wait = int(getattr(exc, "seconds", 30)) + 1
                log.warning("flood wait %ss during %s", wait, what)
                if wait > 300 or attempt == 2:
                    raise
                await asyncio.sleep(wait)

    def _buttons(self, rows: list[list[tuple[str, str]]]) -> Any:
        btn = self.telethon().Button
        return [[btn.inline(label, data.encode()) for label, data in row] for row in rows]

    async def send_owner(self, text: str, buttons: list[list[tuple[str, str]]] | None = None) -> int | None:
        try:
            msg = await self._guard(lambda: self.bot.send_message(
                self.settings.owner_id, text[:TELEGRAM_TEXT_LIMIT],
                buttons=self._buttons(buttons) if buttons else None), "send_owner")
            return msg.id
        except ValueError:
            log.error("cannot message the owner: open the bot in Telegram and press Start first")
        except Exception:  # noqa: BLE001
            log.exception("send_owner failed")
        return None

    async def send_preview(self, bundle: PostBundle, header: str, footer: str) -> int | None:
        text = f"{header}\n\n{bundle.text}\n\n{footer}"
        rows = self._buttons(preview_buttons(bundle.post_id))
        owner = self.settings.owner_id
        try:
            if bundle.image_path and len(text) <= TELEGRAM_CAPTION_LIMIT:
                msg = await self._guard(lambda: self.bot.send_file(owner, bundle.image_path, caption=text, buttons=rows),
                                        "send_preview")
            else:
                if bundle.image_path:
                    await self._guard(lambda: self.bot.send_file(owner, bundle.image_path), "send_preview image")
                msg = await self._guard(lambda: self.bot.send_message(owner, text[:TELEGRAM_TEXT_LIMIT], buttons=rows,
                                                                      link_preview=False), "send_preview")
        except Exception:  # noqa: BLE001
            log.exception("send_preview failed for post %s", bundle.post_id)
            return None
        self._previews[bundle.post_id] = (msg.id, text)
        if len(self._previews) > 200:
            self._previews.pop(next(iter(self._previews)))
        return msg.id

    async def mark_preview(self, post_id: int, status: str) -> None:
        """Replace the buttons of an old preview by a status line."""
        entry = self._previews.get(post_id)
        if not entry:
            return
        msg_id, text = entry
        try:
            await self.bot.edit_message(self.settings.owner_id, msg_id, text=f"{text[:3800]}\n\n{status}", buttons=None)
        except Exception:  # noqa: BLE001 - e.g. message unchanged / too old
            log.debug("mark_preview failed", exc_info=True)

    async def publish(self, bundle: PostBundle) -> int:
        """Send the post to the target channel. Returns the message id."""
        target = parse_target(self.settings.target_channel)
        try:
            if bundle.image_path and not bundle.split:
                msg = await self._guard(lambda: self.bot.send_file(target, bundle.image_path, caption=bundle.text), "publish")
            elif bundle.image_path:
                await self._guard(lambda: self.bot.send_file(target, bundle.image_path), "publish image")
                msg = await self._guard(lambda: self.bot.send_message(target, bundle.text, link_preview=False), "publish text")
            else:
                msg = await self._guard(lambda: self.bot.send_message(target, bundle.text, link_preview=False), "publish")
        except Exception as exc:
            raise PublishError(f"{type(exc).__name__}: {exc}") from exc
        return int(msg.id)

    # ------------------------------------------------------ reading channels
    async def fetch_new_messages(self, link: str, min_id: int = 0, limit: int = 30) -> list[SourceMessage]:
        """New messages of a public channel, oldest first (first scan: only the latest `limit`)."""
        if self.user is None:
            raise SourceUnavailable("user account is not logged in (run `python main.py --login`)")
        tl = self.telethon()
        handle = link_to_entity(link)
        flood = getattr(tl.errors, "FloodWaitError", ())
        for attempt in range(2):
            try:
                entity = await self.user.get_entity(handle)
                if min_id == 0:
                    msgs = list(await self.user.get_messages(entity, limit=limit))
                    msgs.reverse()
                else:
                    msgs = [m async for m in self.user.iter_messages(entity, min_id=min_id, reverse=True, limit=limit)]
                username = getattr(entity, "username", None)
                channel_id = getattr(entity, "id", None)
                converted = (to_source_message(m, link, username, channel_id) for m in msgs)
                return [c for c in converted if c is not None]
            except flood as exc:                              # type: ignore[misc]
                wait = int(getattr(exc, "seconds", 30)) + 1
                if wait > 300 or attempt == 1:
                    raise SourceUnavailable(f"flood wait {wait}s on {handle}") from exc
                log.warning("flood wait %ss while reading %s", wait, handle)
                await asyncio.sleep(wait)
            except SourceUnavailable:
                raise
            except Exception as exc:  # private/invalid/banned channel, network ...
                raise SourceUnavailable(f"{handle}: {type(exc).__name__}: {exc}") from exc
        raise SourceUnavailable(f"could not read {handle}")

    async def fetch_stats(self, channel: str, message_ids: Sequence[int]) -> dict[int, tuple[int, int, int]]:
        """(views, reactions, forwards) per message id of our own channel."""
        client = self.user or self.bot
        found = await client.get_messages(parse_target(channel), ids=list(message_ids))
        out: dict[int, tuple[int, int, int]] = {}
        for msg in found if isinstance(found, list) else [found]:
            if msg is not None:
                out[int(msg.id)] = message_stats(msg)
        return out
