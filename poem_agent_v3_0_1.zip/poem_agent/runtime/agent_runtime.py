"""Bounded agent execution loop with cancellation, budgets and trace events."""
from __future__ import annotations

import asyncio
import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Awaitable, Callable, Mapping

from runtime.event_bus import AgentEvent, EventBus

log = logging.getLogger(__name__)

@dataclass(frozen=True)
class RuntimeLimits:
    max_steps: int = 8
    max_wall_seconds: float = 90.0
    max_tool_calls: int = 12
    max_output_chars: int = 12000

    def normalized(self) -> "RuntimeLimits":
        return RuntimeLimits(max(1, min(int(self.max_steps), 30)),
            max(1.0, min(float(self.max_wall_seconds), 600.0)),
            max(1, min(int(self.max_tool_calls), 60)),
            max(500, min(int(self.max_output_chars), 50000)))

@dataclass
class RuntimeTrace:
    run_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    started_at: float = field(default_factory=time.monotonic)
    steps: list[dict[str, Any]] = field(default_factory=list)
    tool_calls: int = 0
    status: str = "running"

class AgentRuntime:
    """Executes supplied trusted steps; planning and tool authorization remain separate."""
    def __init__(self, event_bus: EventBus | None = None, limits: RuntimeLimits | None = None) -> None:
        self.events = event_bus or EventBus()
        self.limits = (limits or RuntimeLimits()).normalized()

    async def run(self, steps: list[Callable[[], Any]], *, context: Mapping[str, Any] | None = None,
                  stop: asyncio.Event | None = None) -> dict[str, Any]:
        if len(steps) > self.limits.max_steps:
            raise ValueError("runtime step budget exceeded")
        trace = RuntimeTrace()
        await self.events.publish(AgentEvent("runtime.started", {"run_id": trace.run_id, "context_keys": list((context or {}).keys())[:30]}))
        try:
            for index, callback in enumerate(steps, 1):
                if stop and stop.is_set():
                    trace.status = "cancelled"
                    break
                if time.monotonic() - trace.started_at > self.limits.max_wall_seconds:
                    trace.status = "timeout"
                    break
                if trace.tool_calls >= self.limits.max_tool_calls:
                    trace.status = "budget_exhausted"
                    break
                started = time.monotonic()
                try:
                    result = callback()
                    if hasattr(result, "__await__"):
                        result = await asyncio.wait_for(result, timeout=self.limits.max_wall_seconds)
                    text = str(result)[:self.limits.max_output_chars]
                    trace.steps.append({"index": index, "status": "done", "elapsed_ms": int((time.monotonic()-started)*1000), "result": text})
                    trace.tool_calls += 1
                    await self.events.publish("runtime.step.completed", {"run_id": trace.run_id, "index": index})
                except asyncio.CancelledError:
                    trace.status = "cancelled"
                    raise
                except Exception as exc:
                    trace.steps.append({"index": index, "status": "failed", "error": f"{type(exc).__name__}: {str(exc)[:300]}"})
                    trace.status = "failed"
                    await self.events.publish("runtime.step.failed", {"run_id": trace.run_id, "index": index})
                    break
            else:
                trace.status = "completed"
        finally:
            await self.events.publish("runtime.finished", {"run_id": trace.run_id, "status": trace.status,
                                                             "steps": len(trace.steps), "tool_calls": trace.tool_calls})
        return {"run_id": trace.run_id, "status": trace.status, "steps": trace.steps,
                "elapsed_ms": int((time.monotonic()-trace.started_at)*1000), "tool_calls": trace.tool_calls}
