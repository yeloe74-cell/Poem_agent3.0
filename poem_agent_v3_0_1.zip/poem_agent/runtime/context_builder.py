"""Deterministic context assembly with per-source budgets and secret filtering."""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Iterable, Mapping

_SECRET = re.compile(r"(?i)(?:api[_ -]?key|password|passwd|secret|private[_ -]?key|seed phrase|otp)\s*[:=]\s*[^\s,;]+")

@dataclass(frozen=True)
class ContextSection:
    name: str
    content: str
    priority: int = 50
    max_chars: int = 2000

class ContextBuilder:
    """Build compact, stable prompts without allowing one source to dominate."""
    def __init__(self, *, total_chars: int = 9000, max_sections: int = 12) -> None:
        self.total_chars = max(500, min(int(total_chars), 50000))
        self.max_sections = max(1, min(int(max_sections), 40))

    @staticmethod
    def sanitize(value: Any, limit: int) -> str:
        text = str(value or "").replace("\x00", " ").strip()
        text = _SECRET.sub("[REDACTED]", text)
        return text[:max(0, limit)]

    def build(self, sections: Iterable[ContextSection]) -> dict[str, Any]:
        normalized = sorted(list(sections), key=lambda item: (item.priority, item.name))[:self.max_sections]
        remaining = self.total_chars
        result: list[dict[str, str]] = []
        for section in normalized:
            if remaining <= 0:
                break
            budget = min(max(0, section.max_chars), remaining)
            content = self.sanitize(section.content, budget)
            if content:
                result.append({"name": section.name[:80], "content": content})
                remaining -= len(content)
        return {"sections": result, "characters": self.total_chars - remaining,
                "truncated": remaining == 0}

    def from_mapping(self, values: Mapping[str, Any], *, priority: int = 50) -> dict[str, Any]:
        sections = [ContextSection(str(key), str(value), priority, 1800)
                    for key, value in values.items() if value not in (None, "", [], {})]
        return self.build(sections)
