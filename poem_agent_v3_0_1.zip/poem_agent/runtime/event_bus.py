"""Typed asynchronous event bus with bounded delivery and failure isolation."""
from __future__ import annotations

import asyncio
import inspect
import logging
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Awaitable, Callable, Mapping

log = logging.getLogger(__name__)
Handler = Callable[["AgentEvent"], Any | Awaitable[Any]]

@dataclass(frozen=True, slots=True)
class AgentEvent:
    """Immutable event envelope shared between runtime subsystems."""
    name: str
    payload: Mapping[str, Any] = field(default_factory=dict)
    event_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    occurred_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    correlation_id: str | None = None

    def __post_init__(self) -> None:
        if not self.name or len(self.name) > 100:
            raise ValueError("event name must contain 1-100 characters")
        if len(repr(dict(self.payload))) > 12000:
            raise ValueError("event payload is too large")

class EventBus:
    """In-process pub/sub; handlers are isolated so one failure cannot block others."""
    def __init__(self, *, handler_timeout: float = 10.0, max_handlers: int = 64) -> None:
        self.handler_timeout = max(0.1, min(float(handler_timeout), 60.0))
        self.max_handlers = max(1, min(int(max_handlers), 512))
        self._handlers: dict[str, dict[str, Handler]] = {}
        self._lock = asyncio.Lock()
        self._closed = False
        self._published = 0
        self._failed = 0

    async def subscribe(self, event_name: str, handler: Handler) -> str:
        if self._closed:
            raise RuntimeError("event bus is closed")
        if not callable(handler):
            raise TypeError("handler must be callable")
        async with self._lock:
            total = sum(len(group) for group in self._handlers.values())
            if total >= self.max_handlers:
                raise RuntimeError("event handler capacity reached")
            token = uuid.uuid4().hex
            self._handlers.setdefault(event_name, {})[token] = handler
            return token

    async def unsubscribe(self, token: str) -> bool:
        async with self._lock:
            for event_name, handlers in list(self._handlers.items()):
                if token in handlers:
                    del handlers[token]
                    if not handlers:
                        del self._handlers[event_name]
                    return True
        return False

    async def publish(self, event: AgentEvent | str, payload: Mapping[str, Any] | None = None,
                      *, correlation_id: str | None = None) -> dict[str, int]:
        if self._closed:
            raise RuntimeError("event bus is closed")
        item = event if isinstance(event, AgentEvent) else AgentEvent(
            str(event), dict(payload or {}), correlation_id=correlation_id)
        async with self._lock:
            handlers = list(self._handlers.get(item.name, {}).values())
            handlers += list(self._handlers.get("*", {}).values())
        succeeded = failed = 0
        for handler in handlers:
            try:
                result = handler(item)
                if inspect.isawaitable(result):
                    await asyncio.wait_for(result, timeout=self.handler_timeout)
                succeeded += 1
            except asyncio.CancelledError:
                raise
            except Exception:
                failed += 1
                log.exception("event handler failed for %s", item.name)
        self._published += 1
        self._failed += failed
        return {"delivered": succeeded, "failed": failed}

    def metrics(self) -> dict[str, int]:
        return {"published": self._published, "handler_failures": self._failed,
                "subscriptions": sum(len(x) for x in self._handlers.values())}

    async def close(self) -> None:
        async with self._lock:
            self._handlers.clear()
            self._closed = True
