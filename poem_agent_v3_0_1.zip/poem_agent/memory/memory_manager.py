"""Memory manager (main file 05/10).

* short-term  : in-process deque of recent chat turns + task context (e.g. which
                post the owner is currently looking at)
* conversation: persisted to `agent_memory` (type 'conversation'), trimmed
* preferences : owner likes/dislikes; temporary "too many X" avoidances expire
* feedback    : every owner reaction, so selection can learn from it

The model weights are never changed: "learning" means memory + configuration.
"""
from __future__ import annotations

import json
import logging
from collections import deque
from datetime import timedelta
from typing import Any

from config.constants import AVOID_COOLDOWN_DAYS
from core.time_utils import to_db, utcnow
from storage.database import Database

log = logging.getLogger(__name__)
CONVERSATION_KEEP = 200


class MemoryManager:
    def __init__(self, db: Database, short_term_size: int = 20) -> None:
        self.db = db
        self._turns: deque[dict[str, str]] = deque(maxlen=short_term_size)
        self._task_ctx: dict[str, Any] = {}

    # ------------------------------------------------------------------ startup
    async def load(self) -> None:
        """Restore the latest conversation turns after a restart."""
        rows = await self.db.list_memory("conversation", limit=self._turns.maxlen or 20)
        for row in reversed(rows):
            try:
                self._turns.append(json.loads(row["content"]))
            except json.JSONDecodeError:
                continue

    # ------------------------------------------------------- short-term / task
    def set_task_context(self, key: str, value: Any) -> None:
        self._task_ctx[key] = value

    def get_task_context(self, key: str, default: Any = None) -> Any:
        return self._task_ctx.get(key, default)

    def clear_task_context(self, key: str) -> None:
        self._task_ctx.pop(key, None)

    # ------------------------------------------------------------ conversation
    async def add_turn(self, role: str, text: str) -> None:
        turn = {"role": role, "text": text[:600]}
        self._turns.append(turn)
        await self.db.add_memory("conversation", json.dumps(turn, ensure_ascii=False), importance=1)
        await self.db.trim_memory("conversation", CONVERSATION_KEEP)

    def recent_turns(self, n: int = 6) -> list[dict[str, str]]:
        return list(self._turns)[-n:]

    # -------------------------------------------------------------- preferences
    async def remember_preference(self, key: str, content: str, importance: int = 3) -> None:
        await self.db.upsert_memory("preference", f"pref:{key}", content, importance)

    async def remember_style(self, key: str, content: str) -> None:
        await self.db.upsert_memory("channel_style", f"style:{key}", content, 3)

    async def add_feedback(self, text: str, intent: str, params: dict[str, Any] | None = None,
                           post_id: int | None = None, poem_id: int | None = None) -> None:
        """Keep the owner's own words (feedback table + searchable memory)."""
        await self.db.add_feedback(text, intent, params, post_id, poem_id, applied=True)
        await self.db.add_memory("feedback", json.dumps({"text": text[:300], "intent": intent, "params": params or {}},
                                                        ensure_ascii=False), importance=2)
        await self.db.trim_memory("feedback", 300)

    # ---------------------------------------------------------------- avoidance
    async def avoid(self, kind: str, key: str, days: int | None = AVOID_COOLDOWN_DAYS) -> None:
        """kind: 'emotion' | 'category' (temporary) | 'image_style' (permanent when days is None)."""
        expires = to_db(utcnow() + timedelta(days=days)) if days else None
        await self.db.upsert_memory("preference", f"avoid:{kind}:{key}", json.dumps({"kind": kind, "key": key}),
                                    importance=4, expires_at=expires)

    async def active_avoidances(self) -> dict[str, list[str]]:
        rows = await self.db.list_memory("preference", "avoid:", limit=200)
        out: dict[str, list[str]] = {"emotion": [], "category": [], "image_style": []}
        for row in rows:
            try:
                data = json.loads(row["content"])
            except json.JSONDecodeError:
                continue
            if data.get("kind") in out and data.get("key") not in out[data["kind"]]:
                out[data["kind"]].append(data["key"])
        return out

    async def clear_avoidance(self, kind: str, key: str) -> None:
        await self.db.delete_memory_key("preference", f"avoid:{kind}:{key}")

    # ------------------------------------------------------------------ context
    async def build_context(self) -> dict[str, Any]:
        """Compact summary handed to the AI when it interprets the owner."""
        prefs = await self.db.list_memory("preference", "pref:", limit=10)
        style = await self.db.list_memory("channel_style", limit=5)
        return {
            "pending_post_id": self.get_task_context("pending_post_id"),
            "recent_turns": self.recent_turns(6),
            "preferences": [p["content"] for p in prefs],
            "channel_style": [s["content"] for s in style],
            "avoid": await self.active_avoidances(),
        }

    async def purge(self) -> int:
        removed = await self.db.purge_expired_memory()
        if removed:
            log.info("purged %s expired memory rows", removed)
        return removed
