"""Episodic memory utilities: privacy filtering, ranking and controlled retention."""
from __future__ import annotations

import math
import re
from datetime import datetime, timedelta, timezone
from typing import Any, Iterable, Mapping

from core.time_utils import to_db

SECRET = re.compile(r"(?i)(api[_ -]?key|password|passwd|secret|private[_ -]?key|seed phrase|otp)\s*[:=]")
TOKEN = re.compile(r"[\w\u1000-\u109f]+", re.UNICODE)

class EpisodicMemory:
    """A lightweight retrieval layer that can sit over the existing SQLite memory table."""
    def __init__(self, db: Any, *, max_content: int = 1800, retention_days: int = 365) -> None:
        self.db = db
        self.max_content = max(100, min(int(max_content), 10000))
        self.retention_days = max(1, min(int(retention_days), 3650))

    @staticmethod
    def is_sensitive(text: str) -> bool:
        return bool(SECRET.search(str(text)))

    async def remember(self, key: str, content: str, *, category: str = "fact", importance: int = 3) -> bool:
        if not key.strip() or not content.strip() or self.is_sensitive(content):
            return False
        if not 1 <= int(importance) <= 5:
            raise ValueError("importance must be between 1 and 5")
        safe_key = f"episode:{category[:30]}:{key.strip().lower()[:100]}"
        expires_at = to_db(datetime.now(timezone.utc) + timedelta(days=self.retention_days))
        await self.db.upsert_memory("long_term", safe_key, content.strip()[:self.max_content],
                                    importance=int(importance), expires_at=expires_at)
        return True

    async def retrieve(self, query: str, *, limit: int = 8) -> list[dict[str, Any]]:
        terms = set(x.casefold() for x in TOKEN.findall(query) if len(x) > 1)
        if not terms:
            return []
        rows = await self.db.list_memory("long_term", "episode:", limit=300)
        now = datetime.now(timezone.utc)
        ranked = []
        for row in rows:
            content = str(row.get("content", ""))
            key = str(row.get("mem_key", ""))
            tokens = set(x.casefold() for x in TOKEN.findall(content + " " + key))
            overlap = len(terms & tokens)
            if not overlap:
                continue
            updated = row.get("updated_at") or row.get("created_at")
            age_days = 0.0
            if updated:
                try:
                    age = datetime.fromisoformat(str(updated).replace("Z", "+00:00"))
                    if age.tzinfo is None:
                        age = age.replace(tzinfo=timezone.utc)
                    age_days = max(0.0, (now - age).total_seconds() / 86400)
                except ValueError:
                    pass
            importance = int(row.get("importance", 3))
            score = (overlap / math.sqrt(max(1, len(tokens)))) * (1 + importance / 5) * math.exp(-age_days / 180)
            ranked.append((score, {"key": key, "content": content, "score": round(score, 4), "age_days": round(age_days, 1)}))
        ranked.sort(key=lambda item: item[0], reverse=True)
        return [item for _, item in ranked[:max(1, min(int(limit), 30))]]

    async def forget(self, key: str, *, category: str = "fact") -> bool:
        if not key.strip() or not category.strip():
            return False
        target = f"episode:{category[:30]}:{key.strip().lower()[:100]}"
        await self.db.delete_memory_key("long_term", target)
        return True
