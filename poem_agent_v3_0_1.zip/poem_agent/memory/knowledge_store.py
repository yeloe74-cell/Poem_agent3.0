"""Small SQLite-backed knowledge retrieval layer.

This is a lightweight local retrieval baseline, not a vector database. It uses
Unicode-aware token overlap and recency/importance weighting, so it works with
no embedding API and no additional dependency. A future embedding backend can
implement the same search interface.
"""
from __future__ import annotations

import re
from collections import Counter
from typing import Any, Iterable

from storage.database import Database

_STOP = {"the", "and", "for", "with", "that", "this", "from", "have", "မယ်", "တယ်", "ကို", "သည်", "မှာ"}

class KnowledgeStore:
    def __init__(self, db: Database, *, max_content: int = 5000) -> None:
        self.db = db
        self.max_content = max(200, min(int(max_content), 20000))

    async def add(self, key: str, content: str, *, category: str = "note", importance: int = 2) -> None:
        if not isinstance(key, str) or not key.strip() or len(key) > 120:
            raise ValueError("knowledge key must contain 1-120 characters")
        if not isinstance(content, str) or not content.strip() or len(content) > self.max_content:
            raise ValueError("knowledge content is empty or too long")
        if not re.fullmatch(r"[a-zA-Z0-9_ -]{1,40}", category):
            raise ValueError("invalid knowledge category")
        if type(importance) is not int or not 1 <= importance <= 5:
            raise ValueError("importance must be 1-5")
        await self.db.upsert_memory("long_term", f"knowledge:{category}:{key.strip().lower()}",
                                    content.strip(), importance=importance)

    async def search(self, query: str, *, category: str | None = None,
                     limit: int = 5, min_score: float = 0.08) -> list[dict[str, Any]]:
        if not isinstance(query, str) or not query.strip():
            return []
        limit = max(1, min(int(limit), 20))
        rows = await self.db.list_memory("long_term", "knowledge:", limit=500)
        terms = self._tokens(query)
        if not terms:
            return []
        scored: list[dict[str, Any]] = []
        for row in rows:
            key = str(row.get("mem_key", ""))
            knowledge_key = key.removeprefix("knowledge:")
            if category and not knowledge_key.startswith(category + ":"):
                continue
            content = str(row.get("content", ""))
            score = self._score(terms, self._tokens(key + " " + content))
            if score < min_score:
                continue
            score += min(int(row.get("importance", 1)), 5) * 0.015
            scored.append({"key": key, "content": content, "score": round(score, 4),
                           "importance": row.get("importance", 1),
                           "updated_at": row.get("updated_at")})
        scored.sort(key=lambda item: (item["score"], item["importance"]), reverse=True)
        return scored[:limit]

    async def forget(self, key: str, *, category: str = "note") -> None:
        await self.db.delete_memory_key("long_term", f"knowledge:{category}:{key.strip().lower()}")

    async def categories(self) -> list[str]:
        rows = await self.db.list_memory("long_term", "knowledge:", limit=500)
        return sorted({str(r.get("mem_key", "")).removeprefix("knowledge:").split(":", 1)[0]
                       for r in rows if str(r.get("mem_key", "")).startswith("knowledge:")})

    @staticmethod
    def _tokens(text: str) -> Counter[str]:
        # Keep Myanmar syllable-like chunks and English/digit terms intact.
        parts = re.findall(r"[\u1000-\u109f]+|[a-zA-Z0-9_]+", text.casefold())
        return Counter(p for p in parts if p not in _STOP and len(p) > 1)

    @staticmethod
    def _score(query: Counter[str], document: Counter[str]) -> float:
        if not query or not document:
            return 0.0
        overlap = sum(min(count, document.get(term, 0)) for term, count in query.items())
        coverage = overlap / max(1, sum(query.values()))
        precision = overlap / max(1, sum(document.values()))
        # Retrieval should reward query coverage even when a document chunk is
        # longer than the query; precision still contributes to ranking.
        return (0.8 * coverage + 0.2 * precision) if coverage + precision else 0.0

    async def context(self, query: str, *, limit: int = 4) -> list[str]:
        matches = await self.search(query, limit=limit)
        return [f"[{item['key']}] {item['content'][:700]}" for item in matches]
