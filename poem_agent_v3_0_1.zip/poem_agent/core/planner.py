"""Validated planning primitives for multi-step agent workflows.

Plans are proposals, not permission to execute. Every step must map to a
registered tool and every side-effecting step must pass ActionGuard later.
The planner intentionally does not run shell, Python, SQL, or arbitrary URLs.
"""
from __future__ import annotations

import json
import re
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, Iterable, Mapping

from core.errors import AIError

@dataclass(frozen=True)
class PlanStep:
    step_id: str
    title: str
    tool: str
    arguments: dict[str, Any] = field(default_factory=dict)
    depends_on: tuple[str, ...] = ()
    requires_approval: bool = False

@dataclass(frozen=True)
class ExecutionPlan:
    plan_id: str
    goal: str
    steps: tuple[PlanStep, ...]
    created_at: str
    status: str = "proposed"

    def as_dict(self) -> dict[str, Any]:
        return {"plan_id": self.plan_id, "goal": self.goal,
                "steps": [asdict(step) for step in self.steps],
                "created_at": self.created_at, "status": self.status}

class PlanValidationError(ValueError):
    """Raised when an AI-generated plan is incomplete or unsafe."""

class Planner:
    """Ask the configured AI for a plan and validate it deterministically."""
    SYSTEM = """Create a practical, minimal plan for the user's goal.
Return only JSON: {goal: string, steps: [{title, tool, arguments, depends_on,
requires_approval}]}. Use only the tool names supplied. Do not invent tools.
Do not include shell, arbitrary code, credential access, or destructive actions.
Mark any external or irreversible action as requires_approval=true. Prefer
read-only steps first. A plan is only a proposal and will not execute itself."""

    def __init__(self, brain: Any, allowed_tools: Iterable[str], *, max_steps: int = 12) -> None:
        self.brain = brain
        self.allowed_tools = frozenset(str(x) for x in allowed_tools)
        self.max_steps = max(1, min(int(max_steps), 20))

    async def create(self, goal: str, context: Mapping[str, Any] | None = None) -> ExecutionPlan:
        if not isinstance(goal, str) or not goal.strip() or len(goal) > 1800:
            raise PlanValidationError("goal must contain 1-1800 characters")
        if not getattr(self.brain, "available", False):
            raise AIError("AI provider is not available")
        prompt = {"goal": goal, "context": dict(context or {}),
                  "allowed_tools": sorted(self.allowed_tools),
                  "limits": {"max_steps": self.max_steps, "no_auto_execution": True}}
        raw, _model = await self.brain.complete(
            "conversation", self.SYSTEM, json.dumps(prompt, ensure_ascii=False, default=str),
            max_tokens=1100, temperature=0.1)
        payload = self._decode(raw)
        return self.validate(payload)

    @staticmethod
    def _decode(raw: str) -> dict[str, Any]:
        text = str(raw).strip()
        text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.I)
        left, right = text.find("{"), text.rfind("}")
        if left < 0 or right <= left:
            raise PlanValidationError("AI did not return a JSON object")
        try:
            value = json.loads(text[left:right + 1])
        except json.JSONDecodeError as exc:
            raise PlanValidationError("AI returned invalid JSON") from exc
        if not isinstance(value, dict):
            raise PlanValidationError("plan must be an object")
        return value

    def validate(self, payload: Mapping[str, Any]) -> ExecutionPlan:
        goal = payload.get("goal")
        raw_steps = payload.get("steps")
        if not isinstance(goal, str) or not goal.strip() or len(goal) > 1800:
            raise PlanValidationError("plan goal is missing or too long")
        if not isinstance(raw_steps, list) or not 1 <= len(raw_steps) <= self.max_steps:
            raise PlanValidationError(f"plan must contain 1-{self.max_steps} steps")
        steps: list[PlanStep] = []
        seen: set[str] = set()
        for index, raw in enumerate(raw_steps, 1):
            if not isinstance(raw, dict):
                raise PlanValidationError(f"step {index} is not an object")
            title = raw.get("title")
            tool = raw.get("tool")
            args = raw.get("arguments", {})
            deps = raw.get("depends_on", [])
            approval = raw.get("requires_approval", False)
            if not isinstance(title, str) or not title.strip() or len(title) > 180:
                raise PlanValidationError(f"step {index} has an invalid title")
            if not isinstance(tool, str) or tool not in self.allowed_tools:
                raise PlanValidationError(f"step {index} uses an unavailable tool")
            if not isinstance(args, dict) or len(json.dumps(args, ensure_ascii=False, default=str)) > 2000:
                raise PlanValidationError(f"step {index} arguments are invalid")
            if not isinstance(deps, list) or len(deps) > self.max_steps:
                raise PlanValidationError(f"step {index} dependencies are invalid")
            if type(approval) is not bool:
                raise PlanValidationError(f"step {index} approval flag is invalid")
            step_id = f"s{index}"
            steps.append(PlanStep(step_id, title.strip(), tool, dict(args),
                                  tuple(str(x) for x in deps), approval))
            seen.add(step_id)
        self._validate_dependencies(steps, seen)
        self._validate_no_sensitive_arguments(steps)
        now = datetime.now(timezone.utc).isoformat(timespec="seconds")
        return ExecutionPlan(uuid.uuid4().hex[:16], goal.strip(), tuple(steps), now)

    @staticmethod
    def _validate_dependencies(steps: list[PlanStep], seen: set[str]) -> None:
        graph = {step.step_id: step.depends_on for step in steps}
        for step in steps:
            if len(set(step.depends_on)) != len(step.depends_on):
                raise PlanValidationError(f"step {step.step_id} repeats a dependency")
            for dependency in step.depends_on:
                if dependency not in seen or dependency == step.step_id:
                    raise PlanValidationError(f"step {step.step_id} has an invalid dependency")
                if int(dependency[1:]) >= int(step.step_id[1:]):
                    raise PlanValidationError("dependencies must point to earlier steps")
        for node in graph:
            Planner._visit(node, graph, set(), set())

    @staticmethod
    def _visit(node: str, graph: Mapping[str, tuple[str, ...]], active: set[str], done: set[str]) -> None:
        if node in active:
            raise PlanValidationError("plan contains a dependency cycle")
        if node in done:
            return
        active.add(node)
        for child in graph.get(node, ()):
            Planner._visit(child, graph, active, done)
        active.remove(node)
        done.add(node)

    @staticmethod
    def _validate_no_sensitive_arguments(steps: list[PlanStep]) -> None:
        forbidden = re.compile(r"(?i)(api[_ -]?key|password|secret|private[_ -]?key|seed phrase|otp)")
        for step in steps:
            serialized = json.dumps(step.arguments, ensure_ascii=False, default=str)
            if forbidden.search(serialized):
                raise PlanValidationError("plan arguments must not contain credentials")

    @staticmethod
    def render(plan: ExecutionPlan) -> str:
        lines = [f"အစီအစဉ်: {plan.goal}", f"Plan ID: {plan.plan_id}"]
        for step in plan.steps:
            approval = " · Owner approval လိုမယ်" if step.requires_approval else ""
            dependency = f" · Depends on {', '.join(step.depends_on)}" if step.depends_on else ""
            lines.append(f"{step.step_id}. {step.title} [{step.tool}]{dependency}{approval}")
        lines.append("ဒီအစီအစဉ်ဟာ အဆိုပြုချက်သာဖြစ်ပြီး အလိုအလျောက် မလုပ်ဆောင်ပါဘူး။")
        return "\n".join(lines)
