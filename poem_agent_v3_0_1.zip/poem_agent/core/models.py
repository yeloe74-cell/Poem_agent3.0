"""Plain data containers passed between modules."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class SourceMessage:
    """A message read from a source channel (already converted from Telegram)."""

    channel_link: str
    message_id: int
    text: str
    date: str = ""
    has_media: bool = False
    link: str = ""


@dataclass
class CreditInfo:
    """Who wrote a poem, as far as the source tells us. Never guessed."""

    status: str = "unknown"            # 'known' | 'unknown'
    author_name: str | None = None
    credit_text: str | None = None     # exactly as written, e.g. '#အောင်ချိန့်'
    confidence: float = 0.0
    source_link: str | None = None


@dataclass
class PoemAnalysis:
    emotions: list[dict[str, Any]] = field(default_factory=list)   # [{'name','score'}]
    categories: list[str] = field(default_factory=list)
    quality_score: float = 50.0
    quality_notes: str = ""
    visual_themes: list[str] = field(default_factory=list)
    model_used: str = ""


@dataclass
class Intent:
    name: str = "unknown"
    params: dict[str, Any] = field(default_factory=dict)
    confidence: float = 0.0
    clarification: str | None = None
    source: str = "rule"               # 'rule' | 'ai'


@dataclass
class ImageCandidate:
    url: str
    source: str
    license: str = ""
    attribution: str = ""
    width: int = 0
    height: int = 0
    description: str = ""
    query: str = ""
    page_url: str = ""
    rank: int = 0


@dataclass
class PostBundle:
    """Everything needed to preview or publish one post."""

    post_id: int
    poem_id: int
    text: str
    image_path: str | None = None
    split: bool = False                # caption too long -> image + separate text
    scheduled_at: str | None = None
    meta: dict[str, Any] = field(default_factory=dict)


@dataclass
class IngestResult:
    status: str                        # stored | duplicate | skipped | rejected | error
    poem_id: int | None = None
    reason: str = ""
