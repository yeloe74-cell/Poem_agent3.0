"""General-purpose assistant runtime for Poem Agent.

The poetry workflow remains the primary skill. This runtime adds a safe,
provider-agnostic conversational layer with persistent tasks, explicit tool
allow-lists, memory operations, and a strict boundary around side effects.
It never evaluates generated Python, shell commands, SQL, or arbitrary URLs.
"""
from __future__ import annotations

import ast
import asyncio
import json
import logging
import math
import operator
import re
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Callable, Mapping

from core.errors import AIError
from core.planner import Planner
from memory.knowledge_store import KnowledgeStore
from storage.database import Database
from tasks.workflow_engine import WorkflowEngine
from runtime.context_builder import ContextBuilder
from runtime.event_bus import EventBus
from runtime.agent_runtime import AgentRuntime, RuntimeLimits
from memory.episodic_memory import EpisodicMemory
from knowledge.ingestion import KnowledgeIngestor
from security.action_guard import ActionGuard, Risk
from security.policy_engine import ActionRisk
from tools.registry import ToolDefinition, ToolRegistry

log = logging.getLogger(__name__)

SCHEMA = """
CREATE TABLE IF NOT EXISTS agent_tasks (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    details TEXT NOT NULL DEFAULT '',
    state TEXT NOT NULL DEFAULT 'open'
        CHECK(state IN ('open','in_progress','done','cancelled')),
    priority INTEGER NOT NULL DEFAULT 2 CHECK(priority BETWEEN 1 AND 5),
    due_at TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_agent_tasks_state ON agent_tasks(state, priority, created_at);
CREATE TABLE IF NOT EXISTS agent_tool_audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tool_name TEXT NOT NULL,
    arguments TEXT NOT NULL,
    outcome TEXT NOT NULL,
    created_at TEXT NOT NULL
);
"""

@dataclass(frozen=True)
class ToolResult:
    """A serializable result returned by a registered tool."""
    ok: bool
    text: str
    data: Mapping[str, Any] | None = None

@dataclass(frozen=True)
class ToolSpec:
    """Tool metadata; approval is mandatory for future side-effect tools."""
    name: str
    description: str
    handler: Callable[[dict[str, Any]], Any]
    requires_approval: bool = False
    max_argument_chars: int = 2000

class SafeCalculator:
    """Evaluate arithmetic expressions using a tiny AST allow-list."""
    _binary = {ast.Add: operator.add, ast.Sub: operator.sub,
               ast.Mult: operator.mul, ast.Div: operator.truediv,
               ast.FloorDiv: operator.floordiv, ast.Mod: operator.mod,
               ast.Pow: operator.pow}
    _unary = {ast.UAdd: operator.pos, ast.USub: operator.neg}

    @classmethod
    def calculate(cls, expression: str) -> float:
        if not isinstance(expression, str) or len(expression) > 120:
            raise ValueError("expression is too long")
        if not re.fullmatch(r"[0-9+*/().%\-\s]+", expression):
            raise ValueError("only arithmetic characters are allowed")
        tree = ast.parse(expression, mode="eval")
        value = cls._node(tree.body, depth=0)
        if not math.isfinite(float(value)) or abs(value) > 10**15:
            raise ValueError("result is outside the supported range")
        return value

    @classmethod
    def _node(cls, node: ast.AST, depth: int) -> float:
        if depth > 12:
            raise ValueError("expression is too complex")
        if isinstance(node, ast.Constant) and type(node.value) in (int, float):
            return node.value
        if isinstance(node, ast.BinOp) and type(node.op) in cls._binary:
            left = cls._node(node.left, depth + 1)
            right = cls._node(node.right, depth + 1)
            if isinstance(node.op, ast.Pow) and abs(right) > 8:
                raise ValueError("power is too large")
            return cls._binary[type(node.op)](left, right)
        if isinstance(node, ast.UnaryOp) and type(node.op) in cls._unary:
            return cls._unary[type(node.op)](cls._node(node.operand, depth + 1))
        raise ValueError("unsupported arithmetic expression")

class GeneralAgent:
    """Safe general assistant layered beside the original poetry Agent."""
    TOOL_NAMES = ("calculate", "create_task", "list_tasks", "update_task",
                  "remember", "recall", "search_knowledge", "ingest_knowledge",
                  "create_plan", "create_workflow", "workflow_status",
                  "request_workflow_execution", "project_status")
    CONFIRMATION_TTL = 180.0   # seconds a workflow confirmation stays valid (same as ApprovalVault)
    CANCEL_WORDS = frozenset({"မလုပ်နဲ့", "မလုပ်တော့ဘူး", "မလုပ်တော့", "မလုပ်ပါနဲ့", "မလုပ်ဘူး", "cancel", "no", "နောက်မှ", "ရပ်လိုက်", "ပယ်ဖျက်"})
    CONFIRM_WORDS = frozenset({"အတည်ပြုလုပ်ဆောင်", "အတည်ပြုလုပ်ဆောင်ပါ", "အတည်ပြုပြီးလုပ်", "အတည်ပြု", "လုပ်ဆောင်ပါ", "လုပ်လိုက်", "လုပ်ပါ", "ဟုတ်", "ဟုတ်ကဲ့", "အိုကေ", "ok", "yes", "confirm", "approve"})
    SYSTEM_PROMPT = """You are the general assistant inside a Telegram owner-only agent.
Understand Burmese and English. Use recent context when relevant. The dedicated
Poetry Agent handles channel operations; do not claim to have published anything.
Return ONLY one JSON object with keys: response (string), tool_calls (array).
Each tool call has name and arguments. Allowed tools are listed by the user.
Call a tool only when needed. Never invent tool results, IDs, or completed actions.
Do not request or expose API keys, passwords, or private credentials. For external
side effects, explain that explicit owner approval is required. If uncertain, ask
one concise clarification instead of guessing. Keep Burmese natural and concise."""

    def __init__(self, db: Database, brain: Any, memory: Any,
                 *, max_calls: int = 3, timeout_seconds: float = 35.0,
                 context_chars: int = 8500, max_plan_steps: int = 12,
                 workflow_max_steps: int = 30, workflow_max_attempts: int = 3,
                 runtime_max_wall_seconds: float = 90.0, runtime_max_tool_calls: int = 12,
                 memory_retention_days: int = 365, knowledge_chunk_chars: int = 1200,
                 tool_timeout_seconds: float = 20.0, allow_internal_writes: bool = True) -> None:
        self.db, self.brain, self.memory = db, brain, memory
        self.max_calls = max(1, min(int(max_calls), 5))
        self.timeout_seconds = max(5.0, min(float(timeout_seconds), 90.0))
        self._tools: dict[str, ToolSpec] = {}
        self.registry = ToolRegistry()
        self.knowledge = KnowledgeStore(db, max_content=max(5000, min(int(knowledge_chunk_chars), 8000)))
        self.workflows = WorkflowEngine(db, max_steps=workflow_max_steps, max_attempts=workflow_max_attempts)
        self.max_plan_steps = max(1, min(int(max_plan_steps), 20))
        self.tool_timeout_seconds = max(1.0, min(float(tool_timeout_seconds), 120.0))
        self.episodic = EpisodicMemory(db, retention_days=memory_retention_days)
        self.knowledge_ingestor = KnowledgeIngestor(chunk_chars=knowledge_chunk_chars)
        self.context_builder = ContextBuilder(total_chars=context_chars, max_sections=12)
        self.events = EventBus(handler_timeout=8.0)
        self._pending_workflow_approval: dict[str, Any] | None = None
        self.runtime = AgentRuntime(self.events, RuntimeLimits(
            max_steps=self.max_plan_steps, max_wall_seconds=runtime_max_wall_seconds,
            max_tool_calls=runtime_max_tool_calls))
        self._register_builtin_tools()
        self.guard = ActionGuard(self._tools.keys(), auto_allow_internal_write=allow_internal_writes)

    async def initialize(self) -> None:
        """Create additive tables; safe to call repeatedly after DB open."""
        for statement in SCHEMA.split(";"):
            if statement.strip():
                await self.db.execute(statement)
        await self.workflows.initialize()

    def register_tool(self, spec: ToolSpec) -> None:
        """Register trusted application code, never model-generated code."""
        if not re.fullmatch(r"[a-z][a-z0-9_]{1,40}", spec.name):
            raise ValueError("invalid tool name")
        if spec.name in self._tools:
            raise ValueError(f"tool already registered: {spec.name}")
        if not callable(spec.handler):
            raise TypeError("tool handler must be callable")
        self._tools[spec.name] = spec
        configured_risk = ActionGuard.DEFAULT_RISK.get(spec.name, Risk.EXTERNAL)
        risk = ActionRisk.READ if configured_risk == Risk.READ else (
            ActionRisk.INTERNAL_WRITE if configured_risk == Risk.WRITE else ActionRisk.EXTERNAL)
        if spec.requires_approval:
            risk = ActionRisk.EXTERNAL
        self.registry.register(ToolDefinition(
            spec.name, spec.description, spec.handler, risk=risk,
            max_input_chars=spec.max_argument_chars,
            timeout_seconds=self.tool_timeout_seconds if hasattr(self, "tool_timeout_seconds") else 20.0,
        ))
        if hasattr(self, "guard"):
            self.guard.allowed_tools.add(spec.name)

    def tool_catalog(self) -> list[dict[str, Any]]:
        return self.registry.describe()

    def _register_builtin_tools(self) -> None:
        self.register_tool(ToolSpec("calculate", "Safely calculate a basic arithmetic expression.", self._calculate))
        self.register_tool(ToolSpec("create_task", "Create a personal task with title, details and priority.", self._create_task))
        self.register_tool(ToolSpec("list_tasks", "List open or all personal tasks.", self._list_tasks))
        self.register_tool(ToolSpec("update_task", "Mark a task done or cancelled using its task ID.", self._update_task))
        self.register_tool(ToolSpec("remember", "Save a non-sensitive preference or project fact for later.", self._remember))
        self.register_tool(ToolSpec("recall", "Search saved preferences and project notes.", self._recall))
        self.register_tool(ToolSpec("search_knowledge", "Search the local knowledge base.", self._search_knowledge))
        self.register_tool(ToolSpec("ingest_knowledge", "Chunk and store supplied plain-text knowledge locally.", self._ingest_knowledge, max_argument_chars=24000))
        self.register_tool(ToolSpec("create_plan", "Create a validated multi-step plan without executing it.", self._create_plan))
        self.register_tool(ToolSpec("create_workflow", "Save a validated, resumable workflow proposal without executing it.", self._create_workflow))
        self.register_tool(ToolSpec("workflow_status", "Inspect a saved workflow and its step states.", self._workflow_status))
        self.register_tool(ToolSpec("request_workflow_execution", "Request explicit owner confirmation before running a saved workflow.", self._request_workflow_execution))
        self.register_tool(ToolSpec("project_status", "Summarize the connected poetry project status.", self._project_status))

    async def handle(self, message: str) -> str:
        """Interpret an unhandled owner message and run safe allow-listed tools."""
        if not isinstance(message, str) or not message.strip():
            return "ဘာကိုကူညီပေးရမလဲ ပြောပြပါဦး။"
        self._expire_pending()
        if self._pending_workflow_approval is not None:
            return await self._resolve_workflow_confirmation(message)
        if not getattr(self.brain, "available", False) or not hasattr(self.brain, "complete"):
            return "ဒီအလုပ်ကို နားလည်ဖို့ AI Provider မရနိုင်သေးပါဘူး။"
        started = time.monotonic()
        context = self.context_builder.from_mapping(await self._context())
        prompt = {"owner_message": message[:1800], "context": context,
                  "tools": self.tool_catalog(),
                  "rules": ["Only call listed tools", "Never assume success",
                            "Do not publish or message external users", "Ask before irreversible actions"]}
        try:
            raw, model = await self.brain.complete(
                "conversation", self.SYSTEM_PROMPT,
                json.dumps(prompt, ensure_ascii=False, default=str),
                max_tokens=850, temperature=0.15)
            payload = self._parse_payload(raw)
            response = self._clean_response(payload.get("response", ""))
            calls = payload.get("tool_calls", [])
            if not isinstance(calls, list):
                calls = []
            results = await self._execute_calls(calls[:self.max_calls])
            if results:
                response = self._combine(response, results)
            if not response:
                response = "အလုပ်ကို စစ်ဆေးပြီးပါပြီ။ ဘာကို ဆက်လုပ်စေချင်လဲ ပြောပါ။"
            await self._audit("assistant_turn", {"model": model, "message": message[:500]}, "ok")
            await self.events.publish("assistant.turn.completed", {"model": model, "tool_count": len(results)})
            log.info("general assistant handled message in %.2fs", time.monotonic() - started)
            return response[:3500]
        except (AIError, ValueError, TypeError, KeyError) as exc:
            log.warning("general assistant could not process message: %s", exc)
            await self._audit("assistant_turn", {"message": message[:300]}, "failed")
            return "အဲဒီညွှန်ကြားချက်ကို သေချာမဖော်ထုတ်နိုင်သေးပါဘူး။ နည်းနည်းပိုရှင်းပြပေးပါဦး။"
        except Exception:
            log.exception("unexpected general assistant failure")
            await self._audit("assistant_turn", {"message": message[:300]}, "error")
            return "လုပ်ဆောင်နေစဉ် အမှားဖြစ်သွားပါတယ်။ မှတ်တမ်းထဲ သိမ်းထားပါတယ်။"

    async def _context(self) -> dict[str, Any]:
        recent = self.memory.recent_turns(6) if hasattr(self.memory, "recent_turns") else []
        preferences = await self.db.list_memory("preference", limit=12)
        notes = await self.db.list_memory("long_term", "note:", limit=12)
        knowledge = await self.knowledge.search(" ".join(t.get("text", "") for t in recent[-3:]), limit=4) if recent else []
        return {"recent_turns": recent,
                "preferences": [r["content"][:300] for r in preferences],
                "notes": [r["content"][:400] for r in notes],
                "relevant_knowledge": [r["content"][:400] for r in knowledge]}

    @staticmethod
    def _parse_payload(raw: str) -> dict[str, Any]:
        text = raw.strip()
        if text.startswith("```"):
            text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.I)
        start, end = text.find("{"), text.rfind("}")
        if start < 0 or end <= start:
            raise ValueError("model response did not contain JSON")
        value = json.loads(text[start:end + 1])
        if not isinstance(value, dict):
            raise ValueError("model response must be an object")
        return value

    @staticmethod
    def _clean_response(value: Any) -> str:
        if not isinstance(value, str):
            return ""
        text = value.strip()
        text = re.sub(r"(?i)(api[_ -]?key|password|secret)\s*[:=]\s*\S+", r"\1=[redacted]", text)
        return text[:2500]

    async def _execute_calls(self, calls: list[Any]) -> list[str]:
        results: list[str] = []
        for call in calls:
            if not isinstance(call, dict):
                continue
            name = call.get("name")
            args = call.get("arguments", {})
            if not isinstance(name, str) or name not in self._tools:
                results.append("မသိတဲ့ Tool တစ်ခုကို ခေါ်ဖို့ကြိုးစားတာကြောင့် ပယ်ချခဲ့ပါတယ်။")
                continue
            if not isinstance(args, dict) or len(json.dumps(args, ensure_ascii=False)) > self._tools[name].max_argument_chars:
                results.append("Tool argument မမှန်ကန်လို့ ပယ်ချခဲ့ပါတယ်။")
                await self._audit(name, {}, "invalid_arguments")
                continue
            spec = self._tools[name]
            decision = self.guard.assess(name)
            if spec.requires_approval or not decision.allowed:
                results.append(f"{name} ကို လုပ်ဆောင်ဖို့ Owner အတည်ပြုချက် လိုအပ်ပါတယ်။")
                await self._audit(name, args, "approval_required")
                continue
            try:
                execution = await self.registry.execute(name, args, approved=False)
                if not execution.ok:
                    results.append(f"{name} Tool ကို ပယ်ချခဲ့ပါတယ်: {execution.error or 'execution failed'}")
                    await self._audit(name, args, "rejected")
                    continue
                result = execution.output
                if not isinstance(result, ToolResult):
                    result = ToolResult(True, str(result))
                results.append(result.text[:900])
                await self._audit(name, args, "ok" if result.ok else "rejected")
                await self.events.publish("tool.executed", {"name": name, "ok": result.ok,
                                                              "elapsed_ms": execution.elapsed_ms})
            except Exception as exc:
                log.exception("tool %s failed", name)
                results.append(f"{name} Tool မှာ အမှားဖြစ်ပါတယ်: {str(exc)[:180]}")
                await self._audit(name, args, "error")
        return results

    @staticmethod
    def _combine(response: str, results: list[str]) -> str:
        useful = [r for r in results if r]
        if not useful:
            return response
        suffix = "\n\nလုပ်ဆောင်ချက်ရလဒ်:\n" + "\n".join(f"• {r}" for r in useful)
        return (response + suffix).strip()

    async def _calculate(self, args: dict[str, Any]) -> ToolResult:
        expression = args.get("expression", "")
        try:
            value = SafeCalculator.calculate(str(expression))
        except (ValueError, SyntaxError, ZeroDivisionError, OverflowError) as exc:
            return ToolResult(False, f"တွက်ချက်မှု မအောင်မြင်ပါ: {exc}")
        return ToolResult(True, f"{expression} = {value}", {"value": value})

    async def _create_task(self, args: dict[str, Any]) -> ToolResult:
        title = self._required_text(args, "title", 180)
        details = str(args.get("details", ""))[:1200]
        priority = args.get("priority", 2)
        if type(priority) is not int or not 1 <= priority <= 5:
            return ToolResult(False, "Priority ကို 1 မှ 5 အတွင်းပေးပါ။")
        task_id = uuid.uuid4().hex[:12]
        now = datetime.now(timezone.utc).isoformat(timespec="seconds")
        await self.db.execute("INSERT INTO agent_tasks(id,title,details,priority,created_at,updated_at) VALUES(?,?,?,?,?,?)",
                              (task_id, title, details, priority, now, now))
        return ToolResult(True, f"Task အသစ် ဖန်တီးပြီးပါပြီ။ ID: {task_id} · {title}", {"id": task_id})

    async def _list_tasks(self, args: dict[str, Any]) -> ToolResult:
        state = args.get("state", "open")
        if state not in ("open", "in_progress", "done", "cancelled", "all"):
            return ToolResult(False, "Task state မမှန်ပါ။")
        if state == "all":
            rows = await self.db.fetchall("SELECT * FROM agent_tasks ORDER BY priority DESC, created_at DESC LIMIT 30")
        else:
            rows = await self.db.fetchall("SELECT * FROM agent_tasks WHERE state=? ORDER BY priority DESC, created_at DESC LIMIT 30", (state,))
        if not rows:
            return ToolResult(True, "သက်ဆိုင်ရာ Task မရှိသေးပါဘူး။")
        lines = [f"{r['id']} · {r['title']} [{r['state']}] P{r['priority']}" for r in rows]
        return ToolResult(True, "Task စာရင်း:\n" + "\n".join(lines), {"tasks": rows})

    async def _update_task(self, args: dict[str, Any]) -> ToolResult:
        task_id = self._required_text(args, "task_id", 20)
        state = args.get("state")
        if state not in ("done", "cancelled", "in_progress", "open"):
            return ToolResult(False, "State ကို done/cancelled/in_progress/open ထဲက ရွေးပါ။")
        now = datetime.now(timezone.utc).isoformat(timespec="seconds")
        changed = await self.db.fetchone("UPDATE agent_tasks SET state=?,updated_at=? WHERE id=? RETURNING id", (state, now, task_id))
        if not changed:
            return ToolResult(False, "အဲဒီ Task ID ကို မတွေ့ပါဘူး။")
        return ToolResult(True, f"Task {task_id} ကို {state} အဖြစ် ပြောင်းပြီးပါပြီ။")

    async def _remember(self, args: dict[str, Any]) -> ToolResult:
        key = self._required_text(args, "key", 80)
        content = self._required_text(args, "content", 900)
        if re.search(r"(?i)(password|api[_ -]?key|private[_ -]?key|seed phrase|otp)\s*[:=]", content):
            return ToolResult(False, "လုံခြုံရေးအတွက် Secret သို့မဟုတ် Credential ကို Memory ထဲ မသိမ်းပါဘူး။")
        saved = await self.episodic.remember(key, content, category="note", importance=3)
        if not saved:
            return ToolResult(False, "လုံခြုံရေးစည်းမျဉ်းကြောင့် Memory ကို မသိမ်းနိုင်ပါဘူး။")
        return ToolResult(True, f"'{key}' ကို သက်တမ်းကန့်သတ်ထားတဲ့ Long-term Memory ထဲ သိမ်းထားပါတယ်။")

    async def _recall(self, args: dict[str, Any]) -> ToolResult:
        query = self._required_text(args, "query", 100).casefold()
        matches = await self.episodic.retrieve(query, limit=5)
        if not matches:
            return ToolResult(True, "သိမ်းထားတဲ့ Memory ထဲမှာ ကိုက်ညီတာ မတွေ့ပါဘူး။")
        return ToolResult(True, "တွေ့ရှိတဲ့ Memory:\n" + "\n".join(r["content"][:300] for r in matches))

    async def _search_knowledge(self, args: dict[str, Any]) -> ToolResult:
        query = self._required_text(args, "query", 180)
        matches = await self.knowledge.search(query, limit=5)
        if not matches:
            return ToolResult(True, "Knowledge Base ထဲမှာ ကိုက်ညီတာ မတွေ့ပါဘူး။")
        lines = [f"{item['key']} (score {item['score']}): {item['content'][:350]}" for item in matches]
        return ToolResult(True, "Knowledge ရှာဖွေမှုရလဒ်:\n" + "\n".join(lines))

    async def _ingest_knowledge(self, args: dict[str, Any]) -> ToolResult:
        content = self._required_text(args, "content", 20000)
        source = str(args.get("source", "owner_note"))[:300]
        category = str(args.get("category", "document"))[:40]
        result = await self.knowledge_ingestor.ingest(self.knowledge, content, source=source, category=category)
        return ToolResult(True, f"Knowledge ingestion ပြီးပါပြီ။ Chunks: {result['chunks']} · Stored: {result['inserted']}", result)

    async def _create_plan(self, args: dict[str, Any]) -> ToolResult:
        goal = self._required_text(args, "goal", 1200)
        meta_tools = {"create_plan", "create_workflow", "workflow_status", "request_workflow_execution"}
        allowed = [name for name in self._tools if name not in meta_tools]
        planner = Planner(self.brain, allowed, max_steps=self.max_plan_steps)
        plan = await planner.create(goal, await self._context())
        return ToolResult(True, Planner.render(plan), plan.as_dict())

    def _expire_pending(self) -> None:
        """Forget a workflow confirmation the owner never answered."""
        pending = self._pending_workflow_approval
        if pending is not None and time.monotonic() > pending.get("expires_at", 0.0):
            log.info("workflow confirmation for %s expired", pending.get("workflow_id"))
            self._pending_workflow_approval = None

    @property
    def has_pending_confirmation(self) -> bool:
        self._expire_pending()
        return self._pending_workflow_approval is not None

    @classmethod
    def is_confirmation_reply(cls, message: str) -> bool:
        """True when the message is a plain yes/no answer to a pending workflow question."""
        normalized = re.sub(r"\s+", " ", message.strip().casefold())
        return normalized in cls.CANCEL_WORDS or normalized in cls.CONFIRM_WORDS

    async def _request_workflow_execution(self, args: dict[str, Any]) -> ToolResult:
        workflow_id = self._required_text(args, "workflow_id", 64)
        if self._pending_workflow_approval is not None:
            return ToolResult(False, "အခြား Workflow တစ်ခု အတည်ပြုချက်စောင့်နေပါတယ်။")
        data = await self.workflows.get(workflow_id)
        if not data:
            return ToolResult(False, "Workflow ID ကို မတွေ့ပါဘူး။")
        if data["workflow"]["state"] not in {"proposed", "paused", "approved"}:
            return ToolResult(False, "ဒီ Workflow ကို လက်ရှိအခြေအနေမှာ စတင်လို့မရပါဘူး။")
        steps = data["steps"]
        self._pending_workflow_approval = {
            "workflow_id": workflow_id,
            "step_keys": [row["step_key"] for row in steps if row["state"] == "pending_approval"],
            "tool_names": sorted({row["tool_name"] for row in steps}),
            "expires_at": time.monotonic() + self.CONFIRMATION_TTL,
        }
        lines = [f"Workflow {workflow_id} ကို လုပ်ဆောင်ဖို့ အတည်ပြုချက်လိုပါတယ်။",
                 f"ရည်မှန်းချက်: {data['workflow']['goal']}"]
        lines.extend(f"{row['step_key']}. {row['tool_name']} · {row['state']} · {row['arguments']}" for row in steps)
        lines.append("အထက်ပါ Workflow တစ်ခုလုံးကို ခွင့်ပြုရင် 'အတည်ပြုလုပ်ဆောင်' လို့ ပြန်ပါ။ မလုပ်ချင်ရင် 'မလုပ်နဲ့' လို့ ပြန်ပါ။")
        return ToolResult(True, "\n".join(lines), {"workflow_id": workflow_id, "awaiting_owner": True})

    async def _resolve_workflow_confirmation(self, message: str) -> str:
        normalized = re.sub(r"\s+", " ", message.strip().casefold())
        cancel, confirm = self.CANCEL_WORDS, self.CONFIRM_WORDS
        if normalized in cancel:
            self._pending_workflow_approval = None
            return "Workflow ကို မလုပ်ဆောင်တော့ပါဘူး။ အစီအစဉ်အဖြစ်ပဲ သိမ်းထားပါတယ်။"
        if normalized not in confirm:
            return "Workflow အတည်ပြုချက် စောင့်နေပါတယ်။ လုပ်မယ်ဆို 'အတည်ပြုလုပ်ဆောင်'၊ မလုပ်ဘူးဆို 'မလုပ်နဲ့' လို့ ပြန်ပါ။"
        pending, self._pending_workflow_approval = self._pending_workflow_approval, None
        workflow_id = pending["workflow_id"]
        try:
            await self.workflows.approve(workflow_id, approved_steps=set(pending["step_keys"]))
            await self._audit("workflow_approval", {"workflow_id": workflow_id,
                                                       "approved_steps": pending["step_keys"],
                                                       "approved_tools": pending["tool_names"]}, "owner_confirmed")
            outcome = await self.execute_approved_workflow(workflow_id, approved_tools=set(pending["tool_names"]))
            await self._audit("workflow_execution", {"workflow_id": workflow_id}, outcome.get("state", "unknown"))
            return (f"Workflow {workflow_id} · {outcome.get('state')}\n"
                    f"ပြီးမြောက်: {', '.join(outcome.get('completed', [])) or '-'}\n"
                    f"မအောင်မြင်: {', '.join(outcome.get('failed', [])) or '-'}\n"
                    f"ခွင့်ပြုချက်/Dependency စောင့်နေ: {', '.join(outcome.get('blocked', [])) or '-'}")
        except Exception as exc:
            log.exception("approved workflow execution failed")
            await self._audit("workflow_execution", {"workflow_id": workflow_id}, "failed")
            return f"Workflow ကို ဆောင်ရွက်ရာမှာ အမှားဖြစ်ပါတယ်: {str(exc)[:240]}"

    async def _create_workflow(self, args: dict[str, Any]) -> ToolResult:
        goal = self._required_text(args, "goal", 1200)
        meta_tools = {"create_plan", "create_workflow", "workflow_status", "request_workflow_execution"}
        allowed = [name for name in self._tools if name not in meta_tools]
        planner = Planner(self.brain, allowed, max_steps=self.max_plan_steps)
        plan = await planner.create(goal, await self._context())
        raw_steps = []
        for item in plan.steps:
            raw_steps.append({"key": item.step_id, "title": item.title, "tool": item.tool,
                              "arguments": item.arguments, "depends_on": list(item.depends_on),
                              "requires_approval": item.requires_approval})
        workflow = self.workflows.validate(plan.goal, raw_steps, allowed)
        workflow_id = await self.workflows.create(workflow)
        summary = [f"Workflow ID: {workflow_id}", f"ရည်မှန်းချက်: {workflow.goal}"]
        summary.extend(f"{step.key}. {step.title} [{step.tool}]" for step in workflow.steps)
        summary.append("Workflow ကို သိမ်းထားပြီးဖြစ်ပါတယ်။ အတည်ပြုချက်မရှိဘဲ ဘယ် Tool ကိုမှ မလုပ်ဆောင်သေးပါဘူး။")
        return ToolResult(True, "\n".join(summary), {"workflow_id": workflow_id, "steps": len(workflow.steps)})

    async def _workflow_status(self, args: dict[str, Any]) -> ToolResult:
        workflow_id = self._required_text(args, "workflow_id", 64)
        data = await self.workflows.get(workflow_id)
        if not data:
            return ToolResult(False, "Workflow ID ကို မတွေ့ပါဘူး။")
        head = data["workflow"]
        lines = [f"Workflow: {head['id']}", f"State: {head['state']}", f"Goal: {head['goal']}"]
        lines.extend(f"{row['step_key']}: {row['state']} · {row['tool_name']}" for row in data["steps"])
        return ToolResult(True, "\n".join(lines), data)

    async def execute_approved_workflow(self, workflow_id: str, *, approved_tools: set[str]) -> dict[str, Any]:
        """Execute only after the trusted Telegram/owner layer confirms approval."""
        if not isinstance(approved_tools, set) or not approved_tools:
            raise PermissionError("an explicit approved tool set is required")
        registered = set(self._tools)
        if not approved_tools <= registered:
            raise PermissionError("approval includes an unregistered tool")

        async def dispatch(name: str, arguments: dict[str, Any], idempotency_key: str) -> Any:
            if name not in approved_tools:
                raise PermissionError(f"tool {name} was not approved")
            spec = self._tools[name]
            decision = self.guard.assess(name, owner_confirmed=True, explicitly_allowed=True)
            if not decision.allowed:
                raise PermissionError(decision.reason)
            # The workflow confirmation is the explicit owner approval for this
            # exact, displayed step. The registry still enforces tool registration.
            execution = await self.registry.execute(name, arguments, approved=True)
            if not execution.ok:
                raise RuntimeError(execution.error or "tool execution failed")
            result = execution.output
            if not isinstance(result, ToolResult):
                result = ToolResult(True, str(result))
            if not result.ok:
                raise RuntimeError(result.text)
            return {"text": result.text[:1000], "data": dict(result.data or {})}

        outcome: dict[str, Any] = {"workflow_id": workflow_id, "state": "running", "completed": [], "failed": [], "blocked": []}
        for _ in range(self.workflows.max_steps):
            current = await self.workflows.execute_ready(workflow_id, dispatch, approved_tools=approved_tools)
            for key in ("completed", "failed", "blocked"):
                outcome[key].extend(x for x in current.get(key, []) if x not in outcome[key])
            outcome["state"] = current.get("state", "unknown")
            if outcome["state"] != "running" or not current.get("completed"):
                break
        await self.events.publish("workflow.execution.finished", outcome)
        return outcome

    async def _project_status(self, args: dict[str, Any]) -> ToolResult:
        counts = await self.db.count_posts_by_status()
        sources = await self.db.list_source_channels()
        tasks = await self.db.fetchall("SELECT COUNT(*) AS n FROM agent_tasks WHERE state IN ('open','in_progress')")
        summary = (f"Poem Agent: Source channels {len(sources)} ခု; Posts {counts}; "
                   f"General tasks {tasks[0]['n'] if tasks else 0} ခု လုပ်ရန်ကျန်")
        return ToolResult(True, summary, {"posts": counts, "sources": len(sources)})

    @staticmethod
    def _required_text(args: dict[str, Any], key: str, limit: int) -> str:
        value = args.get(key)
        if not isinstance(value, str) or not value.strip() or len(value) > limit:
            raise ValueError(f"{key} is required and must be at most {limit} characters")
        return value.strip()

    async def _audit(self, tool_name: str, arguments: dict[str, Any], outcome: str) -> None:
        try:
            now = datetime.now(timezone.utc).isoformat(timespec="seconds")
            safe_args = json.dumps(arguments, ensure_ascii=False, default=str)[:2000]
            await self.db.execute("INSERT INTO agent_tool_audit(tool_name,arguments,outcome,created_at) VALUES(?,?,?,?)",
                                  (tool_name[:80], safe_args, outcome[:40], now))
        except Exception:
            log.exception("could not write agent tool audit")
