"""Agent controller (main file 03/10).

Connects every module:
  Telegram -> parse Burmese message (ai_brain) -> pick a registered tool ->
  run it (poetry / images / channel manager) -> reply to the owner.

Safeguards:
* tools are looked up in a fixed registry (no free-form execution),
* destructive tools need an explicit "ဟုတ်" confirmation,
* publishing always goes through ChannelManager.publish (owner approval required),
* every tool run is logged in task_logs; failures go to error_logs.
"""
from __future__ import annotations

import asyncio
import logging
import random
import re
import traceback
from datetime import timedelta
from pathlib import Path
from typing import Any, Awaitable, Callable

from config.constants import CATEGORIES, DESTRUCTIVE_INTENTS, EMOTIONS, PLAN_LABELS
from config.settings import Settings
from core.ai_brain import UNKNOWN_MESSAGE, AIBrain
from core.errors import ApprovalRequired, PublishError, SourceUnavailable
from core.general_agent import GeneralAgent
from core.models import Intent, PostBundle
from core.time_utils import from_db, resolve_when, to_db, to_local, utcnow
from channel.channel_manager import ChannelManager
from media.image_engine import ImageEngine
from memory.memory_manager import MemoryManager
from poetry.poetry_engine import PoetryEngine
from storage.database import Database
from telegram.telegram_interface import parse_callback

log = logging.getLogger(__name__)
Tool = Callable[[dict[str, Any], str], Awaitable[str]]

HELP_TEXT = (
    "ကျွန်တော်က ကဗျာ channel ကို စီမံပေးတဲ့ agent ပါ။ ပြောလို့ရတာတွေ -\n\n"
    "• တင်လိုက် (စီစဉ်ထားတဲ့အချိန်မှာ တင်မယ်) / ချက်ချင်းတင်လိုက် (အခုတင်မယ်)\n"
    "• ဒီတစ်ပုဒ်မကြိုက်ဘူး / နောက်တစ်ပုဒ်ပြ\n"
    "• ပုံပြောင်းပေး / ဒီလိုပုံမျိုး မသုံးနဲ့\n"
    "• မနက်ဖြန်အတွက် သိမ်းထားလိုက် / ဒီနေ့ မတင်တော့နဲ့\n"
    "• ကဗျာ ၃ ပုဒ် ပြင်ပေး\n"
    "• အလွမ်းကဗျာတွေ များနေပြီ\n"
    "• t.me/channelname ထည့်ပေး (source ထည့်ရန်)\n"
    "• အခြေအနေ / စာရင်း (report)\n\n"
    "Approve မလုပ်ခင် channel ပေါ်မှာ ဘာမှ မတင်ပါဘူး။"
)
POST_STATUS_MY = {"pending_approval": "အတည်ပြုစောင့်", "approved": "အတည်ပြုပြီး", "scheduled": "အချိန်ချိန်းပြီး",
                  "published": "တင်ပြီး", "failed": "မအောင်မြင်", "rejected": "ပယ်ထား", "cancelled": "ဖျက်ထား",
                  "publishing": "တင်နေ", "draft": "မူကြမ်း"}


def normalize_source(link: str) -> tuple[str, str]:
    """-> (canonical link, username). Only public channels are supported."""
    m = re.search(r"(?:t\.me/|^@)([A-Za-z]\w{3,})", link.strip())
    if not m or "joinchat" in link or "/+" in link:
        raise SourceUnavailable("public channel link သာ ထည့်လို့ရပါတယ် (ဥပမာ t.me/channelname)")
    return f"https://t.me/{m.group(1)}", m.group(1)


class Agent:
    def __init__(self, settings: Settings, db: Database, brain: AIBrain, memory: MemoryManager,
                 poetry: PoetryEngine, images: ImageEngine, channels: ChannelManager, tg: Any,
                 rng: random.Random | None = None) -> None:
        self.settings, self.db, self.brain, self.memory = settings, db, brain, memory
        self.poetry, self.images, self.channels, self.tg = poetry, images, channels, tg
        self.general = GeneralAgent(
            db, brain, memory,
            max_calls=settings.general_agent_max_calls,
            timeout_seconds=settings.general_agent_timeout_seconds,
            context_chars=settings.general_agent_context_chars,
            max_plan_steps=settings.general_agent_max_plan_steps,
            workflow_max_steps=settings.workflow_max_steps,
            workflow_max_attempts=settings.workflow_max_attempts,
            runtime_max_wall_seconds=settings.runtime_max_wall_seconds,
            runtime_max_tool_calls=settings.runtime_max_tool_calls,
            memory_retention_days=settings.memory_retention_days,
            knowledge_chunk_chars=settings.knowledge_chunk_chars,
            tool_timeout_seconds=settings.tool_timeout_seconds,
            allow_internal_writes=settings.general_agent_allow_internal_writes,
        )
        self._rng = rng or random.Random()
        self._awaiting: dict[str, Any] | None = None
        self._prepare_lock = asyncio.Lock()
        self._scan_now = asyncio.Event()
        self._tasks: list[asyncio.Task] = []
        self.tools: dict[str, Tool] = {
            "approve": self._t_approve, "reject": self._t_reject, "next_poem": self._t_next,
            "change_image": self._t_change_image, "avoid_image_style": self._t_avoid_image,
            "schedule": self._t_schedule, "skip_today": self._t_skip_today, "prepare_posts": self._t_prepare,
            "too_many": self._t_too_many, "add_source": self._t_add_source, "remove_source": self._t_remove_source,
            "list_sources": self._t_list_sources, "status": self._t_status, "report": self._t_report,
            "pause_auto": self._t_pause, "resume_auto": self._t_resume, "set_plan": self._t_set_plan,
            "help": self._t_help,
        }

    # ==================================================================
    # lifecycle
    # ==================================================================
    async def startup(self) -> None:
        await self.memory.load()
        await self.general.initialize()
        self.tg.set_handlers(self.on_owner_text, self.on_callback)
        await self.channels.ensure_plans()

    def start_background(self, stop: asyncio.Event) -> None:
        cfg = self.settings
        specs = [("scan", self.scan_once, cfg.scan_interval_minutes * 60, True),
                 ("schedule", self.schedule_tick, 60, False),
                 ("stats", self.stats_tick, cfg.stats_interval_hours * 3600, False),
                 ("maintenance", self.maintenance_tick, 24 * 3600, False)]
        for name, fn, interval, wakeable in specs:
            self._tasks.append(asyncio.create_task(self._loop(name, fn, interval, stop, wakeable), name=f"loop-{name}"))

    async def shutdown(self) -> None:
        for t in self._tasks:
            t.cancel()
        await asyncio.gather(*self._tasks, return_exceptions=True)
        self._tasks.clear()

    async def _loop(self, name: str, fn: Callable[[], Awaitable[Any]], interval: float, stop: asyncio.Event,
                    wakeable: bool) -> None:
        """Run `fn` forever; an error never kills the loop."""
        first = True
        while not stop.is_set():
            if not first:
                try:
                    if wakeable:
                        await asyncio.wait_for(self._scan_now.wait(), timeout=interval)
                        self._scan_now.clear()
                    else:
                        await asyncio.wait_for(stop.wait(), timeout=interval)
                        return
                except asyncio.TimeoutError:
                    pass
            first = False
            if stop.is_set():
                return
            try:
                await fn()
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                log.exception("loop %s failed", name)
                await self.db.log_error(f"agent.{name}", str(exc), traceback.format_exc())

    # ==================================================================
    # owner input
    # ==================================================================
    async def on_owner_text(self, text: str) -> None:
        await self.memory.add_turn("owner", text)
        try:
            if (self._awaiting is None and self.general.has_pending_confirmation
                    and self.general.is_confirmation_reply(text)):
                reply = await self.general.handle(text)
                if reply:
                    await self.tg.send_owner(reply)
                    await self.memory.add_turn("agent", reply)
                return
            intent = await self.brain.parse_owner_message(
                text, awaiting_confirm=self._awaiting is not None, context=await self.memory.build_context())
            if (intent.name == "unknown" and self._awaiting is None
                    and self.settings.general_agent_enabled and hasattr(self.brain, "complete")):
                if intent.clarification and intent.clarification != UNKNOWN_MESSAGE:
                    reply = intent.clarification          # the parser asked a poetry question: keep it
                else:
                    reply = await self.general.handle(text)
            else:
                reply = await self.execute_intent(intent, text)
        except Exception as exc:  # noqa: BLE001
            log.exception("owner message failed")
            await self.db.log_error("agent", f"owner message failed: {exc}", traceback.format_exc())
            reply = "တစ်ခုခု မှားသွားပါတယ်၊ ပြန်ကြိုးစားပေးပါဦး။ (error log ထဲ မှတ်ထားပါတယ်)"
        if reply:
            await self.tg.send_owner(reply)
            await self.memory.add_turn("agent", reply)

    async def on_callback(self, data: str) -> None:
        parsed = parse_callback(data)
        if parsed is None:
            return
        action, post_id = parsed
        self.memory.set_task_context("pending_post_id", post_id)
        intent_name = {"ap": "approve", "rj": "reject", "im": "change_image", "nx": "next_poem", "sc": "schedule"}[action]
        params = {"day_offset": 1} if action == "sc" else {}
        try:
            reply = await self.execute_intent(Intent(intent_name, params, 1.0, source="button"), f"[button:{data}]")
        except Exception as exc:  # noqa: BLE001
            await self.db.log_error("agent", f"callback failed: {exc}", traceback.format_exc())
            reply = "တစ်ခုခု မှားသွားပါတယ်၊ ပြန်ကြိုးစားပေးပါဦး။"
        if reply:
            await self.tg.send_owner(reply)

    async def execute_intent(self, intent: Intent, original_text: str) -> str:
        if intent.name == "confirm":
            pending, self._awaiting = self._awaiting, None
            if not pending:
                return "အတည်ပြုစရာ မရှိပါဘူး။"
            return await self._run_tool(pending["intent"], pending["params"], original_text)
        if intent.name == "cancel_confirm":
            self._awaiting = None
            return "ကောင်းပါပြီ၊ မလုပ်တော့ပါဘူး။"
        if intent.name == "unknown" or intent.name not in self.tools:
            return intent.clarification or UNKNOWN_MESSAGE
        if intent.name in DESTRUCTIVE_INTENTS:
            self._awaiting = {"intent": intent.name, "params": intent.params}
            target = intent.params.get("link", "")
            return f"{target} ကို တကယ်လုပ်မှာလား? 'ဟုတ်' လို့ ပြန်ပြောရင် လုပ်ပါမယ်၊ မလုပ်ချင်ရင် 'မလုပ်နဲ့' လို့ ပြောပါ။"
        self._awaiting = None
        return await self._run_tool(intent.name, intent.params, original_text)

    async def _run_tool(self, name: str, params: dict[str, Any], text: str) -> str:
        tool = self.tools[name]
        task_id = await self.db.start_task(f"tool:{name}", {"params": params})
        try:
            reply = await tool(params, text)
        except Exception as exc:
            await self.db.finish_task(task_id, "failed", {"error": str(exc)})
            await self.db.log_error(f"tool.{name}", str(exc), traceback.format_exc(), task_id=task_id)
            raise
        await self.db.finish_task(task_id, "done", {"reply": reply[:200]})
        if name in ("reject", "next_poem", "change_image", "too_many", "avoid_image_style", "schedule", "skip_today"):
            await self.memory.add_feedback(text, name, params, post_id=self.memory.get_task_context("pending_post_id"))
        return reply

    # ==================================================================
    # helpers
    # ==================================================================
    def fmt_local(self, db_time: str | None) -> str:
        if not db_time:
            return "ချက်ချင်း"
        return to_local(from_db(db_time), self.settings.timezone_offset_minutes).strftime("%Y-%m-%d %H:%M")

    @staticmethod
    def _labels(keys: list[str], table: dict[str, str]) -> str:
        return ", ".join(table.get(k, k) for k in keys) or "-"

    async def _current_post_id(self) -> int | None:
        """The post the owner is looking at: last preview, else newest waiting post."""
        pid = self.memory.get_task_context("pending_post_id")
        if pid:
            post = await self.db.get_post(pid)
            if post and post["status"] == "pending_approval":
                return pid
        waiting = await self.db.list_posts(["pending_approval"], limit=50)
        return waiting[-1]["id"] if waiting else None

    async def _send_preview(self, bundle: PostBundle) -> None:
        meta = bundle.meta
        header = f"📝 ပို့စ် #{bundle.post_id}" + (f" · ⏰ {self.fmt_local(bundle.scheduled_at)}" if bundle.scheduled_at else "")
        emo = [e["name"] for e in meta.get("emotions", [])[:3]]
        footer = (f"🏷 {self._labels(meta.get('categories', []), CATEGORIES)} · 🎭 {self._labels(emo, EMOTIONS)}"
                  f" · ⭐ {meta.get('quality', '-')}" + ("" if bundle.image_path else " · 🖼 ပုံမပါ"))
        await self.tg.send_preview(bundle, header, footer)
        self.memory.set_task_context("pending_post_id", bundle.post_id)

    async def _prepare_and_preview(self, *, scheduled_at: str | None = None, category: str | None = None) -> PostBundle | None:
        async with self._prepare_lock:
            bundle = await self.channels.prepare_post(scheduled_at=scheduled_at, category=category)
        if bundle:
            await self._send_preview(bundle)
        return bundle

    async def _notify_once(self, key: str, hours: float, text: str) -> None:
        last = await self.db.get_config(f"notice:{key}")
        if last and from_db(last) > utcnow() - timedelta(hours=hours):
            return
        await self.db.set_config(f"notice:{key}", to_db(utcnow()))
        await self.tg.send_owner(text)

    async def _publish_now(self, post_id: int) -> str:
        try:
            message_id = await self.channels.publish(post_id, self.tg.publish)
        except ApprovalRequired:
            return "အတည်ပြုချက် မရသေးလို့ မတင်ပါဘူး။"
        except PublishError as exc:
            await self.tg.mark_preview(post_id, "⚠️ မတင်နိုင်ပါ")
            return f"⚠️ Channel ပေါ် မတင်နိုင်ပါဘူး ({exc})။ ပြန်ကြိုးစားချင်ရင် 'တင်လိုက်' လို့ ပြောပါ။"
        await self.tg.mark_preview(post_id, "✅ တင်ပြီးပါပြီ")
        return f"✅ Channel ပေါ် တင်ပြီးပါပြီ (message {message_id})။"

    # ==================================================================
    # tools (one per owner intent)
    # ==================================================================
    async def _t_approve(self, params: dict, text: str) -> str:
        pid = await self._current_post_id()
        if pid is None:
            return "တင်ဖို့ စောင့်နေတဲ့ ပို့စ် မရှိသေးပါဘူး။"
        result = await self.channels.approve(pid, text, now=bool(params.get("now")))
        if result == "publish_now":
            return await self._publish_now(pid)
        if result == "scheduled":
            post = await self.db.get_post(pid)
            await self.tg.mark_preview(pid, "⏰ အချိန်ချိန်းပြီး")
            return f"⏰ {self.fmt_local(post['scheduled_at'])} မှာ တင်ပေးပါမယ်။"
        return "ဒီပို့စ်ကို အတည်ပြုပြီးသားပါ။" if result == "already" else "ဒီပို့စ်ကို ရှာမတွေ့ပါဘူး။"

    async def _replace(self, dislike: bool, text: str) -> str:
        pid = await self._current_post_id()
        if pid is None:
            return "လက်ရှိ ပြထားတဲ့ ပို့စ် မရှိပါဘူး။ 'ကဗျာ ၁ ပုဒ် ပြင်ပေး' လို့ ပြောပါ။"
        await self.tg.mark_preview(pid, "❌ ဖယ်လိုက်ပါပြီ" if dislike else "⏭ ကျော်လိုက်ပါပြီ")
        async with self._prepare_lock:
            bundle = await self.channels.replace_post(pid, dislike=dislike, owner_message=text)
        if bundle is None:
            return "ကဗျာ ကျန်တာ မရှိတော့ပါဘူး။ Source channel တွေ ထပ်ထည့်ပါ၊ ဒါမှမဟုတ် စုဆောင်းတာ စောင့်ပေးပါ။"
        await self._send_preview(bundle)
        return "ကောင်းပါပြီ၊ နောက်တစ်ပုဒ် ပြင်ပေးထားပါတယ်။"

    async def _t_reject(self, params: dict, text: str) -> str:
        return await self._replace(True, text)

    async def _t_next(self, params: dict, text: str) -> str:
        return await self._replace(False, text)

    async def _t_change_image(self, params: dict, text: str, avoid_style: str | None = None) -> str:
        pid = await self._current_post_id()
        if pid is None:
            return "ပုံပြောင်းဖို့ ပို့စ် မရှိသေးပါဘူး။"
        bundle = await self.channels.change_image(pid, avoid_style=avoid_style)
        if bundle is None:
            return "တခြားသင့်တော်တဲ့ပုံ မတွေ့သေးပါဘူး (ဒီနေ့ ပုံရှာတဲ့ အကန့်အသတ် ပြည့်သွားနိုင်ပါတယ်)။"
        await self.tg.mark_preview(pid, "🖼 ပုံပြောင်းလိုက်ပါပြီ")
        post = await self.db.get_post(pid)
        poem = await self.db.get_analysis(post["poem_id"]) or {}
        bundle.meta.update({"emotions": poem.get("emotions", []), "categories": poem.get("categories", []),
                            "quality": poem.get("quality_score", "-")})
        await self._send_preview(bundle)
        return "ပုံအသစ် ပြောင်းပေးထားပါတယ်။"

    async def _t_avoid_image(self, params: dict, text: str) -> str:
        style = str(params.get("style") or "").strip()
        pid = await self._current_post_id()
        if (not style or style == "current") and pid:
            post = await self.db.get_post(pid)
            image = await self.db.get_image(post["image_id"]) if post and post["image_id"] else None
            style = (image or {}).get("search_query", "")
        if not style:
            return "ဘယ်လိုပုံမျိုးလဲ နည်းနည်းပြောပြပေးပါဦး။"
        await self.memory.avoid("image_style", style.lower(), days=None)
        note = await self._t_change_image({}, text, avoid_style=style) if pid else ""
        return f"'{style}' လိုပုံမျိုး နောက်ထပ် မသုံးတော့ပါဘူး။ {note}".strip()

    async def _t_schedule(self, params: dict, text: str) -> str:
        pid = await self._current_post_id()
        if pid is None:
            return "အချိန်ချိန်းဖို့ ပို့စ် မရှိသေးပါဘူး။"
        when = resolve_when(params, utcnow(), self.settings.timezone_offset_minutes, self.settings.post_time_list)
        if when is None:
            return "ဘယ်အချိန်လဲ နားမလည်ပါဘူး၊ ဥပမာ 'မနက်ဖြန် ည ၇ နာရီ' လို့ ပြောပေးပါ။"
        await self.channels.reschedule(pid, when)
        result = await self.channels.approve(pid, text)
        if result == "publish_now":
            return await self._publish_now(pid)
        await self.tg.mark_preview(pid, "⏰ အချိန်ချိန်းပြီး")
        return f"⏰ {self.fmt_local(to_db(when))} မှာ တင်ပေးပါမယ်။"

    async def _t_skip_today(self, params: dict, text: str) -> str:
        count = await self.channels.skip_today()
        return f"ကောင်းပါပြီ၊ ဒီနေ့ ဘာမှမတင်တော့ပါဘူး။ (ဖျက်လိုက်တဲ့ ပို့စ် {count} ခု)"

    async def _t_prepare(self, params: dict, text: str) -> str:
        count = max(1, min(int(params.get("count", 1)), self.settings.max_batch))
        category = params.get("category") or None
        if category and category not in PLAN_LABELS:
            category = None
        await self.tg.send_owner(f"ကဗျာ {count} ပုဒ် ပြင်ဆင်နေပါတယ်၊ ခဏစောင့်ပါ...")
        slots = await self.channels.free_slots(count)
        made = 0
        for i in range(count):
            when = to_db(slots[i]) if i < len(slots) else None
            if await self._prepare_and_preview(scheduled_at=when, category=category) is None:
                break
            made += 1
        if made == 0:
            return "တင်လို့ရမယ့် ကဗျာ မရှိသေးပါဘူး။ Source channel တွေကနေ စုဆောင်းပြီးမှ ပြန်ပြောပါ။"
        return f"ပို့စ် {made} ခု ပြင်ဆင်ပြီးပါပြီ၊ တစ်ခုချင်း ကြည့်ပြီး အတည်ပြုပေးပါ။" + ("" if made == count else f" (ကဗျာ ကျန်တာ မရှိလို့ {count - made} ခု လျှော့လိုက်ပါတယ်)")

    async def _t_too_many(self, params: dict, text: str) -> str:
        kind, key = params.get("kind"), params.get("key")
        if kind not in ("emotion", "category") or not key:
            return "ဘယ်လို ကဗျာမျိုး များနေတာလဲ ပြောပြပေးပါဦး။"
        await self.memory.avoid(kind, key)
        label = (EMOTIONS if kind == "emotion" else CATEGORIES).get(key, key)
        extra = ""
        pid = await self._current_post_id()
        if pid:
            analysis = await self.db.get_analysis((await self.db.get_post(pid))["poem_id"])
            top = analysis["emotions"][0]["name"] if analysis and analysis["emotions"] else None
            if analysis and ((kind == "emotion" and top == key) or (kind == "category" and key in analysis["categories"])):
                extra = " " + await self._replace(False, text)
        return f"{label} ကဗျာတွေကို ရက်အနည်းငယ် လျှော့လိုက်ပါမယ်။{extra}"

    async def _t_add_source(self, params: dict, text: str) -> str:
        try:
            link, username = normalize_source(str(params.get("link", "")))
        except SourceUnavailable as exc:
            return str(exc)
        await self.db.add_source_channel(link, username, username)
        self._scan_now.set()
        return f"Source channel {link} ကို ထည့်လိုက်ပါပြီ၊ မကြာခင် စုဆောင်းပါမယ်။"

    async def _t_remove_source(self, params: dict, text: str) -> str:
        try:
            link, _ = normalize_source(str(params.get("link", "")))
        except SourceUnavailable as exc:
            return str(exc)
        ok = await self.db.deactivate_source_channel(link)
        return f"{link} ကို ဖယ်လိုက်ပါပြီ (စုဆောင်းထားတဲ့ ကဗျာတွေ ဆက်ရှိပါတယ်)။" if ok else f"{link} ကို စာရင်းထဲ မတွေ့ပါဘူး။"

    async def _t_list_sources(self, params: dict, text: str) -> str:
        rows = await self.db.list_source_channels()
        if not rows:
            return "Source channel မရှိသေးပါဘူး။ 't.me/channelname ထည့်ပေး' လို့ ပြောပါ။"
        return "Source channel များ:\n" + "\n".join(
            f"• {r['link']} (နောက်ဆုံး scan: {self.fmt_local(r['last_scan_at']) if r['last_scan_at'] else 'မရှိသေး'})" for r in rows)

    async def _t_status(self, params: dict, text: str) -> str:
        s = await self.channels.status_summary()
        posts = ", ".join(f"{POST_STATUS_MY.get(k, k)} {v}" for k, v in s["posts"].items()) or "မရှိသေး"
        poems = s["poems"]
        return (f"📊 အခြေအနေ\nကဗျာ: အသစ် {poems.get('new', 0)} · ရွေးချယ်နိုင် {poems.get('analyzed', 0)} · "
                f"တင်ပြီး {poems.get('posted', 0)} · ထပ်နေ {poems.get('duplicate', 0)}\n"
                f"ပို့စ်: {posts}\nSource: {s['sources']} ခု · ဒီနေ့ပုံရှာမှု {s['images_today']}/{self.settings.image_daily_limit}\n"
                f"Auto ပြင်ဆင်ခြင်း: {'ဖွင့်' if s['auto'] else 'ပိတ်'}" + (f"\nဒီနေ့ ({s['skip_date']}) မတင်ရန် သတ်မှတ်ထား" if s["skip_date"] == self.channels.local_date_str() else ""))

    async def _t_report(self, params: dict, text: str) -> str:
        r = await self.channels.performance_report()
        if not r["posts"]:
            return "စာရင်းထုတ်ဖို့ တင်ပြီးသား ပို့စ် မရှိသေးပါဘူး။"
        lines = [f"📈 လွန်ခဲ့တဲ့ {r['days']} ရက် - ပို့စ် {r['posts']} ခု"]
        for cat, v in sorted(r["categories"].items(), key=lambda kv: -kv[1]["avg_views"])[:5]:
            lines.append(f"• {CATEGORIES.get(cat, cat)}: {v['posts']} ခု · views {v['avg_views']} · reactions {v['avg_reactions']}")
        if r["best_post"]:
            lines.append(f"🏆 အကောင်းဆုံး: ပို့စ် #{r['best_post']['post_id']} ({r['best_post']['views']} views)")
        return "\n".join(lines)

    async def _t_pause(self, params: dict, text: str) -> str:
        await self.db.set_config("auto_prepare", "0")
        return "ပို့စ် အလိုအလျောက် ပြင်ဆင်တာ ခဏရပ်လိုက်ပါပြီ။ 'ပြန်စ' လို့ ပြောရင် ပြန်စပါမယ်။"

    async def _t_resume(self, params: dict, text: str) -> str:
        await self.db.set_config("auto_prepare", "1")
        return "အလိုအလျောက် ပြင်ဆင်တာ ပြန်စလိုက်ပါပြီ။"

    async def _t_set_plan(self, params: dict, text: str) -> str:
        category = str(params.get("category", ""))
        if category not in PLAN_LABELS:
            return "ဘယ်အမျိုးအစားလဲ နားမလည်ပါဘူး။"
        day = (to_local(utcnow(), self.settings.timezone_offset_minutes) + timedelta(days=int(params.get("day_offset", 0)))).date().isoformat()
        await self.channels.set_plan(day, category, max(1, int(params.get("count", 1))))
        return f"{day} အတွက် {PLAN_LABELS[category]} ကို စီစဉ်လိုက်ပါပြီ။"

    async def _t_help(self, params: dict, text: str) -> str:
        return HELP_TEXT

    # ==================================================================
    # background jobs
    # ==================================================================
    async def scan_once(self) -> dict[str, int]:
        """Read every active source channel (slowly, to protect the spare account)."""
        totals: dict[str, int] = {}
        sources = await self.db.list_source_channels()
        for i, channel in enumerate(sources):
            try:
                counts = await self.poetry.scan_channel(channel, self.tg.fetch_new_messages)
            except SourceUnavailable as exc:
                await self.db.log_error("agent.scan", str(exc), level="warning")
                await self._notify_once(f"source:{channel['id']}", 24, f"⚠️ {channel['link']} ကို ဖတ်လို့မရပါဘူး: {exc}")
                continue
            for k, v in counts.items():
                totals[k] = totals.get(k, 0) + v
            if i < len(sources) - 1:
                await asyncio.sleep(self._rng.uniform(self.settings.scan_delay_min, self.settings.scan_delay_max))
        await self.poetry.process_pending()
        if totals:
            log.info("scan finished: %s", totals)
        return totals

    async def schedule_tick(self) -> None:
        """Every minute: recover, publish due posts, keep plans and the approval queue filled."""
        for post_id in await self.channels.recover_stuck():
            await self.tg.send_owner(f"⚠️ ပို့စ် #{post_id} တင်နေရင်း ရပ်သွားပါတယ်။ Channel ထဲမှာ ရှိမရှိ စစ်ပြီး လိုရင် ပြန်ပြင်ဆင်ပါ။")
        for post_id in await self.channels.due_post_ids():
            try:
                reply = await self._publish_now(post_id)
            except Exception as exc:  # noqa: BLE001
                await self.db.log_error("agent.publish", str(exc), traceback.format_exc())
                continue
            await self.tg.send_owner(f"ပို့စ် #{post_id}: {reply}")
        await self.channels.ensure_plans()
        await self._remind_overdue()
        if (await self.db.get_config("auto_prepare", "1")) == "1":
            await self._fill_queue()

    async def _remind_overdue(self) -> None:
        now = to_db(utcnow())
        for post in await self.db.list_posts(["pending_approval"]):
            if post["scheduled_at"] and post["scheduled_at"] <= now:
                await self._notify_once(f"overdue:{post['id']}", 24 * 365,
                                        f"⏰ ပို့စ် #{post['id']} ရဲ့ အချိန်ရောက်နေပါပြီ၊ အတည်ပြုချက် မရသေးလို့ မတင်ရသေးပါဘူး။ 'တင်လိုက်' ဒါမှမဟုတ် 'နောက်တစ်ပုဒ်ပြ' လို့ ပြောပါ။")

    async def _fill_queue(self) -> None:
        now = to_db(utcnow())
        open_posts = [p for p in await self.db.list_posts(["pending_approval", "approved", "scheduled"])
                      if not p["scheduled_at"] or p["scheduled_at"] > now]
        if len(open_posts) >= self.settings.queue_target:
            return
        slots = await self.channels.free_slots(1)
        if not slots:
            return
        if await self._prepare_and_preview(scheduled_at=to_db(slots[0])) is None:
            await self._notify_once("no_poems", 6, "တင်လို့ရမယ့် ကဗျာ မကျန်တော့ပါဘူး။ Source channel ထပ်ထည့်ပေးပါ။")

    async def stats_tick(self) -> None:
        saved = await self.channels.collect_stats(self.tg.fetch_stats)
        if saved:
            log.info("stored stats for %s posts", saved)

    async def maintenance_tick(self) -> None:
        stamp = to_local(utcnow(), self.settings.timezone_offset_minutes).strftime("%Y%m%d")
        await self.db.backup(Path(self.settings.backup_dir) / f"poem_agent_{stamp}.db")
        for old in sorted(Path(self.settings.backup_dir).glob("poem_agent_*.db"))[:-7]:
            old.unlink(missing_ok=True)
        await self.memory.purge()
