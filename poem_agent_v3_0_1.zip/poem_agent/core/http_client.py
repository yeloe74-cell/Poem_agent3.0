"""Tiny async HTTP client built on urllib (no third-party dependency).

The network call is a plain function ("transport") so tests can replace it.
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Awaitable, Callable, Mapping

from core.errors import HTTPError

log = logging.getLogger(__name__)

MAX_BODY = 20 * 1024 * 1024
Transport = Callable[[str, str, dict, "bytes | None", float], "tuple[int, dict, bytes]"]


def urllib_transport(method: str, url: str, headers: dict, body: bytes | None, timeout: float) -> tuple[int, dict, bytes]:
    req = urllib.request.Request(url, data=body, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310 (url scheme checked by caller)
            data = resp.read(MAX_BODY + 1)
            if len(data) > MAX_BODY:
                raise HTTPError(0, "response too large")
            return resp.status, dict(resp.headers), data
    except urllib.error.HTTPError as exc:
        return exc.code, dict(exc.headers or {}), exc.read() or b""


class HttpClient:
    def __init__(self, timeout: float = 30.0, retries: int = 2, backoff: float = 1.0,
                 user_agent: str = "PoemAgent/1.0 (poetry channel assistant)",
                 transport: Transport | None = None,
                 sleep: Callable[[float], Awaitable[None]] | None = None) -> None:
        self.timeout = timeout
        self.retries = retries
        self.backoff = backoff
        self.user_agent = user_agent
        self._transport: Transport = transport or urllib_transport
        self._sleep = sleep or asyncio.sleep

    async def request(self, method: str, url: str, *, headers: Mapping[str, str] | None = None,
                      params: Mapping[str, Any] | None = None, json_body: Any = None) -> tuple[int, dict, bytes]:
        if urllib.parse.urlparse(url).scheme not in ("http", "https"):
            raise HTTPError(0, f"unsupported URL scheme: {url[:40]}")
        if params:
            url += ("&" if "?" in url else "?") + urllib.parse.urlencode(params)
        hdrs = {"User-Agent": self.user_agent, **(headers or {})}
        body = None
        if json_body is not None:
            body = json.dumps(json_body).encode("utf-8")
            hdrs.setdefault("Content-Type", "application/json")
        last: HTTPError | None = None
        for attempt in range(self.retries + 1):
            try:
                status, rheaders, data = await asyncio.to_thread(
                    self._transport, method, url, hdrs, body, self.timeout)
            except HTTPError as exc:
                last = exc
            except (urllib.error.URLError, OSError, TimeoutError) as exc:
                last = HTTPError(0, str(exc))
            else:
                if status < 400:
                    return status, rheaders, data
                last = HTTPError(status, data[:300].decode("utf-8", "replace"))
                if status not in (429, 500, 502, 503, 504):
                    raise last
            if attempt < self.retries:
                delay = self.backoff * (2 ** attempt)
                log.warning("HTTP retry %s/%s for %s in %.1fs (%s)", attempt + 1, self.retries, url[:80], delay, last)
                await self._sleep(delay)
        assert last is not None
        raise last

    async def json(self, method: str, url: str, **kwargs: Any) -> Any:
        _, _, data = await self.request(method, url, **kwargs)
        try:
            return json.loads(data.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise HTTPError(200, f"invalid JSON: {exc}") from exc

    async def get_json(self, url: str, **kwargs: Any) -> Any:
        return await self.json("GET", url, **kwargs)

    async def post_json(self, url: str, **kwargs: Any) -> Any:
        return await self.json("POST", url, **kwargs)

    async def download_image(self, url: str, dest_dir: Path, stem: str) -> tuple[Path, str]:
        """Download an image; returns (path, sha256). Raises HTTPError if not an image."""
        _, headers, data = await self.request("GET", url)
        ctype = next((v for k, v in headers.items() if k.lower() == "content-type"), "").split(";")[0].strip().lower()
        ext = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"}.get(ctype)
        if ext is None:
            raise HTTPError(200, f"not a supported image type: {ctype or 'unknown'}")
        dest_dir.mkdir(parents=True, exist_ok=True)
        path = dest_dir / f"{stem}{ext}"
        path.write_bytes(data)
        return path, hashlib.sha256(data).hexdigest()

    async def head_ok(self, url: str) -> bool:
        try:
            await self.request("HEAD", url)
            return True
        except HTTPError:
            return False
