"""Outcome evaluation and bounded reflection records for completed agent work."""
from __future__ import annotations

import json
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Mapping, Sequence

@dataclass(frozen=True)
class Evaluation:
    status: str
    score: float
    reasons: tuple[str, ...]
    retryable: bool

class OutcomeEvaluator:
    """Evaluate execution evidence; never infer success from an assistant claim."""
    SUCCESS = {"done", "completed", "published", "ok", "success"}
    FAILURE = {"failed", "error", "rejected", "cancelled", "timeout"}

    def evaluate(self, *, expected: Sequence[str], observed: Mapping[str, Any],
                 error: str | None = None) -> Evaluation:
        reasons: list[str] = []
        if error:
            return Evaluation("failed", 0.0, (self._safe(error),), True)
        state = str(observed.get("status", "unknown")).lower()
        if state in self.FAILURE:
            return Evaluation("failed", 0.0, (f"observed status: {state}",), state in {"failed", "error", "timeout"})
        missing = [key for key in expected if key not in observed or observed[key] in (None, "", False)]
        if missing:
            reasons.append("missing evidence: " + ", ".join(missing[:8]))
        if state not in self.SUCCESS:
            reasons.append("completion status is not confirmed")
        score = max(0.0, 1.0 - (len(missing) * 0.2) - (0.3 if state not in self.SUCCESS else 0))
        status = "verified" if score >= 0.99 and state in self.SUCCESS else "needs_review"
        if not reasons:
            reasons.append("all requested evidence fields are present")
        return Evaluation(status, round(score, 3), tuple(reasons), False)

    @staticmethod
    def _safe(value: str) -> str:
        text = re.sub(r"(?i)(api[_ -]?key|password|secret)\s*[:=]\s*\S+", r"\1=[redacted]", str(value))
        return text[:500]

    @staticmethod
    def reflection_payload(goal: str, evaluation: Evaluation, evidence: Mapping[str, Any]) -> dict[str, Any]:
        safe = {str(k)[:80]: str(v)[:300] for k, v in list(evidence.items())[:20]}
        return {"goal": goal[:500], "status": evaluation.status, "score": evaluation.score,
                "reasons": list(evaluation.reasons), "evidence": safe,
                "created_at": datetime.now(timezone.utc).isoformat()}
