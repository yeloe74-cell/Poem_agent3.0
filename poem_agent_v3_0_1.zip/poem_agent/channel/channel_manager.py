"""Channel manager (main file 08/10).

Owns the life of a post: plan -> prepare (poem + image + caption) -> owner
approval -> scheduling -> guarded publishing -> statistics.

Safety rules enforced here (and again by database triggers):
* nothing is published without an 'approved' approval record,
* a post is claimed atomically before sending, so it can never go out twice,
* a post stuck in 'publishing' is marked failed for the owner to check instead of
  being re-sent automatically (the message may already be on the channel).
"""
from __future__ import annotations

import asyncio
import logging
from collections import Counter
from datetime import datetime, timedelta
from typing import Any, Awaitable, Callable, Iterable

from config.constants import PLAN_LABELS, TELEGRAM_CAPTION_LIMIT
from config.settings import Settings
from core.errors import ApprovalRequired, PublishError
from core.models import CreditInfo, PostBundle
from core.time_utils import from_db, local_to_utc, to_db, to_local, utcnow
from media.image_engine import ImageEngine
from memory.memory_manager import MemoryManager
from poetry.poetry_engine import PoetryEngine
from storage.database import Database

log = logging.getLogger(__name__)
Sender = Callable[[PostBundle], Awaitable[int]]
StatsFetcher = Callable[[str, list[int]], Awaitable[dict[int, tuple[int, int, int]]]]
OPEN_STATUSES = ("pending_approval", "approved", "scheduled")


class ChannelManager:
    def __init__(self, db: Database, poetry: PoetryEngine, images: ImageEngine, memory: MemoryManager,
                 settings: Settings, sleep: Callable[[float], Awaitable[None]] | None = None) -> None:
        self.db = db
        self.poetry = poetry
        self.images = images
        self.memory = memory
        self.settings = settings
        self._sleep = sleep or asyncio.sleep

    # ------------------------------------------------------------------
    # time helpers
    # ------------------------------------------------------------------
    def local_date_str(self, when: datetime | None = None) -> str:
        return to_local(when or utcnow(), self.settings.timezone_offset_minutes).date().isoformat()

    # ------------------------------------------------------------------
    # planning
    # ------------------------------------------------------------------
    async def ensure_plans(self, days_ahead: int = 2) -> None:
        """Create the default weekly-plan rows for today and the next days."""
        now_local = to_local(utcnow(), self.settings.timezone_offset_minutes)
        per_day = max(1, len(self.settings.post_time_list))
        for offset in range(days_ahead + 1):
            day = (now_local + timedelta(days=offset)).date()
            if not await self.db.get_plans(day.isoformat()):
                category = self.settings.weekly_plan.get(day.weekday(), "any")
                await self.db.upsert_plan(day.isoformat(), category, per_day, "weekly template", "agent")

    async def set_plan(self, day: str, category: str, count: int) -> None:
        """Owner override for one day (replaces the agent's own rows)."""
        await self.db.clear_plans(day, "agent")
        await self.db.upsert_plan(day, category, count, "owner request", "owner")

    async def target_category_for(self, day: str) -> str:
        plans = await self.db.get_plans(day)
        if not plans:
            weekday = datetime.fromisoformat(day).weekday()
            return self.settings.weekly_plan.get(weekday, "any")
        expanded = [p["target_category"] for p in plans for _ in range(max(1, p["post_count"]))]
        start = to_db(local_to_utc(*map(int, day.split("-")), 0, 0, self.settings.timezone_offset_minutes))
        end = to_db(local_to_utc(*map(int, day.split("-")), 0, 0, self.settings.timezone_offset_minutes) + timedelta(days=1))
        used = len(await self.db.posts_in_range(start, end))
        return expanded[used % len(expanded)]

    async def free_slots(self, count: int, days: int = 3) -> list[datetime]:
        """Next posting times (UTC) that are in the future, not skipped and not already taken."""
        now = utcnow()
        skip = await self.db.get_config("skip_date")
        slots: list[datetime] = []
        today = to_local(now, self.settings.timezone_offset_minutes).date()
        for offset in range(days + 1):
            day = today + timedelta(days=offset)
            if skip == day.isoformat():
                continue
            for hour, minute in self.settings.post_time_list:
                slot = local_to_utc(day.year, day.month, day.day, hour, minute, self.settings.timezone_offset_minutes)
                if slot <= now + timedelta(minutes=5):
                    continue
                if await self.db.posts_near(to_db(slot), 30):
                    continue
                slots.append(slot)
                if len(slots) >= count:
                    return slots
        return slots

    # ------------------------------------------------------------------
    # preparing a post
    # ------------------------------------------------------------------
    def format_caption(self, body: str, credit: CreditInfo, image: dict[str, Any] | None,
                       source_link: str | None = None) -> str:
        """Poem verbatim + credit exactly as the source wrote it (+ image attribution if required)."""
        footer: list[str] = []
        if credit.status == "known" and credit.credit_text:
            footer.append(credit.credit_text if credit.credit_text.startswith("#") else f"✍️ {credit.credit_text}")
        attribution = self.images.caption_credit(image)
        if attribution:
            footer.append(attribution)
        if self.settings.show_source_link and source_link:
            footer.append(f"🔗 {source_link}")
        return body.strip() + ("\n\n" + "\n".join(footer) if footer else "")

    async def prepare_post(self, *, scheduled_at: str | None = None, category: str | None = None,
                           exclude_poem_ids: Iterable[int] = ()) -> PostBundle | None:
        """Pick a poem + image and create a post waiting for owner approval. None if no poem is available."""
        avoid = await self.memory.active_avoidances()
        if category is None:
            day = self.local_date_str(from_db(scheduled_at) if scheduled_at else None)
            category = await self.target_category_for(day)
        exclude = list(exclude_poem_ids)
        pick = await self.poetry.select_poem(target_category=category, exclude_ids=exclude, avoid=avoid)
        if pick is None and category not in (None, "any"):
            pick = await self.poetry.select_poem(target_category="any", exclude_ids=exclude, avoid=avoid)
        if pick is None:
            return None
        poem = pick.poem
        body, credit = self.poetry.body_and_credit(poem["raw_text"])
        credit.source_link = poem.get("original_link")
        image = await self.images.find_for_poem(poem["id"], body, poem["emotions"], (), avoid["image_style"])
        caption = self.format_caption(body, credit, image, poem.get("original_link"))
        post_id = await self.db.create_post(poem["id"], image["id"] if image else None, caption, scheduled_at)
        bundle = await self.bundle(post_id)
        if bundle is not None:
            bundle.meta.update({"category": category, "score": pick.score, "emotions": poem["emotions"],
                                "categories": poem["categories"], "quality": poem["quality_score"]})
        return bundle

    async def bundle(self, post_id: int) -> PostBundle | None:
        post = await self.db.get_post(post_id)
        if not post:
            return None
        path = None
        if post["image_id"]:
            local = self.images.local_file(post["image_id"])
            path = str(local) if local else None
        split = bool(path) and len(post["caption"]) > TELEGRAM_CAPTION_LIMIT
        return PostBundle(post_id, post["poem_id"], post["caption"], path, split, post["scheduled_at"])

    # ------------------------------------------------------------------
    # owner decisions
    # ------------------------------------------------------------------
    async def approve(self, post_id: int, owner_message: str = "", now: bool = False) -> str:
        """Returns 'publish_now', 'scheduled', 'already' or 'missing'.

        A post with a planned time is scheduled for that time; `now=True` (owner said
        "ချက်ချင်းတင်") publishes it immediately instead."""
        post = await self.db.get_post(post_id)
        if not post:
            return "missing"
        if post["status"] != "pending_approval":
            return "already" if post["status"] in ("approved", "scheduled", "publishing", "published") else "missing"
        await self.db.decide_approval(post_id, "approved", owner_message)
        when = post["scheduled_at"]
        if when and when > to_db(utcnow()) and not now:
            await self.db.update_post(post_id, status="scheduled")
            return "scheduled"
        await self.db.update_post(post_id, status="approved")
        return "publish_now"

    async def cancel_post(self, post_id: int, *, decision: str = "rejected", owner_message: str = "",
                          poem_action: str = "release") -> bool:
        """Stop a post that is not live yet. poem_action: 'release' (back to pool) | 'reject' | 'keep'."""
        post = await self.db.get_post(post_id)
        if not post or post["status"] in ("published", "publishing"):
            return False
        await self.db.decide_approval(post_id, decision, owner_message)
        await self.db.update_post(post_id, status="rejected" if decision == "rejected" else "cancelled")
        if poem_action == "reject":
            await self.poetry.reject_poem(post["poem_id"])
        elif poem_action == "release":
            await self.poetry.release_poem(post["poem_id"])
        return True

    async def replace_post(self, post_id: int, *, dislike: bool, owner_message: str = "") -> PostBundle | None:
        """Cancel a post and prepare another one for the same slot."""
        post = await self.db.get_post(post_id)
        if not post:
            return None
        ok = await self.cancel_post(post_id, decision="rejected" if dislike else "changes_requested",
                                    owner_message=owner_message, poem_action="reject" if dislike else "release")
        if not ok:
            return None
        return await self.prepare_post(scheduled_at=post["scheduled_at"], exclude_poem_ids=[post["poem_id"]])

    async def change_image(self, post_id: int, *, avoid_style: str | None = None) -> PostBundle | None:
        """Swap the image of a post that is still waiting for approval."""
        post = await self.db.get_post(post_id)
        if not post or post["status"] != "pending_approval":
            return None
        poem = await self.db.get_poem(post["poem_id"])
        analysis = await self.db.get_analysis(post["poem_id"])
        body, credit = self.poetry.body_and_credit(poem["raw_text"])
        avoid = await self.memory.active_avoidances()
        styles = list(avoid["image_style"]) + ([avoid_style] if avoid_style else [])
        exclude = [post["image_id"]] if post["image_id"] else []
        image = await self.images.find_for_poem(post["poem_id"], body, analysis["emotions"] if analysis else [],
                                                (), styles, exclude)
        if image is None:
            return None
        caption = self.format_caption(body, credit, image, poem.get("original_link"))
        await self.db.update_post(post_id, image_id=image["id"], caption=caption)
        return await self.bundle(post_id)

    async def reschedule(self, post_id: int, when: datetime) -> str | None:
        post = await self.db.get_post(post_id)
        if not post or post["status"] not in OPEN_STATUSES:
            return None
        fields: dict[str, Any] = {"scheduled_at": to_db(when)}
        if post["status"] in ("approved", "scheduled"):
            fields["status"] = "scheduled" if when > utcnow() else "approved"
        await self.db.update_post(post_id, **fields)
        return fields.get("status", post["status"])

    async def skip_today(self) -> int:
        """Owner: 'do not post today'. Cancels today's open posts and blocks new slots for today."""
        today = self.local_date_str()
        await self.db.set_config("skip_date", today)
        start = local_to_utc(*map(int, today.split("-")), 0, 0, self.settings.timezone_offset_minutes)
        count = 0
        for post in await self.db.posts_in_range(to_db(start), to_db(start + timedelta(days=1))):
            if post["status"] in OPEN_STATUSES and await self.cancel_post(
                    post["id"], decision="rejected", owner_message="skip today", poem_action="release"):
                count += 1
        return count

    # ------------------------------------------------------------------
    # publishing
    # ------------------------------------------------------------------
    async def publish(self, post_id: int, sender: Sender, attempts: int = 3) -> int | None:
        """Send an approved post. Returns the Telegram message id."""
        post = await self.db.get_post(post_id)
        if not post:
            return None
        done = await self.db.get_success_publish(post_id)
        if done:                                           # duplicate publishing prevention
            await self.db.update_post(post_id, status="published")
            return done["telegram_message_id"]
        approval = await self.db.latest_approval(post_id)
        if not approval or approval["decision"] != "approved" or post["status"] not in ("approved", "scheduled"):
            raise ApprovalRequired(f"post {post_id} has no owner approval")
        if not await self.db.claim_post(post_id, ("approved", "scheduled"), "publishing"):
            return None                                    # someone else is already publishing it
        bundle = await self.bundle(post_id)
        assert bundle is not None
        channel = self.settings.target_channel
        last_error = ""
        for attempt in range(1, attempts + 1):
            try:
                message_id = await sender(bundle)
            except Exception as exc:  # network, flood wait, permissions ...
                last_error = f"{type(exc).__name__}: {exc}"
                await self.db.record_publish(post_id, channel, "failed", error=last_error, attempt=attempt)
                log.warning("publish attempt %s/%s failed for post %s: %s", attempt, attempts, post_id, last_error)
                if attempt < attempts:
                    await self._sleep(2 ** attempt)
                continue
            try:
                await self.db.record_publish(post_id, channel, "success", message_id, attempt=attempt)
                await self.db.update_post(post_id, status="published")
                await self.db.set_poem_status(post["poem_id"], "posted")
            except Exception as exc:
                await self.db.log_error("channel_manager",
                                        f"post {post_id} WAS SENT (message {message_id}) but saving failed: {exc}",
                                        level="critical")
                raise
            return message_id
        await self.db.update_post(post_id, status="failed")
        await self.poetry.release_poem(post["poem_id"])
        raise PublishError(f"post {post_id} failed after {attempts} attempts: {last_error}")

    async def recover_stuck(self, minutes: int = 10) -> list[int]:
        """Posts left in 'publishing' (crash mid-send). Never re-sent automatically."""
        recovered: list[int] = []
        for post in await self.db.stuck_posts(to_db(utcnow() - timedelta(minutes=minutes))):
            done = await self.db.get_success_publish(post["id"])
            if done:
                await self.db.update_post(post["id"], status="published")
                await self.db.set_poem_status(post["poem_id"], "posted")
                continue
            await self.db.update_post(post["id"], status="failed")
            await self.poetry.release_poem(post["poem_id"])
            await self.db.log_error("channel_manager", f"post {post['id']} stuck in publishing; marked failed", level="warning")
            recovered.append(post["id"])
        return recovered

    async def due_post_ids(self) -> list[int]:
        return [p["id"] for p in await self.db.due_posts(to_db(utcnow()))]

    # ------------------------------------------------------------------
    # analytics
    # ------------------------------------------------------------------
    async def collect_stats(self, fetch: StatsFetcher, days: int = 14) -> int:
        """Store the latest views/reactions/forwards of recent posts."""
        rows = await self.db.published_since(to_db(utcnow() - timedelta(days=days)))
        by_channel: dict[str, list[dict[str, Any]]] = {}
        for r in rows:
            by_channel.setdefault(r["channel_id"], []).append(r)
        saved = 0
        for channel, items in by_channel.items():
            stats = await fetch(channel, [i["telegram_message_id"] for i in items])
            for item in items:
                values = stats.get(item["telegram_message_id"])
                if values:
                    await self.db.add_stats(item["id"], *values)
                    saved += 1
        return saved

    async def performance_report(self, days: int = 14) -> dict[str, Any]:
        rows = await self.db.performance_rows(to_db(utcnow() - timedelta(days=days)))
        per_cat: dict[str, list[dict[str, Any]]] = {}
        emotions: Counter[str] = Counter()
        for r in rows:
            for cat in r["categories"]:
                per_cat.setdefault(cat, []).append(r)
            if r["emotions"]:
                emotions[r["emotions"][0]["name"]] += 1
        cats = {c: {"posts": len(v),
                    "avg_views": round(sum(x["views"] or 0 for x in v) / len(v), 1),
                    "avg_reactions": round(sum(x["reactions"] or 0 for x in v) / len(v), 1)}
                for c, v in per_cat.items()}
        measured = [r for r in rows if r["views"] is not None]
        best = max(measured, key=lambda r: r["views"], default=None)
        return {"days": days, "posts": len(rows), "categories": cats, "emotions": dict(emotions),
                "best_post": {"post_id": best["post_id"], "views": best["views"]} if best else None}

    @staticmethod
    def category_label(key: str) -> str:
        return PLAN_LABELS.get(key, key)

    async def status_summary(self) -> dict[str, Any]:
        return {"poems": await self.db.count_poems_by_status(), "posts": await self.db.count_posts_by_status(),
                "sources": len(await self.db.list_source_channels()),
                "images_today": await self.images.searches_today(),
                "skip_date": await self.db.get_config("skip_date"),
                "auto": (await self.db.get_config("auto_prepare", "1")) == "1"}
