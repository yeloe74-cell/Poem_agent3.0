"""Safe text ingestion and deterministic chunking for local knowledge retrieval."""
from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from typing import Any, Iterable

@dataclass(frozen=True)
class TextChunk:
    index: int
    content: str
    digest: str
    source: str

class KnowledgeIngestor:
    """Prepare plain text for KnowledgeStore; never fetch arbitrary URLs or execute files."""
    def __init__(self, *, chunk_chars: int = 1200, overlap_chars: int = 160,
                 max_document_chars: int = 200000) -> None:
        self.chunk_chars = max(300, min(int(chunk_chars), 8000))
        self.overlap = max(0, min(int(overlap_chars), self.chunk_chars // 2))
        self.max_document = max(self.chunk_chars, min(int(max_document_chars), 2_000_000))

    @staticmethod
    def normalize(text: str) -> str:
        text = str(text).replace("\x00", " ").replace("\r\n", "\n").replace("\r", "\n")
        text = re.sub(r"[\t ]+", " ", text)
        text = re.sub(r"\n{3,}", "\n\n", text)
        return text.strip()

    def chunk(self, text: str, *, source: str) -> list[TextChunk]:
        if not isinstance(text, str):
            raise TypeError("document must be text")
        if not source.strip() or len(source) > 300:
            raise ValueError("source must contain 1-300 characters")
        normalized = self.normalize(text)[:self.max_document]
        if not normalized:
            return []
        chunks: list[TextChunk] = []
        start = 0
        while start < len(normalized):
            end = min(len(normalized), start + self.chunk_chars)
            if end < len(normalized):
                boundary = normalized.rfind("\n", start + self.chunk_chars // 2, end)
                if boundary > start:
                    end = boundary
            content = normalized[start:end].strip()
            if content:
                digest = hashlib.sha256((source + "\0" + content).encode()).hexdigest()
                chunks.append(TextChunk(len(chunks), content, digest, source.strip()))
            if end >= len(normalized):
                break
            start = max(start + 1, end - self.overlap)
        return chunks

    async def ingest(self, store: Any, text: str, *, source: str, category: str = "document") -> dict[str, int]:
        chunks = self.chunk(text, source=source)
        inserted = 0
        if not hasattr(store, "add"):
            raise TypeError("knowledge store must expose add(key, content, category=...)")
        for chunk in chunks:
            # KnowledgeStore uses an upsert keyed by digest, making repeated
            # ingestion idempotent without needing a vector database.
            await store.add(chunk.digest, chunk.content, category=category, importance=3)
            inserted += 1
        return {"chunks": len(chunks), "inserted": inserted, "skipped": 0}
