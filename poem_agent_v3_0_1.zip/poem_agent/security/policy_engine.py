"""Scoped permission policies and expiring, single-use owner approvals."""
from __future__ import annotations

import hashlib
import hmac
import secrets
import time
from dataclasses import dataclass
from enum import Enum
from typing import Iterable

class ActionRisk(str, Enum):
    READ = "read"
    INTERNAL_WRITE = "internal_write"
    EXTERNAL = "external"
    DESTRUCTIVE = "destructive"
    CREDENTIAL = "credential"

@dataclass(frozen=True)
class PolicyDecision:
    allowed: bool
    approval_required: bool
    reason: str

class ApprovalVault:
    """Short-lived in-memory approval tokens; tokens are scoped and consumed once."""
    def __init__(self, *, ttl_seconds: int = 180) -> None:
        self.ttl = max(15, min(int(ttl_seconds), 900))
        self._tokens: dict[str, tuple[str, float]] = {}

    def issue(self, action: str, subject: str) -> str:
        token = secrets.token_urlsafe(24)
        digest = hashlib.sha256(token.encode()).hexdigest()
        self._tokens[digest] = (f"{action}:{subject}", time.monotonic() + self.ttl)
        self._purge()
        return token

    def consume(self, token: str, action: str, subject: str) -> bool:
        if not isinstance(token, str) or len(token) > 200:
            return False
        digest = hashlib.sha256(token.encode()).hexdigest()
        record = self._tokens.pop(digest, None)
        if not record:
            return False
        scope, expires = record
        return time.monotonic() <= expires and hmac.compare_digest(scope, f"{action}:{subject}")

    def _purge(self) -> None:
        now = time.monotonic()
        self._tokens = {key: value for key, value in self._tokens.items() if value[1] > now}

class PolicyEngine:
    """Default-deny policy for unknown tools and risky capabilities."""
    DEFAULT = {
        "read": ActionRisk.READ, "search": ActionRisk.READ, "calculate": ActionRisk.READ,
        "create_task": ActionRisk.INTERNAL_WRITE, "update_task": ActionRisk.INTERNAL_WRITE,
        "remember": ActionRisk.INTERNAL_WRITE, "create_plan": ActionRisk.READ,
        "publish": ActionRisk.EXTERNAL, "send_message": ActionRisk.EXTERNAL,
        "delete": ActionRisk.DESTRUCTIVE, "change_credentials": ActionRisk.CREDENTIAL,
    }

    def __init__(self, allowed: Iterable[str] = (), *, allow_internal_writes: bool = True) -> None:
        self.allowed = frozenset(str(x) for x in allowed)
        self.allow_internal_writes = bool(allow_internal_writes)

    def assess(self, action: str, *, approval_token: str | None = None,
               subject: str = "default", vault: ApprovalVault | None = None) -> PolicyDecision:
        if action not in self.allowed:
            return PolicyDecision(False, False, "action is not allow-listed")
        risk = self.DEFAULT.get(action, ActionRisk.EXTERNAL)
        if risk == ActionRisk.READ:
            return PolicyDecision(True, False, "read-only action allowed")
        if risk == ActionRisk.INTERNAL_WRITE and self.allow_internal_writes:
            return PolicyDecision(True, False, "reversible internal action allowed")
        if approval_token and vault and vault.consume(approval_token, action, subject):
            return PolicyDecision(True, False, "scoped owner approval accepted")
        return PolicyDecision(False, True, f"{risk.value} action requires explicit owner approval")
