"""Durable, resumable workflow execution with dependency and idempotency checks."""
from __future__ import annotations

import json
import logging
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, Mapping, Sequence

log = logging.getLogger(__name__)
SCHEMA = """
CREATE TABLE IF NOT EXISTS agent_workflows (
 id TEXT PRIMARY KEY, goal TEXT NOT NULL, state TEXT NOT NULL,
 payload TEXT NOT NULL, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS agent_workflow_steps (
 id TEXT PRIMARY KEY, workflow_id TEXT NOT NULL REFERENCES agent_workflows(id) ON DELETE CASCADE,
 step_key TEXT NOT NULL, tool_name TEXT NOT NULL, arguments TEXT NOT NULL,
 dependencies TEXT NOT NULL, state TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0,
 result TEXT, error TEXT, updated_at TEXT NOT NULL,
 UNIQUE(workflow_id, step_key)
);
CREATE INDEX IF NOT EXISTS idx_workflow_steps_state ON agent_workflow_steps(workflow_id,state);
CREATE TABLE IF NOT EXISTS agent_idempotency (
 scope TEXT NOT NULL, idem_key TEXT NOT NULL, result TEXT NOT NULL,
 created_at TEXT NOT NULL, PRIMARY KEY(scope,idem_key)
);
"""

@dataclass(frozen=True)
class WorkflowStep:
    key: str
    title: str
    tool: str
    arguments: Mapping[str, Any] = field(default_factory=dict)
    depends_on: tuple[str, ...] = ()
    requires_approval: bool = False

@dataclass(frozen=True)
class Workflow:
    workflow_id: str
    goal: str
    steps: tuple[WorkflowStep, ...]

class WorkflowValidationError(ValueError):
    pass

class WorkflowEngine:
    """Stores plans and checkpoints; it never executes untrusted generated code."""
    TERMINAL = {"done", "failed", "cancelled", "blocked"}

    def __init__(self, db: Any, *, max_steps: int = 30, max_attempts: int = 3) -> None:
        self.db = db
        self.max_steps = max(1, min(int(max_steps), 100))
        self.max_attempts = max(1, min(int(max_attempts), 8))

    async def initialize(self) -> None:
        for statement in SCHEMA.split(";"):
            if statement.strip():
                await self.db.execute(statement)

    def validate(self, goal: str, steps: Sequence[Mapping[str, Any]], allowed_tools: Sequence[str]) -> Workflow:
        if not isinstance(goal, str) or not goal.strip() or len(goal) > 1800:
            raise WorkflowValidationError("goal must contain 1-1800 characters")
        if not isinstance(steps, Sequence) or isinstance(steps, (str, bytes)) or not 1 <= len(steps) <= self.max_steps:
            raise WorkflowValidationError(f"workflow must contain 1-{self.max_steps} steps")
        allowed = set(allowed_tools)
        parsed: list[WorkflowStep] = []
        seen: set[str] = set()
        for index, raw in enumerate(steps, 1):
            if not isinstance(raw, Mapping):
                raise WorkflowValidationError(f"step {index} must be an object")
            key = str(raw.get("key", f"s{index}"))
            title, tool = raw.get("title"), raw.get("tool")
            args, deps = raw.get("arguments", {}), raw.get("depends_on", [])
            approval = raw.get("requires_approval", False)
            if key in seen or not key.isidentifier() or len(key) > 40:
                raise WorkflowValidationError(f"step {index} has invalid or duplicate key")
            if not isinstance(title, str) or not title.strip() or len(title) > 180:
                raise WorkflowValidationError(f"step {index} title is invalid")
            if not isinstance(tool, str) or tool not in allowed:
                raise WorkflowValidationError(f"step {index} tool is not allow-listed")
            if not isinstance(args, Mapping) or len(json.dumps(dict(args), ensure_ascii=False, default=str)) > 4000:
                raise WorkflowValidationError(f"step {index} arguments are invalid")
            if not isinstance(deps, list) or any(not isinstance(x, str) for x in deps):
                raise WorkflowValidationError(f"step {index} dependencies are invalid")
            if type(approval) is not bool:
                raise WorkflowValidationError(f"step {index} approval flag is invalid")
            parsed.append(WorkflowStep(key, title.strip(), tool, dict(args), tuple(deps), approval))
            seen.add(key)
        self._validate_graph(parsed)
        return Workflow(uuid.uuid4().hex, goal.strip(), tuple(parsed))

    @staticmethod
    def _validate_graph(steps: Sequence[WorkflowStep]) -> None:
        seen: set[str] = set()
        for step in steps:
            if len(set(step.depends_on)) != len(step.depends_on):
                raise WorkflowValidationError(f"{step.key} repeats dependencies")
            if any(dep not in seen for dep in step.depends_on):
                raise WorkflowValidationError("dependencies must reference earlier steps")
            if step.key in step.depends_on:
                raise WorkflowValidationError("a step cannot depend on itself")
            seen.add(step.key)

    async def create(self, workflow: Workflow) -> str:
        now = self._now()
        payload = json.dumps({"step_count": len(workflow.steps)}, ensure_ascii=False)
        await self.db.execute("INSERT INTO agent_workflows(id,goal,state,payload,created_at,updated_at) VALUES(?,?,?,?,?,?)",
                              (workflow.workflow_id, workflow.goal, "proposed", payload, now, now))
        for step in workflow.steps:
            await self.db.execute("INSERT INTO agent_workflow_steps(id,workflow_id,step_key,tool_name,arguments,dependencies,state,updated_at) VALUES(?,?,?,?,?,?,?,?)",
                (uuid.uuid4().hex, workflow.workflow_id, step.key, step.tool,
                 json.dumps(dict(step.arguments), ensure_ascii=False, default=str),
                 json.dumps(list(step.depends_on)), "pending_approval" if step.requires_approval else "pending", now))
        return workflow.workflow_id

    async def get(self, workflow_id: str) -> dict[str, Any] | None:
        head = await self.db.fetchone("SELECT * FROM agent_workflows WHERE id=?", (workflow_id,))
        if not head:
            return None
        steps = await self.db.fetchall("SELECT * FROM agent_workflow_steps WHERE workflow_id=? ORDER BY rowid", (workflow_id,))
        return {"workflow": dict(head), "steps": [dict(row) for row in steps]}

    async def ready_steps(self, workflow_id: str) -> list[dict[str, Any]]:
        rows = await self.db.fetchall("SELECT * FROM agent_workflow_steps WHERE workflow_id=? ORDER BY rowid", (workflow_id,))
        completed = {row["step_key"] for row in rows if row["state"] == "done"}
        ready = []
        for row in rows:
            if row["state"] not in {"pending", "retry"}:
                continue
            deps = json.loads(row["dependencies"])
            if all(dep in completed for dep in deps):
                ready.append(dict(row))
        return ready

    async def approve(self, workflow_id: str, *, approved_steps: set[str]) -> bool:
        """Record explicit approval for selected steps of a proposed/paused workflow."""
        if not isinstance(approved_steps, set):
            raise ValueError("approved_steps must be a set")
        data = await self.get(workflow_id)
        if not data:
            return False
        if data["workflow"]["state"] not in {"proposed", "paused", "approved"}:
            raise PermissionError("workflow cannot be approved in its current state")
        known = {row["step_key"] for row in data["steps"]}
        if not approved_steps <= known:
            raise ValueError("approval contains an unknown step")
        for row in data["steps"]:
            if row["step_key"] in approved_steps and row["state"] == "pending_approval":
                await self.db.execute("UPDATE agent_workflow_steps SET state='pending',updated_at=? WHERE id=? AND state='pending_approval'",
                                      (self._now(), row["id"]))
        await self.set_state(workflow_id, "approved")
        return True

    async def retry_step(self, step_id: str) -> bool:
        """Explicitly requeue a failed step if its attempt budget is not exhausted."""
        row = await self.db.fetchone("UPDATE agent_workflow_steps SET state='retry',error=NULL,updated_at=? WHERE id=? AND state='failed' AND attempts<? RETURNING workflow_id",
                                     (self._now(), step_id, self.max_attempts))
        if not row:
            return False
        await self.set_state(row["workflow_id"], "paused")
        return True

    async def mark_running(self, step_id: str) -> bool:
        now = self._now()
        row = await self.db.fetchone("UPDATE agent_workflow_steps SET state='running',attempts=attempts+1,updated_at=? WHERE id=? AND state IN ('pending','retry') AND attempts<? RETURNING id",
                                     (now, step_id, self.max_attempts))
        return bool(row)

    async def finish_step(self, step_id: str, *, result: Any = None, error: str | None = None) -> None:
        state = "failed" if error else "done"
        await self.db.execute("UPDATE agent_workflow_steps SET state=?,result=?,error=?,updated_at=? WHERE id=? AND state='running'",
            (state, json.dumps(result, ensure_ascii=False, default=str)[:8000] if result is not None else None,
             str(error)[:1000] if error else None, self._now(), step_id))

    async def set_state(self, workflow_id: str, state: str) -> bool:
        if state not in {"proposed", "approved", "running", "paused", "done", "failed", "cancelled"}:
            raise ValueError("invalid workflow state")
        row = await self.db.fetchone("UPDATE agent_workflows SET state=?,updated_at=? WHERE id=? RETURNING id",
                                     (state, self._now(), workflow_id))
        return bool(row)

    async def execute_ready(self, workflow_id: str, executor: Any, *,
                            approved_tools: set[str] | None = None) -> dict[str, Any]:
        """Execute one dependency-ready wave through a trusted executor callback.

        A step marked pending_approval is never selected. The callback receives
        (tool_name, decoded_arguments, idempotency_key) and must enforce its own
        tool-level authorization as a second boundary.
        """
        approved = set(approved_tools or ())
        workflow = await self.get(workflow_id)
        if not workflow:
            raise KeyError("workflow not found")
        if workflow["workflow"]["state"] not in {"approved", "running", "paused"}:
            raise PermissionError("workflow must be approved before execution")
        await self.set_state(workflow_id, "running")
        completed: list[str] = []
        failed: list[str] = []
        blocked: list[str] = []
        rows = await self.ready_steps(workflow_id)
        for row in rows:
            if row["tool_name"] not in approved:
                blocked.append(row["step_key"])
                continue
            if not await self.mark_running(row["id"]):
                continue
            arguments = json.loads(row["arguments"])
            idem_key = f"{workflow_id}:{row['step_key']}"
            try:
                cached = await self.idempotent_result("workflow", idem_key)
                result = cached if cached is not None else await executor(row["tool_name"], arguments, idem_key)
                if cached is None:
                    await self.save_idempotent_result("workflow", idem_key, result)
                await self.finish_step(row["id"], result=result)
                completed.append(row["step_key"])
            except Exception as exc:
                await self.finish_step(row["id"], error=f"{type(exc).__name__}: {str(exc)[:500]}")
                failed.append(row["step_key"])
                log.exception("workflow step failed: %s", row["step_key"])
        current = await self.get(workflow_id)
        states = {item["state"] for item in current["steps"]}
        if states <= {"done"}:
            final_state = "done"
        elif "failed" in states:
            final_state = "failed"
        elif blocked or "pending_approval" in states:
            final_state = "paused"
        else:
            final_state = "running"
        await self.set_state(workflow_id, final_state)
        return {"workflow_id": workflow_id, "state": final_state,
                "completed": completed, "failed": failed, "blocked": blocked}

    async def idempotent_result(self, scope: str, key: str) -> Any | None:
        row = await self.db.fetchone("SELECT result FROM agent_idempotency WHERE scope=? AND idem_key=?", (scope, key))
        return json.loads(row["result"]) if row else None

    async def save_idempotent_result(self, scope: str, key: str, result: Any) -> None:
        encoded = json.dumps(result, ensure_ascii=False, default=str)[:10000]
        await self.db.execute("INSERT OR IGNORE INTO agent_idempotency(scope,idem_key,result,created_at) VALUES(?,?,?,?)",
                              (scope[:120], key[:160], encoded, self._now()))

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat(timespec="seconds")
